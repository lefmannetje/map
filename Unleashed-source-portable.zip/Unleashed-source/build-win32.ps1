$ErrorActionPreference = "Stop"

$cmake = Get-Command cmake -ErrorAction SilentlyContinue
if (-not $cmake) {
    $bundledCmake = "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe"
    if (-not (Test-Path -LiteralPath $bundledCmake)) {
        throw "CMake was not found. Install Visual Studio 2022 C++ Build Tools with CMake support."
    }
    $cmakePath = $bundledCmake
} else {
    $cmakePath = $cmake.Source
}

& $cmakePath -S $PSScriptRoot -B (Join-Path $PSScriptRoot "build") -A Win32
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

& $cmakePath --build (Join-Path $PSScriptRoot "build") --config Release
exit $LASTEXITCODE
