# Unleashed for ProjectD2

Maintainable 32-bit C++ reconstruction of the supplied Unleashed map DLL,
targeted at the verified ProjectD2 client build used during development.

## Included features

- Full map reveal and cached room processing
- Num1 next, Num2 quest, Num3 waypoint, Num4 previous-area navigation
- Boss/champion/unique/Uber automap markers and Cow Level markers
- Shrine, waypoint, special chest and container markers
- Automatic rejuvenation potion below the configured player-life threshold
- Shop-winner overlay for high-value skill weapons and gloves
- Delegation to the installed ProjectD2/BH loot-filter implementation
- Standalone administrator-aware DLL loader

The bindings are intentionally fail-closed. A different `D2Client.dll`,
`ProjectDiablo.dll`, or BH build may require updated verified offsets.

## Requirements

- Windows 10 or 11
- Visual Studio 2022 Build Tools (or Visual Studio 2022) with **Desktop
  development with C++**
- CMake 3.24 or newer

## Build

Open PowerShell in this directory and run:

```powershell
.\build-win32.ps1
```

Or invoke CMake manually:

```powershell
cmake -S . -B build -A Win32
cmake --build build --config Release
```

Outputs are placed in `build\Release`:

- `Unleashed.dll`
- `UnleashedLoader.exe`

Keep `Unleashed.ini` beside `Unleashed.dll`. The optional customized loot
filter is in `filters\Unleashed-Futureal.filter`.

## Use

1. Copy `Unleashed.dll`, `Unleashed.ini`, and `UnleashedLoader.exe` into one
   folder.
2. Start ProjectD2 and enter the game.
3. Run `UnleashedLoader.exe` as administrator.

The loader targets the running 32-bit `Game.exe` and loads `Unleashed.dll`
from its own directory.

## Source layout

- `src\bindings`: target-build verification
- `src\core`: configuration, logging, and feature lifecycle
- `src\features`: map, lighting, survival, shop, and BH integration
- `src\recovered`: verified hook chains and packet dispatcher
- `tools\diagnostic_loader.cpp`: standalone loader source
