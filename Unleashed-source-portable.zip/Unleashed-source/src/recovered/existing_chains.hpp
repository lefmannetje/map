#pragma once

#include <cstdint>

namespace unleashed::recovered {

enum class ExistingChainKind : std::uint8_t {
    project_diablo_two_argument_wrapper,
    bh_packet_filter,
};

struct ExistingChainEvidence {
    ExistingChainKind kind;
    std::uint32_t d2client_site_rva;
    std::uint32_t owner_handler_rva;
    std::uint32_t owner_continuation_rva;
    std::uint8_t patch_length;
};

// Both recovered wrappers interpret zero as "suppress/clear EDX" and a
// nonzero result as "continue unchanged". Combining with logical AND keeps a
// suppression request from either filter.
constexpr bool combine_packet_filter_results(bool bh_continue,
    bool unleashed_continue) noexcept {
    return bh_continue && unleashed_continue;
}

// Static evidence from the exact ProjectD2 binaries recorded in
// bindings/target_build.hpp. These are descriptive until the module hashes
// and live bytes have been verified; they are not hook-install instructions.
inline constexpr ExistingChainEvidence kProjectDiabloChain{
    ExistingChainKind::project_diablo_two_argument_wrapper,
    0x0006264D,
    0x0020F470,
    0x0028ECB0,
    5,
};

inline constexpr ExistingChainEvidence kBhPacketChain{
    ExistingChainKind::bh_packet_filter,
    0x000ACE61,
    0x00079A90,
    0x000437F0,
    5,
};

}  // namespace unleashed::recovered
