#include "recovered/untouched_handlers.hpp"

#include <array>
#include <cstring>
#include <limits>
#include <windows.h>

#include "bindings/target_build.hpp"

namespace unleashed::recovered {

extern "C" volatile long site_a9a27_enabled = 0;

namespace {

VoidCallback site_2929e_original = nullptr;
VoidCallback site_2929e_overlay = nullptr;
VoidCallback site_2929e_overlay2 = nullptr;
std::uint8_t* site_a9a27_address = nullptr;
std::array<std::uint8_t, 5> site_a9a27_saved{};
std::array<std::uint8_t, 5> site_a9a27_patch{};
std::uint8_t* site_2929e_address = nullptr;
std::array<std::uint8_t, 5> site_2929e_saved{};
std::array<std::uint8_t, 5> site_2929e_patch{};

bool write_five_bytes(std::uint8_t* destination,
    const std::array<std::uint8_t, 5>& bytes) noexcept {
    DWORD previous = 0;
    if (VirtualProtect(destination, bytes.size(), PAGE_EXECUTE_READWRITE,
            &previous) == FALSE) {
        return false;
    }
    std::memcpy(destination, bytes.data(), bytes.size());
    FlushInstructionCache(GetCurrentProcess(), destination, bytes.size());
    DWORD ignored = 0;
    return VirtualProtect(destination, bytes.size(), previous, &ignored) != FALSE;
}

}  // namespace

// Exact reconstruction of reference VA 0x100043F0. This function depends on
// the x86 stack layout at D2Client RVA 0xA9A27 and must not be called normally.
extern "C" __declspec(naked) void site_a9a27_handler() noexcept {
    __asm {
        cmp dword ptr [site_a9a27_enabled], 0
        je disabled_path
        mov eax, 0ffh
        mov byte ptr [esp + 4], al
        mov byte ptr [esp + 5], al
        mov byte ptr [esp + 6], al
        // The three bytes above control the light colour.  The low byte of
        // EAX is emitted as the fourth (intensity/alpha) component.  Leaving
        // the caller's 0/1 value here kept Act V interiors dark even though
        // their light colour was white.
        mov eax, 0ffh
        add dword ptr [esp], 082h
        ret
    disabled_path:
        mov byte ptr [esp + 5], 0
        ret
    }
}

bool install_site_a9a27_hook() noexcept {
    if (site_a9a27_address != nullptr) {
        return false;
    }
    auto* d2client = reinterpret_cast<std::uint8_t*>(
        GetModuleHandleW(L"D2Client.dll"));
    if (d2client == nullptr) {
        return false;
    }
    constexpr auto& evidence = bindings::recovered_d2client_sites[1];
    auto* site = d2client + evidence.rva;
    if (std::memcmp(site, evidence.verified_original_bytes.data(),
            evidence.verified_original_bytes.size()) != 0) {
        return false;
    }
    const auto delta = reinterpret_cast<std::intptr_t>(&site_a9a27_handler) -
        reinterpret_cast<std::intptr_t>(site + 5);
    if (delta < std::numeric_limits<std::int32_t>::min() ||
        delta > std::numeric_limits<std::int32_t>::max()) {
        return false;
    }
    std::memcpy(site_a9a27_saved.data(), site, site_a9a27_saved.size());
    site_a9a27_patch[0] = 0xe8;
    const auto displacement = static_cast<std::int32_t>(delta);
    std::memcpy(site_a9a27_patch.data() + 1, &displacement,
        sizeof(displacement));
    site_a9a27_enabled = 1;
    if (!write_five_bytes(site, site_a9a27_patch)) {
        site_a9a27_enabled = 0;
        return false;
    }
    site_a9a27_address = site;
    return true;
}

bool remove_site_a9a27_hook() noexcept {
    if (site_a9a27_address == nullptr) {
        return true;
    }
    if (std::memcmp(site_a9a27_address, site_a9a27_patch.data(),
            site_a9a27_patch.size()) != 0) {
        return false;
    }
    if (!write_five_bytes(site_a9a27_address, site_a9a27_saved)) {
        return false;
    }
    site_a9a27_address = nullptr;
    site_a9a27_enabled = 0;
    return true;
}

void configure_site_2929e_chain(VoidCallback displaced_original,
    VoidCallback recovered_overlay) noexcept {
    site_2929e_original = displaced_original;
    site_2929e_overlay = recovered_overlay;
}

// Structural reconstruction of reference VA 0x10004880. The original binary
// first called an indirect displaced target, then its overlay routine.
extern "C" void site_2929e_handler() noexcept {
    if (site_2929e_original != nullptr) {
        site_2929e_original();
    }
    if (site_2929e_overlay != nullptr) {
        site_2929e_overlay();
    }
    if (site_2929e_overlay2 != nullptr) {
        site_2929e_overlay2();
    }
}

bool install_site_2929e_hook(VoidCallback callback) noexcept {
    if (callback == nullptr) {
        return false;
    }
    if (site_2929e_address != nullptr) {
        if (site_2929e_overlay == callback || site_2929e_overlay2 == callback) {
            return true;
        }
        if (site_2929e_overlay2 == nullptr) {
            site_2929e_overlay2 = callback;
            return true;
        }
        return false;
    }
    auto* d2client = reinterpret_cast<std::uint8_t*>(
        GetModuleHandleW(L"D2Client.dll"));
    if (d2client == nullptr) {
        return false;
    }
    constexpr auto& evidence = bindings::recovered_d2client_sites[2];
    auto* site = d2client + evidence.rva;
    if (std::memcmp(site, evidence.verified_original_bytes.data(), 5) != 0 ||
        site[0] != 0xe8) {
        return false;
    }
    std::int32_t old_displacement = 0;
    std::memcpy(&old_displacement, site + 1, sizeof(old_displacement));
    const auto delta = reinterpret_cast<std::intptr_t>(&site_2929e_handler) -
        reinterpret_cast<std::intptr_t>(site + 5);
    if (delta < std::numeric_limits<std::int32_t>::min() ||
        delta > std::numeric_limits<std::int32_t>::max()) {
        return false;
    }
    std::memcpy(site_2929e_saved.data(), site, 5);
    site_2929e_patch[0] = 0xe8;
    const auto displacement = static_cast<std::int32_t>(delta);
    std::memcpy(site_2929e_patch.data() + 1, &displacement,
        sizeof(displacement));
    configure_site_2929e_chain(
        reinterpret_cast<VoidCallback>(site + 5 + old_displacement), callback);
    if (!write_five_bytes(site, site_2929e_patch)) {
        configure_site_2929e_chain(nullptr, nullptr);
        return false;
    }
    site_2929e_address = site;
    return true;
}

bool remove_site_2929e_hook(VoidCallback callback) noexcept {
    if (site_2929e_address == nullptr) {
        return true;
    }
    if (site_2929e_overlay == callback && site_2929e_overlay2 != nullptr) {
        site_2929e_overlay = site_2929e_overlay2;
        site_2929e_overlay2 = nullptr;
        return true;
    }
    if (site_2929e_overlay2 == callback) {
        site_2929e_overlay2 = nullptr;
        return true;
    }
    if (site_2929e_overlay != callback) {
        return false;
    }
    if (std::memcmp(site_2929e_address, site_2929e_patch.data(), 5) != 0 ||
        !write_five_bytes(site_2929e_address, site_2929e_saved)) {
        return false;
    }
    site_2929e_address = nullptr;
    site_2929e_overlay2 = nullptr;
    configure_site_2929e_chain(nullptr, nullptr);
    return true;
}

}  // namespace unleashed::recovered
