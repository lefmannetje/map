#include "recovered/bh_dispatcher.hpp"

#include <array>
#include <cstring>
#include <limits>
#include <windows.h>

#include "recovered/existing_chains.hpp"
#include "core/config.hpp"

namespace unleashed::recovered {
namespace {

extern "C" volatile long bh_packet_count = 0;
extern "C" volatile long unleashed_mutation_count = 0;
extern "C" volatile long unleashed_suppression_count = 0;
volatile long packet_counts[256]{};
volatile long inventory_full_count = 0;
volatile long recovered_pickit_state = 1;
extern "C" void* bh_original_handler = nullptr;

std::uint8_t* patched_site = nullptr;
std::array<std::uint8_t, 5> saved_bytes{};
std::array<std::uint8_t, 5> installed_bytes{};

// Evidence-backed subset of reference function 0x10004430. ECX is the packet
// pointer and EDX is its byte length at the intercepted D2Client call.
extern "C" int __fastcall unleashed_packet_filter(
    std::uint8_t* packet, std::uint32_t length) noexcept {
    if (packet == nullptr || length == 0) {
        return 1;
    }
    InterlockedIncrement(&packet_counts[packet[0]]);
    if (config().packet_51_adjustment && packet[0] == 0x51 &&
        length > 0x0c && packet[6] == 0x3b &&
        packet[0x0c] < 2) {
        packet[0x0c] = 2;
        InterlockedIncrement(&unleashed_mutation_count);
    }
    if (config().packet_a7_suppression && packet[0] == 0xa7 &&
        length > 6 && packet[6] == 0x66) {
        InterlockedIncrement(&unleashed_suppression_count);
        return 0;
    }
    if (config().inventory_full_event && packet[0] == 0x2c &&
        length == 8 && packet[1] == 0 &&
        packet[6] == 0x17) {
        InterlockedExchange(&recovered_pickit_state, 0);
        InterlockedIncrement(&inventory_full_count);
    }
    return 1;
}

extern "C" __declspec(naked) void bh_passthrough_entry() noexcept {
    __asm {
        lock inc dword ptr [bh_packet_count]
        pushad
        call unleashed_packet_filter
        test eax, eax
        popad
        jne continue_to_bh
        xor edx, edx
    continue_to_bh:
        jmp dword ptr [bh_original_handler]
    }
}

bool write_five_bytes(std::uint8_t* destination,
    const std::array<std::uint8_t, 5>& bytes) noexcept {
    DWORD previous = 0;
    if (VirtualProtect(destination, bytes.size(), PAGE_EXECUTE_READWRITE,
            &previous) == FALSE) {
        return false;
    }
    std::memcpy(destination, bytes.data(), bytes.size());
    FlushInstructionCache(GetCurrentProcess(), destination, bytes.size());
    DWORD ignored = 0;
    return VirtualProtect(destination, bytes.size(), previous, &ignored) != FALSE;
}

}  // namespace

bool install_bh_passthrough_dispatcher() noexcept {
    if (patched_site != nullptr) {
        return false;
    }
    const auto d2client = reinterpret_cast<std::uint8_t*>(
        GetModuleHandleW(L"D2Client.dll"));
    const auto bh = reinterpret_cast<std::uint8_t*>(GetModuleHandleW(L"BH.dll"));
    if (d2client == nullptr || bh == nullptr) {
        return false;
    }

    auto* site = d2client + kBhPacketChain.d2client_site_rva;
    auto* expected_handler = bh + kBhPacketChain.owner_handler_rva;
    if (site[0] != 0xe8) {
        return false;
    }
    std::int32_t current_displacement = 0;
    std::memcpy(&current_displacement, site + 1, sizeof(current_displacement));
    if (site + 5 + current_displacement != expected_handler) {
        return false;
    }

    const auto delta = reinterpret_cast<std::intptr_t>(&bh_passthrough_entry) -
        reinterpret_cast<std::intptr_t>(site + 5);
    if (delta < std::numeric_limits<std::int32_t>::min() ||
        delta > std::numeric_limits<std::int32_t>::max()) {
        return false;
    }

    std::memcpy(saved_bytes.data(), site, saved_bytes.size());
    installed_bytes[0] = 0xe8;
    const auto displacement = static_cast<std::int32_t>(delta);
    std::memcpy(installed_bytes.data() + 1, &displacement, sizeof(displacement));
    bh_original_handler = expected_handler;
    InterlockedExchange(&bh_packet_count, 0);
    InterlockedExchange(&unleashed_mutation_count, 0);
    InterlockedExchange(&unleashed_suppression_count, 0);
    for (auto& count : packet_counts) {
        InterlockedExchange(&count, 0);
    }
    InterlockedExchange(&inventory_full_count, 0);
    InterlockedExchange(&recovered_pickit_state, 1);
    if (!write_five_bytes(site, installed_bytes)) {
        bh_original_handler = nullptr;
        return false;
    }
    patched_site = site;
    return true;
}

bool remove_bh_passthrough_dispatcher() noexcept {
    if (patched_site == nullptr) {
        return true;
    }
    if (std::memcmp(patched_site, installed_bytes.data(), installed_bytes.size()) != 0) {
        return false;
    }
    if (!write_five_bytes(patched_site, saved_bytes)) {
        return false;
    }
    patched_site = nullptr;
    bh_original_handler = nullptr;
    return true;
}

std::uint32_t bh_dispatch_count() noexcept {
    return static_cast<std::uint32_t>(
        InterlockedCompareExchange(&bh_packet_count, 0, 0));
}

std::uint32_t unleashed_packet_mutation_count() noexcept {
    return static_cast<std::uint32_t>(
        InterlockedCompareExchange(&unleashed_mutation_count, 0, 0));
}

std::uint32_t unleashed_packet_suppression_count() noexcept {
    return static_cast<std::uint32_t>(
        InterlockedCompareExchange(&unleashed_suppression_count, 0, 0));
}

std::uint32_t packet_id_count(std::uint8_t packet_id) noexcept {
    return static_cast<std::uint32_t>(
        InterlockedCompareExchange(&packet_counts[packet_id], 0, 0));
}

std::uint32_t inventory_full_disable_count() noexcept {
    return static_cast<std::uint32_t>(
        InterlockedCompareExchange(&inventory_full_count, 0, 0));
}

bool recovered_pickit_enabled() noexcept {
    return InterlockedCompareExchange(&recovered_pickit_state, 0, 0) != 0;
}

}  // namespace unleashed::recovered
