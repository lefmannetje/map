#include "recovered/existing_chains.hpp"

namespace unleashed::recovered {

static_assert(kProjectDiabloChain.patch_length == 5);
static_assert(kBhPacketChain.patch_length == 5);
static_assert(kProjectDiabloChain.d2client_site_rva !=
    kBhPacketChain.d2client_site_rva);
static_assert(combine_packet_filter_results(true, true));
static_assert(!combine_packet_filter_results(false, true));
static_assert(!combine_packet_filter_results(true, false));
static_assert(!combine_packet_filter_results(false, false));

}  // namespace unleashed::recovered
