#pragma once

#include <cstdint>

namespace unleashed::recovered {

bool install_bh_passthrough_dispatcher() noexcept;
bool remove_bh_passthrough_dispatcher() noexcept;
std::uint32_t bh_dispatch_count() noexcept;
std::uint32_t unleashed_packet_mutation_count() noexcept;
std::uint32_t unleashed_packet_suppression_count() noexcept;
std::uint32_t packet_id_count(std::uint8_t packet_id) noexcept;
std::uint32_t inventory_full_disable_count() noexcept;
bool recovered_pickit_enabled() noexcept;

}  // namespace unleashed::recovered
