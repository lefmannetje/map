#pragma once

#include <cstdint>

namespace unleashed::recovered {

using VoidCallback = void(__cdecl*)();

// Neutral names preserve evidence without claiming an unproven feature role.
extern "C" volatile long site_a9a27_enabled;
extern "C" void site_a9a27_handler() noexcept;
bool install_site_a9a27_hook() noexcept;
bool remove_site_a9a27_hook() noexcept;

void configure_site_2929e_chain(VoidCallback displaced_original,
    VoidCallback recovered_overlay) noexcept;
bool install_site_2929e_hook(VoidCallback callback) noexcept;
bool remove_site_2929e_hook(VoidCallback callback) noexcept;
extern "C" void site_2929e_handler() noexcept;

}  // namespace unleashed::recovered
