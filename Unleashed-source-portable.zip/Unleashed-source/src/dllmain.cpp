#include <windows.h>

#include "core/runtime.hpp"
#include "core/logger.hpp"
#include "recovered/bh_dispatcher.hpp"

namespace {

DWORD WINAPI start_runtime(void* parameter) noexcept {
    if (unleashed::Runtime::instance().start(static_cast<HMODULE>(parameter))) {
        bool dispatch_logged = false;
        for (unsigned int attempt = 0; attempt < 1200; ++attempt) {
            const auto count = unleashed::recovered::bh_dispatch_count();
            if (!dispatch_logged && count != 0) {
                char message[96]{};
                wsprintfA(message,
                    "CONFIRMED: chained packet dispatcher executed; count=%u", count);
                unleashed::logger::write(message);
                dispatch_logged = true;
            }
            if (unleashed::recovered::inventory_full_disable_count() != 0) {
                unleashed::logger::write(
                    "CONFIRMED: inventory-full packet disabled recovered PickIt state");
                unleashed::logger::write(
                    "NOTICE: Divin's PickIt: Your Inventory Is Full, PickIt Disabled. "
                    "(Use Toggle Key To Enable It)");
                break;
            }
            Sleep(100);
        }
    }
    return 0;
}

}  // namespace

BOOL WINAPI DllMain(HINSTANCE instance, DWORD reason, LPVOID) {
    switch (reason) {
    case DLL_PROCESS_ATTACH: {
        DisableThreadLibraryCalls(instance);
        const HANDLE thread = CreateThread(nullptr, 0, start_runtime, instance, 0, nullptr);
        if (thread != nullptr) {
            CloseHandle(thread);
        }
        break;
    }
    case DLL_PROCESS_DETACH:
        unleashed::Runtime::instance().stop();
        break;
    default:
        break;
    }
    return TRUE;
}
