#pragma once

#include <string_view>

namespace unleashed {

class Feature {
public:
    virtual ~Feature() = default;
    [[nodiscard]] virtual std::string_view name() const noexcept = 0;
    [[nodiscard]] virtual bool start() noexcept = 0;
    virtual void stop() noexcept = 0;
};

}  // namespace unleashed
