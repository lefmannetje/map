#pragma once

#include <windows.h>

namespace unleashed {

struct Config final {
    bool packet_51_adjustment = true;
    bool packet_a7_suppression = true;
    bool inventory_full_event = false;
    bool project_diablo_map = true;
    bool force_shrine_labels = false;
    bool bh_loot_filter = true;
    bool full_brightness = true;
    bool auto_rejuvenation = false;
    int rejuvenation_life_percent = 50;
    int rejuvenation_belt_key = 1;
    int rejuvenation_cooldown_ms = 1000;
    bool auto_mercenary_rejuvenation = true;
    int mercenary_rejuvenation_life_percent = 40;
    int mercenary_potion_belt_key = 3;
    int mercenary_rejuvenation_cooldown_ms = 1000;
    bool avatar = false;
};

Config& config() noexcept;
bool load_config(HMODULE module) noexcept;

}  // namespace unleashed
