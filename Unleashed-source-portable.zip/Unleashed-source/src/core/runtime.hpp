#pragma once

#include <windows.h>

namespace unleashed {

class Runtime final {
public:
    static Runtime& instance() noexcept;
    bool start(HMODULE module) noexcept;
    void stop() noexcept;

private:
    Runtime() = default;
    HMODULE module_{};
    bool running_{};
};

}  // namespace unleashed
