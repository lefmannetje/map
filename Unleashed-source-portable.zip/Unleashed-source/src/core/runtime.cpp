#include "core/runtime.hpp"

#include <array>
#include <memory>

#include "bindings/target_verifier.hpp"
#include "core/feature.hpp"
#include "core/config.hpp"
#include "core/logger.hpp"
#include "features/avatar.hpp"
#include "features/lighting.hpp"
#include "features/map_reveal.hpp"
#include "features/pickit.hpp"
#include "features/survival.hpp"
#include "recovered/bh_dispatcher.hpp"

namespace unleashed {
namespace {

using FeatureList = std::array<std::unique_ptr<Feature>, 5>;

FeatureList& features() {
    static FeatureList value{
        std::make_unique<MapReveal>(),
        std::make_unique<Pickit>(),
        std::make_unique<Lighting>(),
        std::make_unique<Survival>(),
        std::make_unique<Avatar>(),
    };
    return value;
}

}  // namespace

Runtime& Runtime::instance() noexcept {
    static Runtime runtime;
    return runtime;
}

bool Runtime::start(HMODULE module) noexcept {
    if (running_ || module == nullptr) {
        return false;
    }

    module_ = module;
    running_ = true;

    if (!logger::open(module_)) {
        running_ = false;
        module_ = nullptr;
        return false;
    }
    logger::write("Unleashed reconstruction loaded");
    if (!load_config(module_)) {
        logger::write("Unleashed.ini unavailable; using safe defaults");
    }

    const auto verification = bindings::wait_and_verify_d2client(60'000);
    if (verification != bindings::VerificationResult::verified) {
        logger::write("Initialization stopped because target verification failed");
        running_ = false;
        module_ = nullptr;
        logger::close();
        return false;
    }

    // Features stay fail-closed until bindings for the supplied game build are
    // verified. Delegated owners must be checked before the dispatcher replaces
    // BH's relative call with our forwarding entry.
    for (auto& feature : features()) {
        static_cast<void>(feature->start());
    }

    if (!recovered::install_bh_passthrough_dispatcher()) {
        logger::write("FAILED: chained packet dispatcher was not installed");
        for (auto iterator = features().rbegin(); iterator != features().rend(); ++iterator) {
            (*iterator)->stop();
        }
        running_ = false;
        module_ = nullptr;
        logger::close();
        return false;
    }
    logger::write("Chained packet dispatcher installed; BH forwarding preserved");
    return true;
}

void Runtime::stop() noexcept {
    if (!running_) {
        return;
    }
    logger::write("Unleashed reconstruction stopping");
    for (auto iterator = features().rbegin(); iterator != features().rend(); ++iterator) {
        (*iterator)->stop();
    }
    char count_message[96]{};
    wsprintfA(count_message, "Chained packet dispatch count: %u",
        recovered::bh_dispatch_count());
    logger::write(count_message);
    wsprintfA(count_message, "Inventory-full PickIt disables: %u; PickIt state: %s",
        recovered::inventory_full_disable_count(),
        recovered::recovered_pickit_enabled() ? "enabled" : "disabled");
    logger::write(count_message);
    wsprintfA(count_message,
        "Recovered packet IDs: 0x51=%u 0xA7=%u 0x82=%u 0x5B=%u 0x2C=%u",
        recovered::packet_id_count(0x51), recovered::packet_id_count(0xa7),
        recovered::packet_id_count(0x82), recovered::packet_id_count(0x5b),
        recovered::packet_id_count(0x2c));
    logger::write(count_message);
    wsprintfA(count_message, "Unleashed packet mutations: %u; suppressions: %u",
        recovered::unleashed_packet_mutation_count(),
        recovered::unleashed_packet_suppression_count());
    logger::write(count_message);
    logger::write(recovered::remove_bh_passthrough_dispatcher()
        ? "BH original call restored"
        : "WARNING: BH original call was not restored because live bytes changed");
    running_ = false;
    module_ = nullptr;
    logger::close();
}

}  // namespace unleashed
