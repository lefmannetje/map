#pragma once

#include <string_view>
#include <windows.h>

namespace unleashed::logger {

bool open(HMODULE module) noexcept;
void write(std::string_view message) noexcept;
void close() noexcept;

}  // namespace unleashed::logger
