#include "core/logger.hpp"

#include <array>
#include <string>

namespace unleashed::logger {
namespace {

HANDLE log_file = INVALID_HANDLE_VALUE;
SRWLOCK log_lock = SRWLOCK_INIT;

std::string timestamp() noexcept {
    SYSTEMTIME time{};
    GetLocalTime(&time);
    std::array<char, 32> buffer{};
    const int length = wsprintfA(buffer.data(), "%04u-%02u-%02u %02u:%02u:%02u.%03u",
        time.wYear, time.wMonth, time.wDay, time.wHour, time.wMinute,
        time.wSecond, time.wMilliseconds);
    return std::string(buffer.data(), static_cast<std::size_t>(length));
}

}  // namespace

bool open(HMODULE module) noexcept {
    std::array<wchar_t, MAX_PATH> path{};
    const DWORD length = GetModuleFileNameW(module, path.data(), static_cast<DWORD>(path.size()));
    if (length == 0 || length >= path.size()) {
        return false;
    }

    wchar_t* separator = wcsrchr(path.data(), L'\\');
    if (separator == nullptr) {
        return false;
    }
    *(separator + 1) = L'\0';
    if (wcscat_s(path.data(), path.size(), L"Unleashed.log") != 0) {
        return false;
    }

    log_file = CreateFileW(path.data(), FILE_APPEND_DATA, FILE_SHARE_READ, nullptr,
        OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    return log_file != INVALID_HANDLE_VALUE;
}

void write(std::string_view message) noexcept {
    if (log_file == INVALID_HANDLE_VALUE) {
        return;
    }

    AcquireSRWLockExclusive(&log_lock);
    const std::string line = "[" + timestamp() + "] " + std::string(message) + "\r\n";
    DWORD written = 0;
    WriteFile(log_file, line.data(), static_cast<DWORD>(line.size()), &written, nullptr);
    FlushFileBuffers(log_file);
    ReleaseSRWLockExclusive(&log_lock);
}

void close() noexcept {
    AcquireSRWLockExclusive(&log_lock);
    if (log_file != INVALID_HANDLE_VALUE) {
        CloseHandle(log_file);
        log_file = INVALID_HANDLE_VALUE;
    }
    ReleaseSRWLockExclusive(&log_lock);
}

}  // namespace unleashed::logger
