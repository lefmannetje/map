#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <string_view>

namespace unleashed::bindings {

// Exact target supplied on 2026-08-19. Runtime binding must reject mismatched
// hashes before any patch is attempted.
struct TargetBuild final {
    static constexpr std::string_view game_sha256 =
        "74FE9C092A521F7710392548C82F81544E531107DB2358617E83818874DB40A2";
    static constexpr std::string_view d2client_sha256 =
        "DD8BC6025DE921216A97C17F97CD1A50FBB85926E838EC60E13451448836D906";
    static constexpr std::string_view d2common_sha256 =
        "59FA5928522F566F2BF99675571206AD70DF889C89D3D07FA87EDF5083E06E10";
    static constexpr std::string_view d2game_sha256 =
        "24B293B86F95BEA0228826C502EA04737BA21B91CA9832E52AAC4B11FEF14F53";
};

struct RecoveredHookSite final {
    std::uint32_t rva;
    std::array<std::uint8_t, 5> verified_original_bytes;
};

// Recovered directly from Unleashed.dll's binding routine at VA 0x10005280.
// Semantic names are deliberately deferred until each handler is fully traced.
inline constexpr std::array<RecoveredHookSite, 4> recovered_d2client_sites{{
    {0x0006264d, {0xe8, 0xae, 0xf6, 0xff, 0xff}},
    {0x000a9a27, {0xc6, 0x44, 0x24, 0x01, 0x00}},
    {0x0002929e, {0xe8, 0xed, 0xe7, 0xff, 0xff}},
    {0x000ace61, {0xe8, 0xe0, 0x03, 0xf6, 0xff}},
}};

// Observed in the fully loaded ProjectD2 process on 2026-08-19. These are
// compatibility constraints, not addresses to patch blindly:
//   0x6264D -> ProjectDiablo.dll (existing relative CALL)
//   0xACE61 -> BH.dll            (existing relative CALL)
// The remaining two sites matched the bytes above. Reconstruction must chain
// existing owners and must never overwrite them without preserving behavior.

}  // namespace unleashed::bindings
