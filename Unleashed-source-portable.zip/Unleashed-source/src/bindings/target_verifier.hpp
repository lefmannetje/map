#pragma once

#include <cstdint>

namespace unleashed::bindings {

enum class VerificationResult : std::uint8_t {
    verified,
    module_timeout,
    invalid_pe_image,
    unexpected_site_bytes,
};

VerificationResult wait_and_verify_d2client(std::uint32_t timeout_ms) noexcept;

}  // namespace unleashed::bindings
