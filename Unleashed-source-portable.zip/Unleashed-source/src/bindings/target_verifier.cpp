#include "bindings/target_verifier.hpp"

#include <cstring>
#include <cstdint>
#include <string>
#include <windows.h>

#include "bindings/target_build.hpp"
#include "core/logger.hpp"
#include "recovered/existing_chains.hpp"

namespace unleashed::bindings {
namespace {

bool valid_pe_image(const std::uint8_t* base) noexcept {
    if (base == nullptr) {
        return false;
    }
    const auto* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(base);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE || dos->e_lfanew <= 0) {
        return false;
    }
    const auto* nt = reinterpret_cast<const IMAGE_NT_HEADERS32*>(base + dos->e_lfanew);
    return nt->Signature == IMAGE_NT_SIGNATURE &&
        nt->OptionalHeader.Magic == IMAGE_NT_OPTIONAL_HDR32_MAGIC;
}

std::string hex_rva(std::uint32_t rva) {
    char buffer[16]{};
    wsprintfA(buffer, "0x%08X", rva);
    return buffer;
}

std::string hex_bytes(const std::uint8_t* bytes, std::size_t count) {
    static constexpr char digits[] = "0123456789ABCDEF";
    std::string result;
    result.reserve(count * 3);
    for (std::size_t index = 0; index < count; ++index) {
        if (!result.empty()) {
            result.push_back(' ');
        }
        result.push_back(digits[bytes[index] >> 4]);
        result.push_back(digits[bytes[index] & 0x0f]);
    }
    return result;
}

std::string call_target_owner(const std::uint8_t* instruction) {
    if (instruction[0] != 0xe8) {
        return "not a relative call";
    }
    std::int32_t displacement = 0;
    std::memcpy(&displacement, instruction + 1, sizeof(displacement));
    const auto* target = instruction + 5 + displacement;

    MEMORY_BASIC_INFORMATION memory{};
    if (VirtualQuery(target, &memory, sizeof(memory)) == 0 || memory.AllocationBase == nullptr) {
        return "target owner unavailable";
    }
    char module_path[MAX_PATH]{};
    if (GetModuleFileNameA(static_cast<HMODULE>(memory.AllocationBase), module_path, MAX_PATH) == 0) {
        return "target owner unavailable";
    }
    char address[24]{};
    wsprintfA(address, "0x%08X", static_cast<unsigned int>(
        reinterpret_cast<std::uintptr_t>(target)));
    return std::string("target=") + address + " owner=" + module_path;
}

bool matches_existing_chain(const std::uint8_t* instruction,
    std::uint32_t site_rva, const wchar_t* owner_name,
    const recovered::ExistingChainEvidence& chain) noexcept {
    if (site_rva != chain.d2client_site_rva || instruction[0] != 0xe8) {
        return false;
    }

    std::int32_t displacement = 0;
    std::memcpy(&displacement, instruction + 1, sizeof(displacement));
    const auto* target = instruction + 5 + displacement;
    MEMORY_BASIC_INFORMATION memory{};
    if (VirtualQuery(target, &memory, sizeof(memory)) == 0) {
        return false;
    }
    const HMODULE expected_owner = GetModuleHandleW(owner_name);
    if (expected_owner == nullptr || memory.AllocationBase != expected_owner) {
        return false;
    }
    const auto actual_rva = static_cast<std::uint32_t>(
        target - reinterpret_cast<const std::uint8_t*>(expected_owner));
    return actual_rva == chain.owner_handler_rva;
}

}  // namespace

VerificationResult wait_and_verify_d2client(std::uint32_t timeout_ms) noexcept {
    logger::write("Waiting for D2Client.dll");
    const ULONGLONG deadline = GetTickCount64() + timeout_ms;
    HMODULE module = nullptr;
    while (GetTickCount64() < deadline) {
        module = GetModuleHandleW(L"D2Client.dll");
        if (module != nullptr) {
            break;
        }
        Sleep(100);
    }
    if (module == nullptr) {
        logger::write("FAILED: D2Client.dll was not loaded before timeout");
        return VerificationResult::module_timeout;
    }

    const auto* base = reinterpret_cast<const std::uint8_t*>(module);
    if (!valid_pe_image(base)) {
        logger::write("FAILED: D2Client.dll is not a valid 32-bit PE image");
        return VerificationResult::invalid_pe_image;
    }

    bool all_sites_match = true;
    for (const auto& site : recovered_d2client_sites) {
        const auto* actual = base + site.rva;
        if (std::memcmp(actual, site.verified_original_bytes.data(),
                site.verified_original_bytes.size()) != 0) {
            const bool project_diablo_chain = matches_existing_chain(actual, site.rva,
                L"ProjectDiablo.dll", recovered::kProjectDiabloChain);
            const bool bh_chain = matches_existing_chain(actual, site.rva,
                L"BH.dll", recovered::kBhPacketChain);
            if (project_diablo_chain || bh_chain) {
                logger::write("Verified existing chain at D2Client RVA " +
                    hex_rva(site.rva));
                logger::write("  " + call_target_owner(actual));
            } else {
                all_sites_match = false;
                logger::write("MISMATCH D2Client RVA " + hex_rva(site.rva) +
                    " actual=[" + hex_bytes(actual, site.verified_original_bytes.size()) +
                    "] disk=[" + hex_bytes(site.verified_original_bytes.data(),
                        site.verified_original_bytes.size()) + "]");
                logger::write("  " + call_target_owner(actual));
            }
        } else {
            logger::write("Verified D2Client RVA " + hex_rva(site.rva));
        }
    }
    if (!all_sites_match) {
        logger::write("FAILED: one or more live D2Client sites were already modified");
        return VerificationResult::unexpected_site_bytes;
    }

    logger::write("Target and existing hook-chain verification passed; no hooks were installed");
    return VerificationResult::verified;
}

}  // namespace unleashed::bindings
