#pragma once

#include "core/feature.hpp"

namespace unleashed {

class MapReveal final : public Feature {
public:
    [[nodiscard]] std::string_view name() const noexcept override;
    [[nodiscard]] bool start() noexcept override;
    void stop() noexcept override;

private:
    bool delegated_to_project_diablo_ = false;
};

}  // namespace unleashed
