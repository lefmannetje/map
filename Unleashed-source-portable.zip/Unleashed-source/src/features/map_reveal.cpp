#include "features/map_reveal.hpp"

#include <cstdint>
#include <cstring>
#include <array>
#include <algorithm>
#include <unordered_set>
#include <vector>
#include <windows.h>

#include "core/config.hpp"
#include "core/logger.hpp"
#include "recovered/existing_chains.hpp"
#include "recovered/untouched_handlers.hpp"
#include "features/navigation_data.hpp"

namespace unleashed {
namespace {
#pragma pack(push, 1)
struct Level;
struct Room1;
struct Room2 {
    std::uint32_t unused0[2]; Room2** near_rooms; std::uint32_t unused1[5];
    void* type_info; Room2* next; std::uint32_t flags, near_count; Room1* room1;
    std::uint32_t x, y, size_x, size_y, unused2, preset_type; void* room_tiles;
    std::uint32_t unused3[2]; Level* level; void* presets;
};
struct UnitAny;
struct Room1 {
    std::uint32_t unused[4]; Room2* room2;
    std::uint8_t unused_after_room2[0x60];
    UnitAny* first_unit;
    std::uint32_t unused_after_first;
    Room1* next_active;
};
struct PresetUnit {
    std::uint32_t unused0, id, x; PresetUnit* next; std::uint32_t unused1, type, y;
};
struct RoomTile {
    Room2* room; RoomTile* next; std::uint32_t unused[2]; std::uint32_t* number;
};
struct ObjectData { void* text; std::uint8_t shrine_type; };
struct MonsterData {
    std::uint8_t unused[22];
    std::uint8_t flags;
};
struct UnitAny {
    std::uint32_t type, id, unused0, unit_id, mode;
    ObjectData* object_data;
    std::uint8_t unused1[0x14];
    void* path;
    std::uint8_t unused2a[0x5c];
    std::uint16_t x, y;
    std::uint8_t unused2[0x58];
    UnitAny* room_next;
};
struct Level {
    std::uint32_t unused0[4]; Room2* first_room; std::uint32_t unused1[102];
    Level* next; std::uint32_t unused2; void* act_misc; std::uint32_t unused3[6];
    std::uint32_t number;
};
#pragma pack(pop)

using AddRoomData = void(__stdcall*)(void*, int, int, int, Room1*);
using RemoveRoomData = void(__stdcall*)(void*, int, int, int, Room1*);
using RevealRoom = void(__stdcall*)(Room1*, std::uint32_t, void*);
using DrawLine = void(__stdcall*)(int, int, int, int, std::uint32_t, std::uint32_t);
using MapToAbsScreen = void(__stdcall*)(long*, long*);
using DrawText = void(__fastcall*)(wchar_t*, int, int, std::uint32_t, std::uint32_t);
using SetTextSize = std::uint32_t(__fastcall*)(std::uint32_t);
using GetCurrentNpc = void*(__fastcall*)();
using GetUnitStat = std::uint32_t(__stdcall*)(void*, std::uint32_t, std::uint32_t);
using DrawRectangle = void(__stdcall*)(int, int, int, int, std::uint32_t, std::uint32_t);
using GetItemName = BOOL(__stdcall*)(void*, wchar_t*, std::uint32_t);
using IsMatchingType = BOOL(__stdcall*)(void*, int);

#pragma pack(push, 1)
struct Inventory {
    std::uint32_t signature; void* game; void* owner; void* first_item;
    void* last_item;
};
struct ItemData {
    std::uint8_t unused[0x64];
    void* next_inventory_item;
};
struct InventoryLayout {
    std::uint8_t slot_width, slot_height, unused0, unused1;
    std::uint32_t left, right, top, bottom;
    std::uint8_t pixel_width, pixel_height;
};
#pragma pack(pop)

void** player_slot = nullptr;
void** layer_slot = nullptr;
AddRoomData add_room = nullptr;
RemoveRoomData remove_room = nullptr;
RevealRoom reveal_room = nullptr;
DrawLine draw_line = nullptr;
MapToAbsScreen map_to_screen = nullptr;
int* automap_mode = nullptr;
POINT* automap_offset = nullptr;
BOOL* automap_on = nullptr;
DrawText draw_text = nullptr;
SetTextSize set_text_size = nullptr;
GetCurrentNpc get_current_npc = nullptr;
GetUnitStat get_unit_stat = nullptr;
DrawRectangle draw_rectangle = nullptr;
InventoryLayout* store_layout = nullptr;
GetItemName get_item_name = nullptr;
IsMatchingType is_matching_type = nullptr;
Level* last_level = nullptr;
DWORD next_tick = 0;
DWORD next_monster_tick = 0;
DWORD next_dynamic_tick = 0;
int passes = 0;
volatile long revealed = 0;
POINT selected_target{};
int selected_key = -1;
bool selected_target_valid = false;
std::array<bool, 4> num_down{};
bool num5_down = false;
// 0 = all, 1 = bosses/special minions, 2 = bosses only, 3 = none.
int monster_marker_mode = 0;
struct ShrineMarker { POINT point; std::uint32_t object_id; std::uint8_t effect; };
std::vector<ShrineMarker> shrine_markers;
enum class MonsterMarkerKind : std::uint8_t {
    minion, champion, unique, act_boss, uber
};
struct SpecialMonster { POINT point; MonsterMarkerKind kind; };
std::vector<SpecialMonster> special_monsters;
std::vector<POINT> normal_monsters;
std::vector<POINT> special_chests;
struct ContainerMarker { POINT point; std::uint32_t object_id; };
std::vector<ContainerMarker> normal_containers;
std::vector<POINT> opened_containers;
std::vector<POINT> waypoint_markers;
struct PendingShrineRoom {
    void* act;
    Room2* room;
    std::uint32_t level, x, y;
    DWORD ready_at;
};
std::vector<PendingShrineRoom> pending_shrine_rooms;
std::unordered_set<std::uint64_t> processed_rooms;

std::uint64_t room_key(const Room2* room) noexcept {
    return (static_cast<std::uint64_t>(room->x) << 32) |
        static_cast<std::uint64_t>(room->y);
}

struct SkillTreeGroup {
    int tab;
    const int* skills;
    std::size_t count;
};
#define SKILLS(name, ...) static constexpr int name[]{__VA_ARGS__}
SKILLS(asn1,254,255,260,259,265,269,270,275,274,280);
SKILLS(asn2,252,253,258,263,264,273,267,268,279,278);
SKILLS(asn3,251,256,257,261,262,266,277,366,272,271,276);
SKILLS(bar1,130,131,138,154,142,137,149,150,155,146);
SKILLS(bar2,128,135,134,141,145,148,153,368);
SKILLS(bar3,126,133,147,139,144,140,132,143,152,151,375);
SKILLS(dru1,225,230,229,235,234,240,370,244,245,250,249);
SKILLS(dru2,223,228,224,232,233,242,238,243,239,248);
SKILLS(dru3,221,222,236,227,231,246,237,241,226,247);
SKILLS(nec1,70,69,75,80,79,85,367,90,89,94,95);
SKILLS(nec2,67,73,68,74,78,83,84,88,92,93);
SKILLS(nec3,66,374,71,381,76,82,77,72,81,86,87,91);
SKILLS(pal1,99,100,105,110,104,109,115,120,124,125);
SKILLS(pal2,98,102,103,108,113,114,118,119,122,123);
SKILLS(pal3,96,101,97,106,371,107,111,112,116,378,121,117,364);
SKILLS(sor1,39,40,44,45,50,55,60,369,59,64,65);
SKILLS(sor2,38,43,42,48,49,54,53,57,58,63);
SKILLS(sor3,36,37,41,46,51,47,383,52,56,376,62,61);
#undef SKILLS
#define GROUP(tab, name) {tab, name, std::size(name)}
static constexpr SkillTreeGroup skill_groups[]{
    GROUP(50,asn1),GROUP(49,asn2),GROUP(48,asn3),
    GROUP(34,bar1),GROUP(33,bar2),GROUP(32,bar3),
    GROUP(42,dru1),GROUP(41,dru2),GROUP(40,dru3),
    GROUP(18,nec1),GROUP(17,nec2),GROUP(16,nec3),
    GROUP(26,pal1),GROUP(25,pal2),GROUP(24,pal3),
    GROUP(10,sor1),GROUP(9,sor2),GROUP(8,sor3)
};
#undef GROUP

bool has_plus_three(void* item, const int* skills, std::size_t count) noexcept {
    for (std::size_t i = 0; i < count; ++i)
        if (get_unit_stat(item, 107, skills[i]) >= 3) return true;
    return false;
}

int shop_winner_kind(void* item) noexcept {
    if (!item || !get_unit_stat) return 0;
    for (const auto& group : skill_groups) {
        if (get_unit_stat(item, 188, group.tab) >= 3 &&
            has_plus_three(item, group.skills, group.count)) return 6;
    }
    // Amazon tab bonuses can be granted directly at +6 on class-specific gear.
    for (int tab = 0; tab <= 2; ++tab)
        if (get_unit_stat(item, 188, tab) >= 6) return 6;
    if (get_unit_stat(item, 83, 2) >= 2 &&
        (has_plus_three(item, nec1, std::size(nec1)) ||
         has_plus_three(item, nec2, std::size(nec2)) ||
         has_plus_three(item, nec3, std::size(nec3)))) return 5;

    if (is_matching_type) {
        constexpr int item_type_gloves = 16;
        constexpr int item_type_javelin = 44;
        constexpr int item_type_claw = 67;
        constexpr int item_type_claw2 = 88;
        constexpr int stat_ias = 93;
        // The strongest currently shopped 3/20 gloves: Bow, Javelin and MA.
        if (is_matching_type(item, item_type_gloves) &&
            get_unit_stat(item, stat_ias, 0) >= 20 &&
            (get_unit_stat(item, 188, 0) >= 3 ||
             get_unit_stat(item, 188, 2) >= 3 ||
             get_unit_stat(item, 188, 50) >= 3)) return 320;
        // Lancer's javelins of Quickness.
        if (is_matching_type(item, item_type_javelin) &&
            get_unit_stat(item, stat_ias, 0) >= 40 &&
            get_unit_stat(item, 188, 2) >= 3) return 340;
        // Cunning claws of Quickness; +6 staffmod claws are caught above.
        if ((is_matching_type(item, item_type_claw) ||
             is_matching_type(item, item_type_claw2)) &&
            get_unit_stat(item, stat_ias, 0) >= 40 &&
            get_unit_stat(item, 188, 48) >= 3) return 340;
    }
    return 0;
}

void draw_shop_winners() noexcept {
    if (!get_current_npc || !draw_rectangle || !draw_text || !set_text_size ||
        !store_layout) return;
    auto* npc = static_cast<std::uint8_t*>(get_current_npc());
    if (!npc) return;
    auto* inventory = *reinterpret_cast<Inventory**>(npc + 0x60);
    if (!inventory || !inventory->first_item) return;
    int winners = 0;
    wchar_t winner_name[96]{};
    const bool bright_phase = ((GetTickCount() / 350) & 1) == 0;
    void* raw = inventory->first_item;
    for (int guard = 0; raw && guard < 512; ++guard) {
        auto* item = static_cast<std::uint8_t*>(raw);
        auto* data = *reinterpret_cast<ItemData**>(item + 0x14);
        if (!data) break;
        const int kind = shop_winner_kind(item);
        if (kind) {
            ++winners;
            if (winners == 1 && get_item_name) {
                wchar_t raw_name[128]{};
                if (get_item_name(item, raw_name, std::size(raw_name))) {
                    std::size_t out = 0;
                    for (std::size_t in = 0; raw_name[in] && out + 1 < std::size(winner_name); ++in) {
                        if (raw_name[in] == L'\n' || raw_name[in] == L'\r') break;
                        // Diablo color controls are 0xFF, 'c', then one color byte.
                        if (raw_name[in] == 0xff && raw_name[in + 1] == L'c' && raw_name[in + 2]) {
                            in += 2;
                            continue;
                        }
                        winner_name[out++] = raw_name[in];
                    }
                    winner_name[out] = 0;
                }
            }
            const int col = *reinterpret_cast<std::uint16_t*>(item + 0x8c);
            const int row = *reinterpret_cast<std::uint16_t*>(item + 0x8e);
            const int x1 = static_cast<int>(store_layout->left) +
                col * store_layout->pixel_width;
            const int y1 = static_cast<int>(store_layout->top) +
                row * store_layout->pixel_height;
            const int x2 = x1 + std::max<int>(store_layout->pixel_width, 28);
            const int y2 = y1 + std::max<int>(store_layout->pixel_height, 28);
            // Draw only the four edges so the item remains fully visible.
            // Alternate yellow/white to make the location unmistakably flash.
            const std::uint32_t color = bright_phase ? 0x0d : 0x00;
            constexpr int thickness = 3;
            draw_rectangle(x1, y1, x2, y1 + thickness, color, 1);
            draw_rectangle(x1, y2 - thickness, x2, y2, color, 1);
            draw_rectangle(x1, y1, x1 + thickness, y2, color, 1);
            draw_rectangle(x2 - thickness, y1, x2, y2, color, 1);
        }
        raw = data->next_inventory_item;
    }
    if (winners) {
        wchar_t message[180]{};
        if (winner_name[0] && winners == 1)
            wsprintfW(message, L"SHOP WINNER: %s", winner_name);
        else if (winner_name[0])
            wsprintfW(message, L"SHOP WINNERS (%d), FIRST: %s", winners, winner_name);
        else
            wsprintfW(message, L"SHOP WINNER FOUND (%d)", winners);
        const auto old = set_text_size(1);
        draw_text(message, 20, 135, 0x0d, 0);
        set_text_size(old);
    }
}

bool is_cow(std::uint32_t class_id) noexcept {
    static constexpr std::array<std::uint32_t, 4> ids{391, 826, 827, 828};
    return std::find(ids.begin(), ids.end(), class_id) != ids.end();
}

bool is_special_chest(std::uint32_t id) noexcept {
    return id == 371 || id == 397 || id == 455 || id == 580;
}

bool is_normal_container(std::uint32_t id) noexcept {
    // ProjectD2 official normal chests, stashes, coffins/sarcophagi, plus
    // Loose Boulder (175). Barrels are intentionally excluded.
    static constexpr auto ids = std::array{
        5u,6u,87u,88u,89u,125u,127u,128u,139u,140u,141u,144u,146u,
        147u,148u,155u,159u,175u,176u,177u,181u,182u,183u,185u,186u,
        187u,188u,198u,203u,204u,205u,240u,241u,242u,243u,274u,284u,
        329u,330u,331u,332u,333u,334u,335u,336u,354u,355u,356u,372u,
        387u,389u,390u,391u,405u,406u,407u,413u,416u,420u,424u,425u,
        430u,431u,432u,433u,463u,501u,502u,504u,505u,588u};
    return std::find(ids.begin(), ids.end(), id) != ids.end();
}

bool point_is_opened(const POINT& point) noexcept {
    return std::any_of(opened_containers.begin(), opened_containers.end(),
        [&](const POINT& opened) {
            return std::abs(opened.x - point.x) <= 2 &&
                std::abs(opened.y - point.y) <= 2;
        });
}

bool is_act_boss(std::uint32_t class_id) noexcept {
    static constexpr std::array<std::uint32_t, 5> ids{
        156, 211, 242, 243, 544};
    return std::find(ids.begin(), ids.end(), class_id) != ids.end();
}

bool is_known_uber(std::uint32_t class_id) noexcept {
    // ProjectD2 official MonStats IDs: Diablo Clone, Pandemonium Ubers,
    // new Uber Diablo/souls, and Uber Ancients.
    static constexpr std::array<std::uint32_t, 17> ids{
        333, 704, 705, 706, 707, 708, 709, 789, 790,
        791, 792, 793, 794, 989, 990, 991, 755};
    return std::find(ids.begin(), ids.end(), class_id) != ids.end();
}

bool is_waypoint_object(std::uint32_t id) noexcept {
    static constexpr std::array<std::uint32_t, 17> ids{
        119,157,156,323,288,402,324,237,238,398,496,511,494,392,394,396,255};
    return std::find(ids.begin(), ids.end(), id) != ids.end();
}

bool is_shrine_or_well(std::uint32_t id) noexcept {
    // Extracted from ProjectD2's active official Objects.txt. These entries are
    // named as shrines or wells, including the act-specific visual variants.
    static constexpr std::array<std::uint32_t, 102> ids{
        2,77,81,83,84,85,93,96,97,109,111,113,115,116,118,123,124,130,
        132,133,134,135,136,137,138,150,151,164,165,166,167,168,170,172,
        173,184,190,191,197,199,200,201,202,206,226,231,232,236,249,260,
        262,263,264,265,275,276,277,278,279,280,281,282,299,300,302,303,
        320,322,325,343,344,361,414,415,421,422,423,426,427,428,464,465,
        472,479,483,484,488,491,492,493,495,497,498,499,503,509,512,513,
        519,520,521,522};
    return std::binary_search(ids.begin(), ids.end(), id);
}

bool room_has_shrine(Room2* room) noexcept {
    if (!room) return false;
    for (auto* preset = static_cast<PresetUnit*>(room->presets);
         preset; preset = preset->next) {
        if (preset->type == 2 && is_shrine_or_well(preset->id)) return true;
    }
    return false;
}

void capture_shrine_effects(Room1* room) noexcept;

void finish_pending_shrine_rooms(DWORD now) noexcept {
    for (auto it = pending_shrine_rooms.begin();
         it != pending_shrine_rooms.end();) {
        if (static_cast<LONG>(now - it->ready_at) < 0) {
            ++it;
            continue;
        }
        if (it->room && it->room->room1)
            capture_shrine_effects(it->room->room1);
        if (remove_room && it->act)
            remove_room(it->act, static_cast<int>(it->level),
                static_cast<int>(it->x), static_cast<int>(it->y), nullptr);
        it = pending_shrine_rooms.erase(it);
    }
}

void capture_shrines(Room2* room) {
    if (!room) return;
    for (auto* preset = static_cast<PresetUnit*>(room->presets);
         preset; preset = preset->next) {
        if (preset->type != 2 || !is_shrine_or_well(preset->id)) continue;
        POINT point{static_cast<LONG>(room->x * 5 + preset->x),
            static_cast<LONG>(room->y * 5 + preset->y)};
        const bool exists = std::any_of(shrine_markers.begin(), shrine_markers.end(),
            [&](const ShrineMarker& old) {
                return old.point.x == point.x && old.point.y == point.y;
            });
        if (!exists) shrine_markers.push_back({point, preset->id, 0});
    }
}

void capture_special_chests(Room2* room) {
    if (!room) return;
    for (auto* preset = static_cast<PresetUnit*>(room->presets);
         preset; preset = preset->next) {
        // Countess chest, small/large sparkly chest, and super chest.
        if (preset->type != 2 || !is_special_chest(preset->id)) continue;
        POINT point{static_cast<LONG>(room->x * 5 + preset->x),
            static_cast<LONG>(room->y * 5 + preset->y)};
        const bool exists = std::any_of(special_chests.begin(), special_chests.end(),
            [&](const POINT& old) { return old.x == point.x && old.y == point.y; });
        if (!exists) special_chests.push_back(point);
    }
}

void capture_normal_containers(Room2* room) {
    if (!room) return;
    for (auto* preset = static_cast<PresetUnit*>(room->presets);
         preset; preset = preset->next) {
        if (preset->type != 2 || !is_normal_container(preset->id)) continue;
        POINT point{static_cast<LONG>(room->x * 5 + preset->x),
            static_cast<LONG>(room->y * 5 + preset->y)};
        const bool exists = std::any_of(normal_containers.begin(),
            normal_containers.end(), [&](const ContainerMarker& old) {
                return old.point.x == point.x && old.point.y == point.y;
            });
        if (!exists) normal_containers.push_back({point, preset->id});
    }
}

void capture_container_states(Room1* room) noexcept {
    if (!room) return;
    int guard = 0;
    for (UnitAny* unit = room->first_unit; unit && guard++ < 2048;
         unit = unit->room_next) {
        if (unit->type != 2 || !unit->path ||
            (!is_normal_container(unit->id) && !is_special_chest(unit->id)))
            continue;
        const auto* path = static_cast<const std::uint8_t*>(unit->path);
        POINT point{
            static_cast<LONG>(*reinterpret_cast<const std::uint32_t*>(path + 0x0c)),
            static_cast<LONG>(*reinterpret_cast<const std::uint32_t*>(path + 0x10))};
        if (unit->mode != 0) {
            if (!point_is_opened(point)) opened_containers.push_back(point);
        } else if (is_normal_container(unit->id)) {
            const bool exists = std::any_of(normal_containers.begin(),
                normal_containers.end(), [&](const ContainerMarker& old) {
                    return std::abs(old.point.x - point.x) <= 2 &&
                        std::abs(old.point.y - point.y) <= 2;
                });
            if (!exists) normal_containers.push_back({point, unit->id});
        }
    }
}

void capture_waypoints(Room2* room) {
    if (!room) return;
    for (auto* preset = static_cast<PresetUnit*>(room->presets);
         preset; preset = preset->next) {
        if (preset->type != 2 || !is_waypoint_object(preset->id)) continue;
        POINT point{static_cast<LONG>(room->x * 5 + preset->x),
            static_cast<LONG>(room->y * 5 + preset->y)};
        const bool exists = std::any_of(waypoint_markers.begin(), waypoint_markers.end(),
            [&](const POINT& old) { return old.x == point.x && old.y == point.y; });
        if (!exists) waypoint_markers.push_back(point);
    }
}

void capture_shrine_effects(Room1* room) noexcept {
    if (!room) return;
    int guard = 0;
    for (UnitAny* unit = room->first_unit; unit && guard++ < 2048;
         unit = unit->room_next) {
        if (unit->type != 2 || !unit->object_data || !is_shrine_or_well(unit->id))
            continue;
        if (!unit->path) continue;
        const auto* object_path = static_cast<const std::uint8_t*>(unit->path);
        const auto object_x = *reinterpret_cast<const std::uint32_t*>(object_path + 0x0c);
        const auto object_y = *reinterpret_cast<const std::uint32_t*>(object_path + 0x10);
        auto found = std::find_if(shrine_markers.begin(), shrine_markers.end(),
            [&](const ShrineMarker& marker) {
                return std::abs(marker.point.x - static_cast<LONG>(object_x)) <= 2 &&
                    std::abs(marker.point.y - static_cast<LONG>(object_y)) <= 2;
            });
        if (found != shrine_markers.end()) {
            found->effect = unit->object_data->shrine_type;
        } else {
            // Some active rooms (notably Act 3) no longer expose the preset
            // that was used to create the shrine. Create its map marker from
            // the live object instead of requiring a preset marker first.
            shrine_markers.push_back({
                {static_cast<LONG>(object_x), static_cast<LONG>(object_y)},
                unit->id, unit->object_data->shrine_type});
        }
    }
}

void refresh_shrine_effects(std::uint8_t* player) noexcept {
    auto* act = *reinterpret_cast<std::uint8_t**>(player + 0x1c);
    if (!act) return;
    Room1* room = *reinterpret_cast<Room1**>(act + 0x10);
    int guard = 0;
    while (room && guard++ < 256) {
        capture_shrine_effects(room);
        capture_container_states(room);
        room = room->next_active;
    }
}

std::uint32_t tile_destination(Room2* room, std::uint32_t tile_id) noexcept {
    for (auto* tile = static_cast<RoomTile*>(room->room_tiles); tile; tile = tile->next) {
        if (tile->number && *tile->number == tile_id && tile->room && tile->room->level)
            return tile->room->level->number;
    }
    return 0;
}

bool resolve_target(std::uint8_t* player, Level* level,
    const navigation_data::Target& target, POINT& point) noexcept {
    if (target.type == 0) return false;
    // Type 8 is the Act 2 true tomb selected for this game. The value is
    // stored in ActMisc::dwStaffTombLevel and changes between games.
    if (target.type == 8) {
        if (!level->act_misc) return false;
        const auto* misc = static_cast<const std::uint8_t*>(level->act_misc);
        const std::uint32_t true_tomb =
            *reinterpret_cast<const std::uint32_t*>(misc + 0x94);
        if (true_tomb < 66 || true_tomb > 72) return false;
        return resolve_target(player, level,
            navigation_data::Target{6u, true_tomb, 0u, 0u}, point);
    }
    void* act = *reinterpret_cast<void**>(player + 0x1c);
    if (!act) return false;
    for (Room2* room = level->first_room; room; room = room->next) {
        const bool added = room->room1 == nullptr;
        if (added) add_room(act, static_cast<int>(level->number),
            static_cast<int>(room->x), static_cast<int>(room->y), nullptr);
        bool found = false;
        for (auto* preset = static_cast<PresetUnit*>(room->presets);
             preset; preset = preset->next) {
            if ((target.type == preset->type && target.id == preset->id) ||
                (target.type == 6 && preset->type == 5 &&
                    tile_destination(room, preset->id) == target.id)) {
                point.x = static_cast<LONG>(room->x * 5 + preset->x);
                point.y = static_cast<LONG>(room->y * 5 + preset->y);
                found = true;
                break;
            }
        }
        if (!found && target.type == 6 && room->near_rooms) {
            for (std::uint32_t i = 0; i < room->near_count; ++i) {
                Room2* adjacent = room->near_rooms[i];
                if (adjacent && adjacent->level && adjacent->level->number == target.id) {
                    point.x = static_cast<LONG>(room->x * 5 + room->size_x * 5 / 2);
                    point.y = static_cast<LONG>(room->y * 5 + room->size_y * 5 / 2);
                    found = true;
                    break;
                }
            }
        }
        if (added) remove_room(act, static_cast<int>(level->number),
            static_cast<int>(room->x), static_cast<int>(room->y), nullptr);
        if (found) return true;
    }
    return false;
}

POINT to_automap(long x, long y) noexcept {
    map_to_screen(&x, &y);
    const int scale = automap_mode && *automap_mode ? *automap_mode : 1;
    return {x / scale - automap_offset->x + 8,
        y / scale - automap_offset->y - 8};
}

void draw_shrines() noexcept {
    if (!automap_on || !*automap_on || !draw_line || !map_to_screen ||
        !automap_offset) return;
    for (const ShrineMarker& marker : shrine_markers) {
        const POINT p = to_automap(marker.point.x, marker.point.y);
        // A compact gold diamond remains recognizable at every automap scale.
        constexpr std::uint32_t color = 0x0d;
        constexpr int radius = 4;
        draw_line(p.x, p.y - radius, p.x + radius, p.y, color, 0xff);
        draw_line(p.x + radius, p.y, p.x, p.y + radius, color, 0xff);
        draw_line(p.x, p.y + radius, p.x - radius, p.y, color, 0xff);
        draw_line(p.x - radius, p.y, p.x, p.y - radius, color, 0xff);
        if (draw_text && set_text_size) {
            wchar_t health[] = L"HP";
            wchar_t mana[] = L"MA";
            wchar_t armor[] = L"AR";
            wchar_t combat[] = L"CO";
            wchar_t skill[] = L"SK";
            wchar_t stamina[] = L"ST";
            wchar_t experience[] = L"XP";
            wchar_t gem[] = L"GEM";
            wchar_t well[] = L"W";
            wchar_t* label = nullptr;
            if (marker.effect == 2) label = health;
            else if (marker.effect == 6) label = armor;
            else if (marker.effect == 7) label = combat;
            else if (marker.effect == 12) label = skill;
            else if (marker.effect == 13) label = mana;
            else if (marker.effect == 14) label = stamina;
            else if (marker.effect == 15) label = experience;
            else if (marker.effect == 18) label = gem;
            else if (marker.object_id == 111 || marker.object_id == 113 ||
                marker.object_id == 115 || marker.object_id == 118 ||
                marker.object_id == 130 || marker.object_id == 132 ||
                marker.object_id == 137 || marker.object_id == 138 ||
                marker.object_id == 322 || marker.object_id == 426 ||
                marker.object_id == 493 || marker.object_id == 498 ||
                marker.object_id == 513 || marker.object_id == 519) label = well;
            if (label) {
                const std::uint32_t old_size = set_text_size(6);
                draw_text(label, p.x - 6, p.y - 7, color, 0);
                set_text_size(old_size);
            }
        }
    }
}

void refresh_special_monsters(std::uint8_t* player,
    std::uint32_t level_number) noexcept {
    special_monsters.clear();
    normal_monsters.clear();
    const bool show_white_cows = level_number == 39;
    auto* act = *reinterpret_cast<std::uint8_t**>(player + 0x1c);
    if (!act) return;
    Room1* room = *reinterpret_cast<Room1**>(act + 0x10);
    int room_guard = 0;
    while (room && room_guard++ < 256) {
        int unit_guard = 0;
        for (UnitAny* unit = room->first_unit; unit && unit_guard++ < 4096;
             unit = unit->room_next) {
            // Monster modes 0 and 12 are death animation and corpse.
            if (unit->type != 1 || !unit->object_data ||
                unit->mode == 0 || unit->mode == 12) continue;
            const auto* monster = reinterpret_cast<const MonsterData*>(unit->object_data);
            // Bits 2, 3 and 4 are champion, unique/boss and unique-pack minion.
            if ((monster->flags & 0x1c) == 0) {
                if (show_white_cows && is_cow(unit->id)) {
                    normal_monsters.push_back(
                        {static_cast<LONG>(unit->x), static_cast<LONG>(unit->y)});
                }
                continue;
            }
            const bool minion = (monster->flags & 0x10) != 0;
            if (minion) continue;
            MonsterMarkerKind kind = MonsterMarkerKind::unique;
            if (minion) kind = MonsterMarkerKind::minion;
            else if (is_known_uber(unit->id)) kind = MonsterMarkerKind::uber;
            else if (is_act_boss(unit->id)) kind = MonsterMarkerKind::act_boss;
            else if ((monster->flags & 0x04) != 0)
                kind = MonsterMarkerKind::champion;
            special_monsters.push_back({
                {static_cast<LONG>(unit->x), static_cast<LONG>(unit->y)},
                kind});
        }
        room = room->next_active;
    }
}

void monster_marker_toggle_frame() noexcept {
    const bool down = (GetAsyncKeyState(VK_NUMPAD5) & 0x8000) != 0;
    if (down && !num5_down) {
        monster_marker_mode = (monster_marker_mode + 1) % 4;
        normal_monsters.clear();
        special_monsters.clear();
        next_monster_tick = GetTickCount();
        static constexpr const char* names[4]{
            "all", "bosses and special minions", "bosses only", "none"};
        char message[96]{};
        wsprintfA(message, "Num5 monster markers: %s", names[monster_marker_mode]);
        logger::write(message);
    }
    num5_down = down;
}

void draw_monster_marker_mode() noexcept {
    if (!automap_on || !*automap_on || !draw_text || !set_text_size) return;
    wchar_t all[] = L"MOBS: ALL";
    wchar_t special[] = L"MOBS: SPECIAL";
    wchar_t bosses[] = L"MOBS: BOSS";
    wchar_t off[] = L"MOBS: OFF";
    wchar_t* labels[4]{all, special, bosses, off};
    static constexpr std::uint32_t colors[4]{0xd0, 0x9b, 0x0a, 0x84};
    const std::uint32_t old_size = set_text_size(1);
    draw_text(labels[monster_marker_mode], 15, 90,
        colors[monster_marker_mode], 0);
    set_text_size(old_size);
}

void draw_normal_monsters() noexcept {
    if (!automap_on || !*automap_on || !draw_line || !map_to_screen ||
        !automap_offset) return;
    constexpr std::uint32_t color = 0xd0;
    constexpr std::uint32_t outline = 0x00;
    constexpr int radius = 3;
    for (const POINT& monster : normal_monsters) {
        const POINT p = to_automap(monster.x, monster.y);
        for (int offset = -1; offset <= 1; ++offset) {
            draw_line(p.x - radius - 1, p.y + offset,
                p.x + radius + 1, p.y + offset, outline, 0xff);
            draw_line(p.x + offset, p.y - radius - 1,
                p.x + offset, p.y + radius + 1, outline, 0xff);
        }
        draw_line(p.x - radius, p.y, p.x + radius, p.y, color, 0xff);
        draw_line(p.x, p.y - radius, p.x, p.y + radius, color, 0xff);
    }
}

void draw_special_monsters() noexcept {
    if (!automap_on || !*automap_on || !draw_line || !map_to_screen ||
        !automap_offset) return;
    constexpr int radius = 5;
    for (const SpecialMonster& monster : special_monsters) {
        std::uint32_t color = 0x0d;  // unique/super-unique: orange/gold
        if (monster.kind == MonsterMarkerKind::minion) color = 0x9b;
        else if (monster.kind == MonsterMarkerKind::champion) color = 0x97;
        else if (monster.kind == MonsterMarkerKind::act_boss) color = 0x0a;
        else if (monster.kind == MonsterMarkerKind::uber) color = 0x9b;
        const POINT p = to_automap(monster.point.x, monster.point.y);
        constexpr std::uint32_t outline = 0x00;
        for (int offset = -1; offset <= 1; ++offset) {
            draw_line(p.x - radius - 1, p.y + offset,
                p.x + radius + 1, p.y + offset, outline, 0xff);
            draw_line(p.x + offset, p.y - radius - 1,
                p.x + offset, p.y + radius + 1, outline, 0xff);
            draw_line(p.x - 4, p.y - 4 + offset,
                p.x + 4, p.y + 4 + offset, outline, 0xff);
            draw_line(p.x + 4, p.y - 4 + offset,
                p.x - 4, p.y + 4 + offset, outline, 0xff);
        }
        draw_line(p.x - radius, p.y, p.x + radius, p.y, color, 0xff);
        draw_line(p.x, p.y - radius, p.x, p.y + radius, color, 0xff);
        draw_line(p.x - 3, p.y - 3, p.x + 3, p.y + 3, color, 0xff);
        draw_line(p.x + 3, p.y - 3, p.x - 3, p.y + 3, color, 0xff);
    }
}

void draw_special_chests() noexcept {
    if (!automap_on || !*automap_on || !draw_line || !map_to_screen ||
        !automap_offset) return;
    constexpr std::uint32_t color = 0x97;
    constexpr int radius = 7;
    for (const POINT& chest : special_chests) {
        if (point_is_opened(chest)) continue;
        const POINT p = to_automap(chest.x, chest.y);
        // Three parallel strokes per diagonal make special chests stand out
        // without increasing the size of monster markers.
        for (int offset = -1; offset <= 1; ++offset) {
            draw_line(p.x - radius, p.y - radius + offset,
                p.x + radius, p.y + radius + offset, color, 0xff);
            draw_line(p.x + radius, p.y - radius + offset,
                p.x - radius, p.y + radius + offset, color, 0xff);
        }
    }
}

void draw_normal_containers() noexcept {
    if (!automap_on || !*automap_on || !draw_line || !map_to_screen ||
        !automap_offset) return;
    constexpr std::uint32_t color = 0x9b;
    constexpr int radius = 3;
    for (const ContainerMarker& marker : normal_containers) {
        if (point_is_opened(marker.point)) continue;
        const POINT p = to_automap(marker.point.x, marker.point.y);
        draw_line(p.x - radius, p.y - radius,
            p.x + radius, p.y + radius, color, 0xff);
        draw_line(p.x + radius, p.y - radius,
            p.x - radius, p.y + radius, color, 0xff);
    }
}

void draw_waypoints() noexcept {
    if (!automap_on || !*automap_on || !draw_line || !map_to_screen ||
        !automap_offset) return;
    constexpr std::uint32_t color = 0x84;
    constexpr int radius = 5;
    for (const POINT& waypoint : waypoint_markers) {
        const POINT p = to_automap(waypoint.x, waypoint.y);
        draw_line(p.x - radius, p.y - radius, p.x + radius, p.y - radius, color, 0xff);
        draw_line(p.x + radius, p.y - radius, p.x + radius, p.y + radius, color, 0xff);
        draw_line(p.x + radius, p.y + radius, p.x - radius, p.y + radius, color, 0xff);
        draw_line(p.x - radius, p.y + radius, p.x - radius, p.y - radius, color, 0xff);
        if (draw_text && set_text_size) {
            wchar_t label[] = L"WP";
            const std::uint32_t old_size = set_text_size(6);
            draw_text(label, p.x - 6, p.y - 7, color, 0);
            set_text_size(old_size);
        }
    }
}

void navigation_frame(std::uint8_t* player, Level* level) noexcept {
    static constexpr int keys[4]{VK_NUMPAD1, VK_NUMPAD2, VK_NUMPAD3, VK_NUMPAD4};
    for (int i = 0; i < 4; ++i) {
        const bool down = (GetAsyncKeyState(keys[i]) & 0x8000) != 0;
        if (down && !num_down[i] &&
            level->number < navigation_data::targets.size()) {
            POINT candidate{};
            const auto& descriptor = navigation_data::targets[level->number][i];
            if (resolve_target(player, level, descriptor, candidate)) {
                selected_target = candidate;
                selected_key = i;
                selected_target_valid = true;
                char message[96]{};
                wsprintfA(message, "Num%d target selected: type %u id %u at %ld,%ld",
                    i + 1, descriptor.type, descriptor.id, candidate.x, candidate.y);
                logger::write(message);
            } else {
                selected_key = i;
                selected_target_valid = false;
                char message[80]{};
                wsprintfA(message, "Num%d target unavailable: type %u id %u",
                    i + 1, descriptor.type, descriptor.id);
                logger::write(message);
            }
        }
        num_down[i] = down;
    }
    if (selected_key < 0 || !selected_target_valid ||
        !automap_on || !*automap_on || !draw_line ||
        !map_to_screen || !automap_offset) return;
    auto* path = *reinterpret_cast<std::uint8_t**>(player + 0x2c);
    if (!path) return;
    const long player_x = *reinterpret_cast<std::uint16_t*>(path + 2);
    const long player_y = *reinterpret_cast<std::uint16_t*>(path + 6);
    const POINT from = to_automap(player_x, player_y);
    const POINT to = to_automap(selected_target.x, selected_target.y);
    static constexpr std::uint32_t colors[4]{0x97, 0x0a, 0x84, 0x0d};
    draw_line(from.x, from.y, to.x, to.y, colors[selected_key], 0xff);
}

void reveal_frame() noexcept {
    draw_shop_winners();
    if (!player_slot || !layer_slot || !*player_slot || !*layer_slot) {
        last_level = nullptr; passes = 0; return;
    }
    auto* player = static_cast<std::uint8_t*>(*player_slot);
    auto* path = *reinterpret_cast<std::uint8_t**>(player + 0x2c);
    if (!path) return;
    auto* room1 = *reinterpret_cast<Room1**>(path + 0x1c);
    if (!room1 || !room1->room2 || !room1->room2->level) return;
    Level* level = room1->room2->level;
    const DWORD now = GetTickCount();
    finish_pending_shrine_rooms(now);
    navigation_frame(player, level);
    if (level != last_level) {
        last_level = level; passes = 24; next_tick = now + 250;
        // Never use zero as an absolute GetTickCount deadline: after Windows
        // has been up for 24.9+ days the signed wrap-safe comparison treats it
        // as a future deadline and live markers never receive their first scan.
        next_monster_tick = now;
        next_dynamic_tick = now;
        processed_rooms.clear();
        shrine_markers.clear();
        special_monsters.clear();
        normal_monsters.clear();
        special_chests.clear();
        normal_containers.clear();
        opened_containers.clear();
        waypoint_markers.clear();
        if (selected_key >= 0 &&
            level->number < navigation_data::targets.size()) {
            POINT candidate{};
            const auto& descriptor =
                navigation_data::targets[level->number][selected_key];
            if (resolve_target(player, level, descriptor, candidate)) {
                selected_target = candidate;
                selected_target_valid = true;
                logger::write("Active Num target refreshed for the new area");
            } else {
                selected_target_valid = false;
                logger::write("Active Num target unavailable in the new area");
            }
        }
        return;
    }

    const bool endgame_map = level->number > 136;
    // Live objects and monsters used to be walked every rendered frame. Large
    // PD2 maps keep hundreds of rooms/units active, so that work grew during a
    // run and produced periodic stalls. A few refreshes per second are enough
    // for markers while drawing the cached points remains smooth.
    if (static_cast<LONG>(now - next_dynamic_tick) >= 0) {
        next_dynamic_tick = now + (endgame_map ? 500 : 200);
        refresh_shrine_effects(player);
    }
    if (monster_marker_mode == 3) {
        special_monsters.clear();
        normal_monsters.clear();
    } else if (static_cast<LONG>(now - next_monster_tick) >= 0) {
        next_monster_tick = now + (endgame_map ? 500 : 250);
        refresh_special_monsters(player, level->number);
    }
    draw_shrines();
    draw_normal_monsters();
    draw_special_monsters();
    draw_special_chests();
    draw_normal_containers();
    draw_waypoints();

    if (static_cast<LONG>(now - next_tick) < 0) return;
    if (passes > 0) {
        next_tick = now + 250;
        --passes;
    } else {
        // Act 5 and some large outdoor areas generate additional rooms after
        // the initial reveal window. Keep a low-frequency scan alive so their
        // geometry, waypoints, shrines and special chests are collected.
        next_tick = now + 2000;
    }
    void* act = *reinterpret_cast<void**>(player + 0x1c);
    if (!act) return;
    long count = 0;
    for (Room2* room = level->first_room; room && count < 1024;
         room = room->next, ++count) {
        const bool added = room->room1 == nullptr;
        if (added) add_room(act, static_cast<int>(level->number),
            static_cast<int>(room->x), static_cast<int>(room->y), nullptr);
        const auto key = room_key(room);
        if (room->room1 && processed_rooms.insert(key).second) {
            reveal_room(room->room1, 1, *layer_slot);
            capture_shrines(room);
            capture_special_chests(room);
            capture_normal_containers(room);
            capture_waypoints(room);
            capture_shrine_effects(room->room1);
            InterlockedIncrement(&revealed);
        }
        if (added && config().force_shrine_labels && room_has_shrine(room)) {
            pending_shrine_rooms.push_back({act, room, level->number,
                room->x, room->y, now + 100});
        } else if (added) {
            remove_room(act, static_cast<int>(level->number),
                static_cast<int>(room->x), static_cast<int>(room->y), nullptr);
        }
    }
}
}  // namespace

std::string_view MapReveal::name() const noexcept { return "map_reveal"; }

bool MapReveal::start() noexcept {
    if (!config().project_diablo_map) return true;
    auto* client = reinterpret_cast<std::uint8_t*>(GetModuleHandleW(L"D2Client.dll"));
    auto* project = reinterpret_cast<std::uint8_t*>(GetModuleHandleW(L"ProjectDiablo.dll"));
    if (!client || !project) {
        logger::write("Map reveal delegation unavailable: required module missing"); return false;
    }
    auto* site = client + recovered::kProjectDiabloChain.d2client_site_rva;
    if (site[0] != 0xe8) return false;
    std::int32_t displacement = 0;
    std::memcpy(&displacement, site + 1, sizeof(displacement));
    if (site + 5 + displacement != project + recovered::kProjectDiabloChain.owner_handler_rva) {
        logger::write("Map reveal delegation rejected: ProjectDiablo handler mismatch"); return false;
    }
    HMODULE common = GetModuleHandleW(L"D2Common.dll");
    FARPROC add = common ? GetProcAddress(common,
        reinterpret_cast<LPCSTR>(static_cast<ULONG_PTR>(10401))) : nullptr;
    FARPROC remove = common ? GetProcAddress(common,
        reinterpret_cast<LPCSTR>(static_cast<ULONG_PTR>(11099))) : nullptr;
    FARPROC screen = common ? GetProcAddress(common,
        reinterpret_cast<LPCSTR>(static_cast<ULONG_PTR>(11087))) : nullptr;
    HMODULE gfx = GetModuleHandleW(L"D2Gfx.dll");
    FARPROC line = gfx ? GetProcAddress(gfx,
        reinterpret_cast<LPCSTR>(static_cast<ULONG_PTR>(10010))) : nullptr;
    FARPROC rectangle = gfx ? GetProcAddress(gfx,
        reinterpret_cast<LPCSTR>(static_cast<ULONG_PTR>(10014))) : nullptr;
    HMODULE win = GetModuleHandleW(L"D2Win.dll");
    FARPROC text = win ? GetProcAddress(win,
        reinterpret_cast<LPCSTR>(static_cast<ULONG_PTR>(10150))) : nullptr;
    FARPROC text_size = win ? GetProcAddress(win,
        reinterpret_cast<LPCSTR>(static_cast<ULONG_PTR>(10184))) : nullptr;
    FARPROC unit_stat = common ? GetProcAddress(common,
        reinterpret_cast<LPCSTR>(static_cast<ULONG_PTR>(10973))) : nullptr;
    FARPROC matching_type = common ? GetProcAddress(common,
        reinterpret_cast<LPCSTR>(static_cast<ULONG_PTR>(10744))) : nullptr;
    if (!add || !remove || !screen || !line || !rectangle || !text ||
        !text_size || !unit_stat || !matching_type) return false;
    player_slot = reinterpret_cast<void**>(client + 0x11bbfc);
    layer_slot = reinterpret_cast<void**>(client + 0x11c1c4);
    add_room = reinterpret_cast<AddRoomData>(add);
    remove_room = reinterpret_cast<RemoveRoomData>(remove);
    reveal_room = reinterpret_cast<RevealRoom>(client + 0x62580);
    map_to_screen = reinterpret_cast<MapToAbsScreen>(screen);
    draw_line = reinterpret_cast<DrawLine>(line);
    draw_rectangle = reinterpret_cast<DrawRectangle>(rectangle);
    get_unit_stat = reinterpret_cast<GetUnitStat>(unit_stat);
    is_matching_type = reinterpret_cast<IsMatchingType>(matching_type);
    get_current_npc = reinterpret_cast<GetCurrentNpc>(client + 0x46150);
    get_item_name = reinterpret_cast<GetItemName>(client + 0x914f0);
    store_layout = reinterpret_cast<InventoryLayout*>(client + 0x10b3b0);
    automap_mode = reinterpret_cast<int*>(client + 0xf16b0);
    automap_offset = reinterpret_cast<POINT*>(client + 0x11c1f8);
    automap_on = reinterpret_cast<BOOL*>(client + 0xfada8);
    draw_text = reinterpret_cast<DrawText>(text);
    set_text_size = reinterpret_cast<SetTextSize>(text_size);
    selected_key = 1;
    selected_target_valid = false;
    num_down.fill(false);
    num5_down = false;
    monster_marker_mode = 2;
    shrine_markers.clear();
    special_monsters.clear();
    normal_monsters.clear();
    special_chests.clear();
    normal_containers.clear();
    opened_containers.clear();
    waypoint_markers.clear();
    pending_shrine_rooms.clear();
    processed_rooms.clear();
    last_level = nullptr; next_tick = 0; next_monster_tick = 0;
    next_dynamic_tick = 0; passes = 0;
    InterlockedExchange(&revealed, 0);
    if (!recovered::install_site_2929e_hook(&reveal_frame)) return false;
    delegated_to_project_diablo_ = true;
    logger::write("Map reveal armed using verified target-build room routines");
    return true;
}

void MapReveal::stop() noexcept {
    if (delegated_to_project_diablo_) {
        logger::write(recovered::remove_site_2929e_hook(&reveal_frame)
            ? "Map reveal frame hook restored" : "WARNING: map reveal frame hook was not restored");
        char message[64]{}; wsprintfA(message, "Map rooms revealed: %ld", revealed);
        logger::write(message);
    }
    delegated_to_project_diablo_ = false;
    player_slot = layer_slot = nullptr; add_room = nullptr; remove_room = nullptr;
    reveal_room = nullptr; last_level = nullptr; next_tick = 0;
    next_monster_tick = 0; next_dynamic_tick = 0; passes = 0;
    draw_line = nullptr; map_to_screen = nullptr; automap_mode = nullptr;
    automap_offset = nullptr; automap_on = nullptr; selected_key = -1;
    selected_target_valid = false;
    num5_down = false; monster_marker_mode = 2;
    draw_text = nullptr; set_text_size = nullptr;
    draw_rectangle = nullptr; get_unit_stat = nullptr; is_matching_type = nullptr;
    get_current_npc = nullptr; get_item_name = nullptr; store_layout = nullptr;
    shrine_markers.clear();
    special_monsters.clear();
    normal_monsters.clear();
    special_chests.clear();
    normal_containers.clear();
    opened_containers.clear();
    waypoint_markers.clear();
    pending_shrine_rooms.clear();
    processed_rooms.clear();
}
}  // namespace unleashed
