#include "features/pickit.hpp"

#include <cstdint>
#include <cstring>
#include <windows.h>

#include "core/logger.hpp"
#include "core/config.hpp"
#include "recovered/existing_chains.hpp"

namespace unleashed {

std::string_view Pickit::name() const noexcept { return "pickit"; }
bool Pickit::start() noexcept {
    if (!config().bh_loot_filter) {
        logger::write("BH loot-filter delegation disabled by configuration");
        return true;
    }
    const auto d2client = reinterpret_cast<const std::uint8_t*>(
        GetModuleHandleW(L"D2Client.dll"));
    const auto bh = reinterpret_cast<const std::uint8_t*>(GetModuleHandleW(L"BH.dll"));
    if (d2client == nullptr || bh == nullptr) {
        logger::write("PickIt delegation unavailable: BH or D2Client missing");
        return false;
    }
    const auto* site = d2client + recovered::kBhPacketChain.d2client_site_rva;
    if (site[0] != 0xe8) {
        logger::write("PickIt delegation rejected: BH relative call missing");
        return false;
    }
    std::int32_t displacement = 0;
    std::memcpy(&displacement, site + 1, sizeof(displacement));
    const auto* target = site + 5 + displacement;
    const auto* expected = bh + recovered::kBhPacketChain.owner_handler_rva;
    if (target != expected) {
        logger::write("PickIt delegation rejected: BH handler mismatch");
        return false;
    }

    wchar_t bh_path[MAX_PATH]{};
    const DWORD length = GetModuleFileNameW(reinterpret_cast<HMODULE>(
        const_cast<std::uint8_t*>(bh)), bh_path, MAX_PATH);
    if (length == 0 || length >= MAX_PATH) {
        return false;
    }
    wchar_t* separator = wcsrchr(bh_path, L'\\');
    if (separator == nullptr) {
        return false;
    }
    *(separator + 1) = L'\0';
    if (wcscat_s(bh_path, MAX_PATH, L"loot.filter") != 0 ||
        GetFileAttributesW(bh_path) == INVALID_FILE_ATTRIBUTES) {
        logger::write("PickIt delegation rejected: loot.filter missing beside BH.dll");
        return false;
    }

    delegated_to_bh_ = true;
    logger::write(
        "Item filtering delegated to verified BH handler and loot.filter");
    return true;
}

void Pickit::stop() noexcept {
    delegated_to_bh_ = false;
}

}  // namespace unleashed
