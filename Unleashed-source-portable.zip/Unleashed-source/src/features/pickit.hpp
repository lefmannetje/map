#pragma once

#include "core/feature.hpp"

namespace unleashed {

class Pickit final : public Feature {
public:
    [[nodiscard]] std::string_view name() const noexcept override;
    [[nodiscard]] bool start() noexcept override;
    void stop() noexcept override;

private:
    bool delegated_to_bh_ = false;
};

}  // namespace unleashed
