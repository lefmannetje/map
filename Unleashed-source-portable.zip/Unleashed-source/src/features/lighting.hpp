#pragma once

#include "core/feature.hpp"

namespace unleashed {

class Lighting final : public Feature {
public:
    [[nodiscard]] std::string_view name() const noexcept override;
    [[nodiscard]] bool start() noexcept override;
    void stop() noexcept override;
};

}  // namespace unleashed
