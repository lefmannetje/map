#include "features/avatar.hpp"

#include "core/config.hpp"
#include "core/logger.hpp"

namespace unleashed {

std::string_view Avatar::name() const noexcept { return "avatar"; }
bool Avatar::start() noexcept {
    if (!config().avatar) {
        logger::write("Avatar automation disabled by configuration");
        return true;
    }
    logger::write("Avatar requested but remains fail-closed pending reconstruction");
    return false;
}
void Avatar::stop() noexcept {}

}  // namespace unleashed
