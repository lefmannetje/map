#include "features/lighting.hpp"

#include "core/config.hpp"
#include "core/logger.hpp"
#include "recovered/untouched_handlers.hpp"

namespace unleashed {

std::string_view Lighting::name() const noexcept { return "full_brightness"; }

bool Lighting::start() noexcept {
    if (!config().full_brightness) {
        logger::write("Full-brightness hook disabled by configuration");
        return true;
    }
    if (!recovered::install_site_a9a27_hook()) {
        logger::write("FAILED: full-brightness hook was not installed");
        return false;
    }
    logger::write("Full-brightness hook installed at verified D2Client site");
    return true;
}

void Lighting::stop() noexcept {
    logger::write(recovered::remove_site_a9a27_hook()
        ? "Full-brightness original bytes restored"
        : "WARNING: full-brightness bytes not restored because live bytes changed");
}

}  // namespace unleashed
