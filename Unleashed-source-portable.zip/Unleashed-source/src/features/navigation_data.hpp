#pragma once

#include <array>
#include <cstdint>

namespace unleashed::navigation_data {

struct Target { std::uint32_t type; std::uint32_t id; std::uint32_t a; std::uint32_t b; };
using LevelTargets = std::array<Target, 4>;
inline constexpr std::array<LevelTargets, 136> targets{{
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 0
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 1
    LevelTargets{Target{6u, 3u, 0u, 0u}, Target{6u, 8u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 1u, 0u, 0u}}, // level 2
    LevelTargets{Target{6u, 4u, 0u, 0u}, Target{6u, 17u, 0u, 0u}, Target{2u, 119u, 0u, 0u}, Target{6u, 2u, 0u, 0u}}, // level 3
    LevelTargets{Target{6u, 10u, 0u, 0u}, Target{2u, 22u, 0u, 0u}, Target{2u, 119u, 0u, 0u}, Target{6u, 3u, 0u, 0u}}, // level 4
    LevelTargets{Target{6u, 6u, 0u, 0u}, Target{2u, 30u, 0u, 0u}, Target{2u, 119u, 0u, 0u}, Target{6u, 10u, 0u, 0u}}, // level 5
    LevelTargets{Target{6u, 7u, 0u, 0u}, Target{6u, 20u, 0u, 0u}, Target{2u, 119u, 0u, 0u}, Target{6u, 5u, 0u, 0u}}, // level 6
    LevelTargets{Target{6u, 26u, 0u, 0u}, Target{6u, 12u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 6u, 0u, 0u}}, // level 7
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 2u, 0u, 0u}}, // level 8
    LevelTargets{Target{6u, 13u, 0u, 0u}, Target{1u, 736u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 3u, 0u, 0u}}, // level 9
    LevelTargets{Target{6u, 5u, 0u, 0u}, Target{6u, 14u, 0u, 0u}, Target{2u, 157u, 0u, 0u}, Target{6u, 4u, 0u, 0u}}, // level 10
    LevelTargets{Target{6u, 15u, 0u, 0u}, Target{6u, 15u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 6u, 0u, 0u}}, // level 11
    LevelTargets{Target{6u, 16u, 0u, 0u}, Target{6u, 16u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 7u, 0u, 0u}}, // level 12
    LevelTargets{Target{2u, 397u, 0u, 0u}, Target{2u, 397u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 9u, 0u, 0u}}, // level 13
    LevelTargets{Target{2u, 397u, 0u, 0u}, Target{2u, 397u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 10u, 0u, 0u}}, // level 14
    LevelTargets{Target{2u, 397u, 0u, 0u}, Target{2u, 397u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 11u, 0u, 0u}}, // level 15
    LevelTargets{Target{2u, 397u, 0u, 0u}, Target{2u, 397u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 12u, 0u, 0u}}, // level 16
    LevelTargets{Target{6u, 18u, 0u, 0u}, Target{6u, 19u, 0u, 0u}, Target{1u, 805u, 0u, 0u}, Target{6u, 3u, 0u, 0u}}, // level 17
    LevelTargets{Target{2u, 397u, 0u, 0u}, Target{2u, 397u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 17u, 0u, 0u}}, // level 18
    LevelTargets{Target{2u, 397u, 0u, 0u}, Target{2u, 397u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 17u, 0u, 0u}}, // level 19
    LevelTargets{Target{6u, 21u, 0u, 0u}, Target{6u, 21u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 6u, 0u, 0u}}, // level 20
    LevelTargets{Target{6u, 22u, 0u, 0u}, Target{6u, 22u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 20u, 0u, 0u}}, // level 21
    LevelTargets{Target{6u, 23u, 0u, 0u}, Target{6u, 23u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 21u, 0u, 0u}}, // level 22
    LevelTargets{Target{6u, 24u, 0u, 0u}, Target{6u, 24u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 22u, 0u, 0u}}, // level 23
    LevelTargets{Target{6u, 25u, 0u, 0u}, Target{6u, 25u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 23u, 0u, 0u}}, // level 24
    LevelTargets{Target{1u, 740u, 0u, 0u}, Target{1u, 740u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 24u, 0u, 0u}}, // level 25
    LevelTargets{Target{6u, 27u, 0u, 0u}, Target{6u, 27u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{7u, 15141u, 5091u, 7u}}, // level 26
    LevelTargets{Target{6u, 28u, 0u, 0u}, Target{6u, 28u, 0u, 0u}, Target{2u, 119u, 0u, 0u}, Target{6u, 26u, 0u, 0u}}, // level 27
    LevelTargets{Target{6u, 29u, 0u, 0u}, Target{2u, 108u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 27u, 0u, 0u}}, // level 28
    LevelTargets{Target{6u, 30u, 0u, 0u}, Target{6u, 30u, 0u, 0u}, Target{2u, 157u, 0u, 0u}, Target{6u, 28u, 0u, 0u}}, // level 29
    LevelTargets{Target{6u, 31u, 0u, 0u}, Target{6u, 31u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 29u, 0u, 0u}}, // level 30
    LevelTargets{Target{6u, 32u, 0u, 0u}, Target{6u, 32u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 30u, 0u, 0u}}, // level 31
    LevelTargets{Target{6u, 33u, 0u, 0u}, Target{6u, 33u, 0u, 0u}, Target{2u, 119u, 0u, 0u}, Target{6u, 31u, 0u, 0u}}, // level 32
    LevelTargets{Target{6u, 34u, 0u, 0u}, Target{6u, 34u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 32u, 0u, 0u}}, // level 33
    LevelTargets{Target{6u, 35u, 0u, 0u}, Target{6u, 35u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 33u, 0u, 0u}}, // level 34
    LevelTargets{Target{6u, 36u, 0u, 0u}, Target{6u, 36u, 0u, 0u}, Target{2u, 157u, 0u, 0u}, Target{6u, 34u, 0u, 0u}}, // level 35
    LevelTargets{Target{6u, 37u, 0u, 0u}, Target{6u, 37u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 35u, 0u, 0u}}, // level 36
    LevelTargets{Target{7u, 22533u, 9556u, 0u}, Target{7u, 22563u, 9556u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 36u, 0u, 0u}}, // level 37
    LevelTargets{Target{2u, 268u, 0u, 0u}, Target{2u, 26u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{7u, 25173u, 5083u, 0u}}, // level 38
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 39
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 40
    LevelTargets{Target{6u, 42u, 0u, 0u}, Target{6u, 42u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 40u, 0u, 0u}}, // level 41
    LevelTargets{Target{6u, 43u, 0u, 0u}, Target{6u, 56u, 0u, 0u}, Target{2u, 156u, 0u, 0u}, Target{6u, 41u, 0u, 0u}}, // level 42
    LevelTargets{Target{6u, 44u, 0u, 0u}, Target{6u, 62u, 0u, 0u}, Target{2u, 156u, 0u, 0u}, Target{6u, 42u, 0u, 0u}}, // level 43
    LevelTargets{Target{6u, 45u, 0u, 0u}, Target{6u, 65u, 0u, 0u}, Target{2u, 156u, 0u, 0u}, Target{6u, 43u, 0u, 0u}}, // level 44
    LevelTargets{Target{6u, 58u, 0u, 0u}, Target{6u, 58u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 44u, 0u, 0u}}, // level 45
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{8u, 0u, 0u, 0u}, Target{2u, 402u, 0u, 0u}, Target{2u, 402u, 0u, 0u}}, // level 46: runtime true tomb
    LevelTargets{Target{6u, 48u, 0u, 0u}, Target{6u, 48u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 40u, 0u, 0u}}, // level 47
    LevelTargets{Target{6u, 49u, 0u, 0u}, Target{6u, 49u, 0u, 0u}, Target{2u, 323u, 0u, 0u}, Target{6u, 47u, 0u, 0u}}, // level 48
    LevelTargets{Target{2u, 355u, 0u, 0u}, Target{2u, 355u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 48u, 0u, 0u}}, // level 49
    LevelTargets{Target{5u, 29u, 0u, 0u}, Target{5u, 29u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 40u, 0u, 0u}}, // level 50
    LevelTargets{Target{6u, 52u, 0u, 0u}, Target{6u, 52u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 50u, 0u, 0u}}, // level 51
    LevelTargets{Target{6u, 53u, 0u, 0u}, Target{6u, 53u, 0u, 0u}, Target{2u, 288u, 0u, 0u}, Target{6u, 51u, 0u, 0u}}, // level 52
    LevelTargets{Target{6u, 54u, 0u, 0u}, Target{6u, 54u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 52u, 0u, 0u}}, // level 53
    LevelTargets{Target{2u, 298u, 0u, 0u}, Target{2u, 298u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 53u, 0u, 0u}}, // level 54
    LevelTargets{Target{6u, 59u, 0u, 0u}, Target{6u, 59u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 41u, 0u, 0u}}, // level 55
    LevelTargets{Target{6u, 57u, 0u, 0u}, Target{6u, 57u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 42u, 0u, 0u}}, // level 56
    LevelTargets{Target{6u, 60u, 0u, 0u}, Target{6u, 60u, 0u, 0u}, Target{2u, 156u, 0u, 0u}, Target{6u, 56u, 0u, 0u}}, // level 57
    LevelTargets{Target{6u, 61u, 0u, 0u}, Target{6u, 61u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 45u, 0u, 0u}}, // level 58
    LevelTargets{Target{2u, 397u, 0u, 0u}, Target{2u, 397u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 55u, 0u, 0u}}, // level 59
    LevelTargets{Target{2u, 354u, 0u, 0u}, Target{2u, 354u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 57u, 0u, 0u}}, // level 60
    LevelTargets{Target{2u, 149u, 0u, 0u}, Target{2u, 149u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 58u, 0u, 0u}}, // level 61
    LevelTargets{Target{6u, 63u, 0u, 0u}, Target{6u, 63u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 43u, 0u, 0u}}, // level 62
    LevelTargets{Target{6u, 64u, 0u, 0u}, Target{6u, 64u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 62u, 0u, 0u}}, // level 63
    LevelTargets{Target{2u, 356u, 0u, 0u}, Target{2u, 356u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 63u, 0u, 0u}}, // level 64
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 44u, 0u, 0u}}, // level 65
    LevelTargets{Target{2u, 152u, 0u, 0u}, Target{2u, 152u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 46u, 0u, 0u}}, // level 66
    LevelTargets{Target{2u, 152u, 0u, 0u}, Target{2u, 152u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 46u, 0u, 0u}}, // level 67
    LevelTargets{Target{2u, 152u, 0u, 0u}, Target{2u, 152u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 46u, 0u, 0u}}, // level 68
    LevelTargets{Target{2u, 152u, 0u, 0u}, Target{2u, 152u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 46u, 0u, 0u}}, // level 69
    LevelTargets{Target{2u, 152u, 0u, 0u}, Target{2u, 152u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 46u, 0u, 0u}}, // level 70
    LevelTargets{Target{2u, 152u, 0u, 0u}, Target{2u, 152u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 46u, 0u, 0u}}, // level 71
    LevelTargets{Target{2u, 152u, 0u, 0u}, Target{2u, 152u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 46u, 0u, 0u}}, // level 72
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{1u, 211u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 73: Duriel
    LevelTargets{Target{2u, 357u, 0u, 0u}, Target{2u, 357u, 0u, 0u}, Target{2u, 402u, 0u, 0u}, Target{2u, 298u, 0u, 0u}}, // level 74
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 75
    LevelTargets{Target{6u, 77u, 0u, 0u}, Target{6u, 85u, 0u, 0u}, Target{2u, 237u, 0u, 0u}, Target{6u, 75u, 0u, 0u}}, // level 76
    LevelTargets{Target{6u, 78u, 0u, 0u}, Target{6u, 78u, 0u, 0u}, Target{2u, 237u, 0u, 0u}, Target{6u, 76u, 0u, 0u}}, // level 77
    LevelTargets{Target{6u, 79u, 0u, 0u}, Target{2u, 252u, 0u, 0u}, Target{2u, 237u, 0u, 0u}, Target{6u, 77u, 0u, 0u}}, // level 78
    LevelTargets{Target{6u, 80u, 0u, 0u}, Target{6u, 80u, 0u, 0u}, Target{2u, 237u, 0u, 0u}, Target{6u, 78u, 0u, 0u}}, // level 79
    LevelTargets{Target{6u, 81u, 0u, 0u}, Target{6u, 94u, 0u, 0u}, Target{2u, 237u, 0u, 0u}, Target{6u, 79u, 0u, 0u}}, // level 80
    LevelTargets{Target{6u, 82u, 0u, 0u}, Target{6u, 82u, 0u, 0u}, Target{2u, 237u, 0u, 0u}, Target{6u, 80u, 0u, 0u}}, // level 81
    LevelTargets{Target{6u, 83u, 0u, 0u}, Target{6u, 83u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 81u, 0u, 0u}}, // level 82
    LevelTargets{Target{6u, 100u, 0u, 0u}, Target{6u, 100u, 0u, 0u}, Target{2u, 237u, 0u, 0u}, Target{6u, 82u, 0u, 0u}}, // level 83
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 84
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 85
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 86
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 87
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 88
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 89
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 90
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 91
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 92
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 93
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 94
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 95
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 96
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 97
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 98
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 99
    LevelTargets{Target{6u, 101u, 0u, 0u}, Target{6u, 101u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 83u, 0u, 0u}}, // level 100
    LevelTargets{Target{6u, 102u, 0u, 0u}, Target{6u, 102u, 0u, 0u}, Target{2u, 324u, 0u, 0u}, Target{6u, 100u, 0u, 0u}}, // level 101
    LevelTargets{Target{7u, 17591u, 8069u, 0u}, Target{7u, 17591u, 8069u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 101u, 0u, 0u}}, // level 102
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 103
    LevelTargets{Target{6u, 105u, 0u, 0u}, Target{6u, 105u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 103u, 0u, 0u}}, // level 104
    LevelTargets{Target{6u, 106u, 0u, 0u}, Target{1u, 256u, 0u, 0u}, Target{2u, 238u, 0u, 0u}, Target{6u, 104u, 0u, 0u}}, // level 105
    LevelTargets{Target{6u, 107u, 0u, 0u}, Target{6u, 107u, 0u, 0u}, Target{2u, 238u, 0u, 0u}, Target{6u, 105u, 0u, 0u}}, // level 106
    LevelTargets{Target{2u, 255u, 0u, 108u}, Target{2u, 376u, 0u, 0u}, Target{2u, 238u, 0u, 0u}, Target{6u, 106u, 0u, 0u}}, // level 107
    LevelTargets{Target{2u, 392u, 1337u, 0u}, Target{2u, 255u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 107u, 0u, 0u}}, // level 108
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 109
    LevelTargets{Target{6u, 111u, 0u, 0u}, Target{1u, 776u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 109u, 0u, 0u}}, // level 110
    LevelTargets{Target{6u, 112u, 0u, 0u}, Target{6u, 112u, 0u, 0u}, Target{2u, 496u, 0u, 0u}, Target{6u, 110u, 0u, 0u}}, // level 111
    LevelTargets{Target{6u, 113u, 0u, 0u}, Target{6u, 113u, 0u, 0u}, Target{2u, 496u, 0u, 0u}, Target{6u, 111u, 0u, 0u}}, // level 112
    LevelTargets{Target{6u, 115u, 0u, 0u}, Target{6u, 114u, 0u, 0u}, Target{2u, 511u, 0u, 0u}, Target{6u, 112u, 0u, 0u}}, // level 113
    LevelTargets{Target{2u, 460u, 0u, 0u}, Target{2u, 460u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 113u, 0u, 0u}}, // level 114
    LevelTargets{Target{6u, 117u, 0u, 0u}, Target{6u, 117u, 0u, 0u}, Target{2u, 511u, 0u, 0u}, Target{6u, 113u, 0u, 0u}}, // level 115
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 116
    LevelTargets{Target{6u, 118u, 0u, 0u}, Target{6u, 118u, 0u, 0u}, Target{2u, 496u, 0u, 0u}, Target{6u, 112u, 0u, 0u}}, // level 117
    LevelTargets{Target{6u, 120u, 0u, 0u}, Target{6u, 120u, 0u, 0u}, Target{2u, 511u, 0u, 0u}, Target{6u, 117u, 0u, 0u}}, // level 118
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 119
    LevelTargets{Target{6u, 128u, 0u, 0u}, Target{6u, 128u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 118u, 0u, 0u}}, // level 120
    LevelTargets{Target{6u, 122u, 0u, 0u}, Target{6u, 122u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 121
    LevelTargets{Target{6u, 123u, 0u, 0u}, Target{6u, 123u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 121u, 0u, 0u}}, // level 122
    LevelTargets{Target{6u, 124u, 0u, 0u}, Target{6u, 124u, 0u, 0u}, Target{2u, 496u, 0u, 0u}, Target{6u, 122u, 0u, 0u}}, // level 123
    LevelTargets{Target{2u, 462u, 0u, 0u}, Target{2u, 462u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 123u, 0u, 0u}}, // level 124
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 125
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 126
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 127
    LevelTargets{Target{6u, 129u, 0u, 0u}, Target{6u, 129u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 112u, 0u, 0u}}, // level 128
    LevelTargets{Target{6u, 130u, 0u, 0u}, Target{6u, 130u, 0u, 0u}, Target{2u, 494u, 0u, 0u}, Target{6u, 128u, 0u, 0u}}, // level 129
    LevelTargets{Target{6u, 131u, 0u, 0u}, Target{6u, 131u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 129u, 0u, 0u}}, // level 130
    LevelTargets{Target{7u, 15091u, 5006u, 0u}, Target{7u, 15114u, 5069u, 0u}, Target{0u, 0u, 0u, 0u}, Target{6u, 130u, 0u, 0u}}, // level 131
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 132
    LevelTargets{Target{2u, 397u, 0u, 0u}, Target{2u, 397u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 133
    LevelTargets{Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 134
    LevelTargets{Target{2u, 397u, 0u, 0u}, Target{2u, 397u, 0u, 0u}, Target{0u, 0u, 0u, 0u}, Target{0u, 0u, 0u, 0u}}, // level 135
}};

}  // namespace unleashed::navigation_data
