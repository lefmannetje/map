#include <array>
#include <cwchar>
#include <string>
#include <windows.h>
#include <tlhelp32.h>

namespace {

void show(const wchar_t* title, const std::wstring& message) noexcept {
    MessageBoxW(nullptr, message.c_str(), title, MB_OK | MB_ICONINFORMATION);
}

std::wstring win32_error(const wchar_t* operation, DWORD error) {
    wchar_t* system_message = nullptr;
    FormatMessageW(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM |
            FORMAT_MESSAGE_IGNORE_INSERTS,
        nullptr, error, 0, reinterpret_cast<wchar_t*>(&system_message), 0, nullptr);
    std::wstring message = operation;
    message += L" failed (error ";
    message += std::to_wstring(error);
    message += L"): ";
    if (system_message != nullptr) {
        message += system_message;
        LocalFree(system_message);
    }
    return message;
}

DWORD find_game_process() noexcept {
    const HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapshot == INVALID_HANDLE_VALUE) {
        return 0;
    }
    PROCESSENTRY32W entry{};
    entry.dwSize = sizeof(entry);
    DWORD process_id = 0;
    if (Process32FirstW(snapshot, &entry)) {
        do {
            if (_wcsicmp(entry.szExeFile, L"Game.exe") == 0) {
                process_id = entry.th32ProcessID;
                break;
            }
        } while (Process32NextW(snapshot, &entry));
    }
    CloseHandle(snapshot);
    return process_id;
}

bool enable_debug_privilege(std::wstring& error_message) noexcept {
    HANDLE token = nullptr;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY,
            &token)) {
        error_message = win32_error(L"OpenProcessToken", GetLastError());
        return false;
    }
    TOKEN_PRIVILEGES privileges{};
    privileges.PrivilegeCount = 1;
    if (!LookupPrivilegeValueW(nullptr, L"SeDebugPrivilege",
            &privileges.Privileges[0].Luid)) {
        const DWORD error = GetLastError();
        CloseHandle(token);
        error_message = win32_error(L"LookupPrivilegeValue", error);
        return false;
    }
    privileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
    SetLastError(ERROR_SUCCESS);
    const BOOL adjusted = AdjustTokenPrivileges(token, FALSE, &privileges,
        sizeof(privileges), nullptr, nullptr);
    const DWORD error = GetLastError();
    CloseHandle(token);
    if (!adjusted || error == ERROR_NOT_ALL_ASSIGNED) {
        error_message = win32_error(L"AdjustTokenPrivileges",
            error == ERROR_SUCCESS ? ERROR_PRIVILEGE_NOT_HELD : error);
        return false;
    }
    return true;
}

bool get_adjacent_dll(std::array<wchar_t, MAX_PATH>& path) noexcept {
    const DWORD length = GetModuleFileNameW(nullptr, path.data(), static_cast<DWORD>(path.size()));
    if (length == 0 || length >= path.size()) {
        return false;
    }
    wchar_t* separator = wcsrchr(path.data(), L'\\');
    return separator != nullptr &&
        wcscpy_s(separator + 1, path.size() - static_cast<std::size_t>(separator + 1 - path.data()),
            L"Unleashed.dll") == 0;
}

bool path_is_expected(HANDLE process, std::wstring& observed) noexcept {
    std::array<wchar_t, 4096> path{};
    DWORD length = static_cast<DWORD>(path.size());
    if (!QueryFullProcessImageNameW(process, 0, path.data(), &length)) {
        return false;
    }
    observed.assign(path.data(), length);
    const std::wstring lower = observed;
    const wchar_t* expected_root = L"\\projectd2\\game.exe";
    const wchar_t* expected_live = L"\\projectd2\\live\\game.exe";
    const auto ends_with_case_insensitive = [&lower](const wchar_t* suffix) {
        const std::size_t suffix_length = wcslen(suffix);
        return lower.size() >= suffix_length &&
            _wcsicmp(lower.c_str() + lower.size() - suffix_length, suffix) == 0;
    };
    return ends_with_case_insensitive(expected_root) || ends_with_case_insensitive(expected_live);
}

}  // namespace

int WINAPI wWinMain(HINSTANCE, HINSTANCE, wchar_t*, int) {
    std::wstring privilege_error;
    if (!enable_debug_privilege(privilege_error)) {
        show(L"Unleashed loader", privilege_error);
        return 1;
    }
    std::array<wchar_t, MAX_PATH> dll_path{};
    if (!get_adjacent_dll(dll_path)) {
        show(L"Unleashed loader", L"Could not construct the adjacent Unleashed.dll path.");
        return 1;
    }
    if (GetFileAttributesW(dll_path.data()) == INVALID_FILE_ATTRIBUTES) {
        show(L"Unleashed loader", L"Unleashed.dll is missing beside this loader.");
        return 1;
    }

    const DWORD process_id = find_game_process();
    if (process_id == 0) {
        show(L"Unleashed loader", L"Game.exe is not running.");
        return 1;
    }

    const HANDLE process = OpenProcess(PROCESS_CREATE_THREAD | PROCESS_QUERY_LIMITED_INFORMATION |
            PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_VM_READ,
        FALSE, process_id);
    if (process == nullptr) {
        show(L"Unleashed loader", win32_error(L"OpenProcess", GetLastError()));
        return 1;
    }

    std::wstring process_path;
    if (!path_is_expected(process, process_path)) {
        CloseHandle(process);
        show(L"Unleashed loader", L"Refused unexpected Game.exe path:\r\n" + process_path);
        return 1;
    }

    BOOL target_wow64 = FALSE;
    if (!IsWow64Process(process, &target_wow64) || !target_wow64) {
        CloseHandle(process);
        show(L"Unleashed loader", L"Refused target because it is not a 32-bit process.");
        return 1;
    }

    const SIZE_T bytes = (wcslen(dll_path.data()) + 1) * sizeof(wchar_t);
    void* remote_path = VirtualAllocEx(process, nullptr, bytes, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (remote_path == nullptr) {
        const DWORD error = GetLastError();
        CloseHandle(process);
        show(L"Unleashed loader", win32_error(L"VirtualAllocEx", error));
        return 1;
    }

    if (!WriteProcessMemory(process, remote_path, dll_path.data(), bytes, nullptr)) {
        const DWORD error = GetLastError();
        VirtualFreeEx(process, remote_path, 0, MEM_RELEASE);
        CloseHandle(process);
        show(L"Unleashed loader", win32_error(L"WriteProcessMemory", error));
        return 1;
    }

    const HMODULE kernel32 = GetModuleHandleW(L"kernel32.dll");
    const auto load_library = reinterpret_cast<LPTHREAD_START_ROUTINE>(
        GetProcAddress(kernel32, "LoadLibraryW"));
    if (load_library == nullptr) {
        VirtualFreeEx(process, remote_path, 0, MEM_RELEASE);
        CloseHandle(process);
        show(L"Unleashed loader", L"Could not resolve LoadLibraryW.");
        return 1;
    }

    const HANDLE thread = CreateRemoteThread(process, nullptr, 0, load_library, remote_path, 0, nullptr);
    if (thread == nullptr) {
        const DWORD error = GetLastError();
        VirtualFreeEx(process, remote_path, 0, MEM_RELEASE);
        CloseHandle(process);
        show(L"Unleashed loader", win32_error(L"CreateRemoteThread", error));
        return 1;
    }

    const DWORD wait = WaitForSingleObject(thread, 10'000);
    DWORD remote_module = 0;
    GetExitCodeThread(thread, &remote_module);
    CloseHandle(thread);
    VirtualFreeEx(process, remote_path, 0, MEM_RELEASE);
    CloseHandle(process);

    if (wait != WAIT_OBJECT_0 || remote_module == 0) {
        show(L"Unleashed loader", L"The remote LoadLibraryW call failed or timed out.");
        return 1;
    }

    show(L"Unleashed loader", L"Unleashed.dll loaded successfully into Game.exe.");
    return 0;
}
