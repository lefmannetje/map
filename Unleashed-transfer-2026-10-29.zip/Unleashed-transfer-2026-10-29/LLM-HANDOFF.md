# Unleashed technical handoff

## Objective and current baseline

This is a 32-bit Project Diablo 2 DLL plus loader. The current build was
verified in a live process on 2026-10-29 with GDFX selected. Initialization,
map reveal, full brightness and the chained BH packet dispatcher all executed.

The bot/shopper logic is highly stateful and was previously regression-prone.
When adapting to a game update, change only the compatibility evidence first;
do not rewrite the F8/F9/F10 state machines unless logs prove they are involved.

## Current module evidence

| Module | SHA-256 |
|---|---|
| D2Client.dll | `DD8BC6025DE921216A97C17F97CD1A50FBB85926E838EC60E13451448836D906` |
| ProjectDiablo.dll | `37D7CC4CCD8208BECB123BABD77F9FE24F85ECC89CCC21DDBAF8462C47625FAE` |
| BH.dll | `219CFCD8A6F0581C6D8438925B2C56FE3BA6E23EB5CC1AE8A4BF724EDA8C3A61` |

Verified live chains:

- `D2Client.dll + 0x6264D` calls `ProjectDiablo.dll + 0x2920C0`.
- `D2Client.dll + 0xACE61` calls `BH.dll + 0x7A3A0`.
- The BH wrapper's continuation is `BH.dll + 0x43DD0`.
- Unleashed-owned sites `D2Client + 0xA9A27` and `+0x2929E` retained their
  verified original bytes during the October updates.

The relevant declarations are in:

- `source/src/recovered/existing_chains.hpp`
- `source/src/bindings/target_build.hpp`
- `source/src/bindings/target_verifier.cpp`
- `source/src/recovered/bh_dispatcher.cpp`

## Expected successful log sequence

```text
Verified existing chain at D2Client RVA 0x0006264D
Verified D2Client RVA 0x000A9A27
Verified D2Client RVA 0x0002929E
Verified existing chain at D2Client RVA 0x000ACE61
Target and existing hook-chain verification passed; no hooks were installed
Map reveal armed using verified target-build room routines
Item filtering delegated to verified BH handler and loot.filter
Full-brightness hook installed at verified D2Client site
Chained packet dispatcher installed; BH forwarding preserved
CONFIRMED: chained packet dispatcher executed
```

## Procedure after a future PD2 update

1. Leave the game running after one failed injection so live module ownership
   and ASLR-adjusted call targets can be recorded in `Unleashed.log`.
2. Check whether D2Client changed. If its hash and the two Unleashed-owned site
   bytes are unchanged, do not touch the many D2Client function/data offsets.
3. For a changed existing call chain, decode the live relative `E8` target and
   confirm `VirtualQuery(...).AllocationBase` belongs to the expected module.
4. Convert the live target to an RVA by subtracting that module's live base.
5. Disassemble the on-disk function at `preferred image base + RVA`. Confirm
   the wrapper has the same calling convention and behavior. For BH, the known
   pattern preserves registers, calls its filter, clears EDX on suppression,
   then calls the original continuation.
6. Update only `ExistingChainEvidence` and the documented module hash.
7. Build x86, stage under a different filename, close Game.exe, then replace
   the runtime DLL. Never overwrite a loaded DLL.
8. First test only initialization/overlay. Then test packet traffic, movement
   and automation separately.

Do not weaken `matches_existing_chain()` to accept any call into the expected
module. Exact owner plus exact handler RVA is intentional fail-closed behavior.

## October 2026 update history

- 2026-10-26: Project wrapper moved from `0x20F470` to `0x292AA0`; BH wrapper
  moved from `0x79A90` to `0x7A3A0`, continuation `0x43DD0`.
- 2026-10-28: Project wrapper moved again to `0x2920C0`. BH stayed at
  `0x7A3A0`. D2Client remained hash-identical.
- 2026-10-29: live verification and dispatcher execution succeeded with the
  current package.

## Renderer note

GDFX was not responsible for the no-effect injection on 2026-10-28; target
verification had already stopped initialization. Renderer changes can still
alter coordinate scaling. The current code logs logical automap bounds and
loaded graphics modules. Treat navigation/click problems separately from an
initialization mismatch.

## Emergency-exit false crash

`emergency_exit=1` intentionally terminates Game.exe when player life reaches
the configured threshold. This was previously mistaken for an injection crash.
Always inspect the final log lines for `EMERGENCY EXIT` before debugging hooks.

## Packaging constraints

The archive intentionally excludes `Unleashed.log`, build directories, object
files, PDBs, crash dumps and withdrawn stash experiments. The rollback binary
is for comparison only and is not compatible with the current wrapper RVA.
