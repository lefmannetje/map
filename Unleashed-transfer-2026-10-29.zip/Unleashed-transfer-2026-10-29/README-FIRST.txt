UNLEASHED TRANSFER PACKAGE — VERIFIED 2026-10-29
================================================

What is included
----------------
runtime\Unleashed.dll          Current 32-bit PD2 extension
runtime\UnleashedLoader.exe    Loader for the adjacent DLL
runtime\Unleashed.ini          Current configuration
runtime\Unleashed-Futureal.filter  Optional custom loot filter
runtime\StashedItems.csv       Item-storage log/template
source\                        Complete buildable source
rollback\                      Previous DLL, diagnostic rollback only
LLM-HANDOFF.md                  Technical notes for another coding assistant
SHA256SUMS.txt                  Integrity hashes for every packaged file

Install on another Windows PC
-----------------------------
1. Extract the ZIP to a normal writable folder.
2. Keep Unleashed.dll, UnleashedLoader.exe and Unleashed.ini together. The
   easiest option is to use them directly from the runtime folder.
3. Start Project Diablo 2 and enter a game.
4. Run UnleashedLoader.exe as administrator.
5. A successful load creates Unleashed.log beside the DLL. The log should say:
     Target and existing hook-chain verification passed
     Map reveal armed using verified target-build room routines
     Chained packet dispatcher installed; BH forwarding preserved
6. The loader accepts a 32-bit Game.exe under either \ProjectD2\Game.exe or
   \ProjectD2\Live\Game.exe.

Renderer
--------
The verified PC used GDFX even though ddraw.dll was also present. GDFX did not
prevent initialization. Renderer choice may affect mouse/cursor scaling used
by automation, so retest movement and lobby clicks after changing resolution,
Windows display scaling, renderer, or window mode.

Current controls and status
---------------------------
F8: configured automated shopper for the supported merchant flow.
F9: experimental Pindleskin loop developed on the original PC.
F10: isolated Malah ID-scroll refill test, used with F9 off.

Do not leave automation unattended until walking, portal entry, lobby creation,
item handling and emergency behavior have each been verified on the new PC.

Important safety setting
------------------------
The supplied INI currently has emergency_exit=1 at 25% life. At or below that
threshold it intentionally terminates Game.exe; this can look exactly like a
crash. Set emergency_exit=0 before testing if that behavior is not wanted.

Loot filter
-----------
The DLL delegates filtering to BH.dll and the active loot.filter beside BH.dll.
Unleashed-Futureal.filter is included as an optional reference; do not overwrite
the other PC's active filter unless that is intentional.

Compatibility
-------------
This build is fail-closed and targets the PD2 modules verified on 2026-10-29.
If injection reports success but no overlay or changes appear, inspect
Unleashed.log. A MISMATCH entry normally means PD2 updated and the wrapper RVA
must be re-verified. Do not simply disable verification or copy a guessed RVA.
See LLM-HANDOFF.md for the exact hashes, offsets and update procedure.

Build from source
-----------------
Install Visual Studio 2022 C++ Build Tools with CMake support. Open PowerShell
inside the source folder and run:

  .\build-win32.ps1

The project must be built as 32-bit/x86. New binaries appear under
source\build\Release when using the supplied script.

Rollback
--------
The rollback DLL predates the 2026-10-28 PD2 wrapper move and is expected to
fail verification on the current game. It exists only for comparison and
diagnosis. Keep the current runtime\Unleashed.dll for normal use.

Security
--------
DLL injection and unsigned binaries may trigger antivirus warnings. Do not
disable security software globally. Verify SHA256SUMS.txt after transferring.
No gameplay log or crash dump is included in this archive.
