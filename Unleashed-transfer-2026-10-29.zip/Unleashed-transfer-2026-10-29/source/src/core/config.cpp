#include "core/config.hpp"

#include <array>

#include "core/logger.hpp"

namespace unleashed {
namespace {

Config current_config{};

bool read_bool(const wchar_t* path, const wchar_t* key,
    bool fallback) noexcept {
    return GetPrivateProfileIntW(L"features", key, fallback ? 1 : 0, path) != 0;
}

int read_int(const wchar_t* path, const wchar_t* key, int fallback,
    int minimum, int maximum) noexcept {
    const int value = GetPrivateProfileIntW(L"features", key, fallback, path);
    return value < minimum ? minimum : (value > maximum ? maximum : value);
}

}  // namespace

Config& config() noexcept {
    return current_config;
}

bool load_config(HMODULE module) noexcept {
    std::array<wchar_t, MAX_PATH> path{};
    const DWORD length = GetModuleFileNameW(module, path.data(),
        static_cast<DWORD>(path.size()));
    if (length == 0 || length >= path.size()) {
        return false;
    }
    wchar_t* separator = wcsrchr(path.data(), L'\\');
    if (separator == nullptr) {
        return false;
    }
    *(separator + 1) = L'\0';
    if (wcscat_s(path.data(), path.size(), L"Unleashed.ini") != 0) {
        return false;
    }

    current_config.packet_51_adjustment = read_bool(path.data(),
        L"packet_51_adjustment", true);
    current_config.packet_a7_suppression = read_bool(path.data(),
        L"packet_a7_suppression", true);
    current_config.inventory_full_event = read_bool(path.data(),
        L"inventory_full_event", false);
    current_config.project_diablo_map = read_bool(path.data(),
        L"project_diablo_map", true);
    current_config.force_shrine_labels = read_bool(path.data(),
        L"force_shrine_labels", false);
    current_config.bh_loot_filter = read_bool(path.data(),
        L"bh_loot_filter", true);
    current_config.full_brightness = read_bool(path.data(),
        L"full_brightness", true);
    current_config.auto_rejuvenation = read_bool(path.data(),
        L"auto_rejuvenation", false);
    current_config.rejuvenation_life_percent = read_int(path.data(),
        L"rejuvenation_life_percent", 50, 1, 99);
    current_config.rejuvenation_belt_key = read_int(path.data(),
        L"rejuvenation_belt_key", 1, 1, 4);
    current_config.rejuvenation_cooldown_ms = read_int(path.data(),
        L"rejuvenation_cooldown_ms", 1000, 250, 5000);
    current_config.emergency_exit = read_bool(path.data(),
        L"emergency_exit", true);
    current_config.emergency_exit_life_percent = read_int(path.data(),
        L"emergency_exit_life_percent", 20, 1, 99);
    current_config.auto_mercenary_rejuvenation = read_bool(path.data(),
        L"auto_mercenary_rejuvenation", true);
    current_config.mercenary_rejuvenation_life_percent = read_int(path.data(),
        L"mercenary_rejuvenation_life_percent", 40, 1, 99);
    current_config.mercenary_potion_belt_key = read_int(path.data(),
        L"mercenary_potion_belt_key", 3, 1, 4);
    current_config.mercenary_rejuvenation_cooldown_ms = read_int(path.data(),
        L"mercenary_rejuvenation_cooldown_ms", 1000, 250, 5000);
    current_config.avatar = read_bool(path.data(), L"avatar", false);
    current_config.automated_shopper = read_bool(path.data(),
        L"automated_shopper", true);
    current_config.automated_shopper_hotkey = read_int(path.data(),
        L"automated_shopper_hotkey", VK_F8, 1, 255);
    current_config.automated_shopper_buy_cooldown_ms = read_int(path.data(),
        L"automated_shopper_buy_cooldown_ms", 750, 250, 5000);
    current_config.automated_shopper_test_sorc_plus_four = read_bool(path.data(),
        L"automated_shopper_test_sorc_plus_four", false);

    logger::write("Loaded Unleashed.ini feature configuration");
    return true;
}

}  // namespace unleashed
