#include "features/map_reveal.hpp"

#include <cstdint>
#include <climits>
#include <cstring>
#include <array>
#include <algorithm>
#include <unordered_set>
#include <vector>
#include <windows.h>

#include "core/config.hpp"
#include "core/logger.hpp"
#include "recovered/existing_chains.hpp"
#include "recovered/untouched_handlers.hpp"
#include "features/navigation_data.hpp"

namespace unleashed {
namespace {
#pragma pack(push, 1)
struct Level;
struct Room1;
struct Room2 {
    std::uint32_t unused0[2]; Room2** near_rooms; std::uint32_t unused1[5];
    void* type_info; Room2* next; std::uint32_t flags, near_count; Room1* room1;
    std::uint32_t x, y, size_x, size_y, unused2, preset_type; void* room_tiles;
    std::uint32_t unused3[2]; Level* level; void* presets;
};
struct UnitAny;
struct Room1 {
    std::uint32_t unused[4]; Room2* room2;
    std::uint8_t unused_after_room2[0x60];
    UnitAny* first_unit;
    std::uint32_t unused_after_first;
    Room1* next_active;
};
struct PresetUnit {
    std::uint32_t unused0, id, x; PresetUnit* next; std::uint32_t unused1, type, y;
};
struct RoomTile {
    Room2* room; RoomTile* next; std::uint32_t unused[2]; std::uint32_t* number;
};
struct ObjectData { void* text; std::uint8_t shrine_type; };
struct MonsterData {
    std::uint8_t unused[22];
    std::uint8_t flags;
    std::uint8_t last_animation_mode;
    std::uint32_t duriel_flag;
    std::uint8_t modifiers[10];
};
struct UnitAny {
    std::uint32_t type, id, unused0, unit_id, mode;
    ObjectData* object_data;
    std::uint8_t unused1[0x14];
    void* path;
    std::uint8_t unused2a[0x5c];
    std::uint16_t x, y;
    std::uint8_t unused2[0x58];
    UnitAny* room_next;
};
struct Level {
    std::uint32_t unused0[4]; Room2* first_room; std::uint32_t unused1[102];
    Level* next; std::uint32_t unused2; void* act_misc; std::uint32_t unused3[6];
    std::uint32_t number;
};
#pragma pack(pop)

using AddRoomData = void(__stdcall*)(void*, int, int, int, Room1*);
using RemoveRoomData = void(__stdcall*)(void*, int, int, int, Room1*);
using RevealRoom = void(__stdcall*)(Room1*, std::uint32_t, void*);
using DrawLine = void(__stdcall*)(int, int, int, int, std::uint32_t, std::uint32_t);
using MapToAbsScreen = void(__stdcall*)(long*, long*);
using DrawText = void(__fastcall*)(wchar_t*, int, int, std::uint32_t, std::uint32_t);
using SetTextSize = std::uint32_t(__fastcall*)(std::uint32_t);
using GetCurrentNpc = void*(__fastcall*)();
using GetUnitStat = std::uint32_t(__stdcall*)(void*, std::uint32_t, std::uint32_t);
using DrawRectangle = void(__stdcall*)(int, int, int, int, std::uint32_t, std::uint32_t);
using GetItemName = BOOL(__stdcall*)(void*, wchar_t*, std::uint32_t);
using IsMatchingType = BOOL(__stdcall*)(void*, int);
using GetDifficulty = std::uint8_t(__stdcall*)();
using GetQuestInfo = void*(__stdcall*)();
using GetItemPrice = std::uint32_t(__stdcall*)(void*, void*, std::uint32_t,
    std::uint32_t, std::uint32_t, std::uint32_t);
using SendPacket = void(__stdcall*)(std::uint32_t, std::uint32_t, void*);
using ClickMap = void(__stdcall*)(std::uint32_t, std::uint32_t, std::uint32_t,
    std::uint32_t);
using GetMouseOffset = std::uint32_t(__fastcall*)();
using CloseNpcInteract = void(__fastcall*)();
using GetUnitCoordinate = int(__fastcall*)(void*);
using ExitGame = void(__fastcall*)();

#pragma pack(push, 1)
struct Inventory {
    std::uint32_t signature; void* game; void* owner; void* first_item;
    void* last_item;
};
struct ItemData {
    std::uint8_t unused[0x64];
    void* next_inventory_item;
};
struct InventoryLayout {
    std::uint8_t slot_width, slot_height, unused0, unused1;
    std::uint32_t left, right, top, bottom;
    std::uint8_t pixel_width, pixel_height;
};
#pragma pack(pop)

void** player_slot = nullptr;
void** layer_slot = nullptr;
AddRoomData add_room = nullptr;
RemoveRoomData remove_room = nullptr;
RevealRoom reveal_room = nullptr;
DrawLine draw_line = nullptr;
MapToAbsScreen map_to_screen = nullptr;
int* automap_mode = nullptr;
POINT* automap_offset = nullptr;
BOOL* automap_on = nullptr;
DrawText draw_text = nullptr;
SetTextSize set_text_size = nullptr;
GetCurrentNpc get_current_npc = nullptr;
GetUnitStat get_unit_stat = nullptr;
DrawRectangle draw_rectangle = nullptr;
InventoryLayout* store_layout = nullptr;
GetItemName get_item_name = nullptr;
IsMatchingType is_matching_type = nullptr;
GetDifficulty get_difficulty = nullptr;
GetQuestInfo get_quest_info = nullptr;
GetItemPrice get_item_price = nullptr;
SendPacket send_packet = nullptr;
ClickMap click_map = nullptr;
GetMouseOffset get_mouse_x_offset = nullptr;
GetMouseOffset get_mouse_y_offset = nullptr;
CloseNpcInteract close_npc_interact = nullptr;
DWORD* always_run = nullptr;
GetUnitCoordinate get_unit_x = nullptr;
GetUnitCoordinate get_unit_y = nullptr;
ExitGame exit_game = nullptr;
Level* last_level = nullptr;
DWORD next_tick = 0;
DWORD next_monster_tick = 0;
DWORD next_dynamic_tick = 0;
int passes = 0;
volatile long revealed = 0;
POINT selected_target{};
int selected_key = -1;
bool selected_target_valid = false;
std::array<bool, 4> num_down{};
bool num5_down = false;
// 0 = all, 1 = bosses/special minions, 2 = bosses only, 3 = none.
int monster_marker_mode = 0;
const char* overlay_stage = "idle";
void* overlay_fault_address = nullptr;
DWORD overlay_fault_code = 0;
std::array<bool, 6> overlay_stage_enabled{true, true, true, true, true, true};
int render_width = 800;
int render_height = 600;
bool game_session_seen = false;
DWORD lobby_missing_player_since = 0;
DWORD anya_portal_entered_at = 0;
bool auto_buyer_enabled = false;
bool auto_buyer_key_down = false;
DWORD auto_buyer_next_action = 0;
std::uint32_t auto_buyer_last_item = 0;
DWORD auto_buyer_bought_until = 0;
int auto_buyer_bought_skill = 0;
int auto_buyer_bought_fcr = 0;
constexpr int auto_buyer_min_sorceress_bonus = 6;
constexpr int auto_buyer_min_faster_cast_rate = 30;
enum class ShopRefreshState {
    idle, open_npc_session, open_shop, close_shop,
    approach_road, leave_town, return_town
};
ShopRefreshState shop_refresh_state = ShopRefreshState::idle;
DWORD shop_refresh_next_action = 0;
DWORD shop_refresh_deadline = 0;
std::uint32_t shop_refresh_npc_id = 0;
int shop_refresh_route_step = 0;
std::vector<POINT> learned_shop_route;
bool shop_route_recording = false;
bool shop_route_key_down = false;
std::size_t shop_route_index = 0;
struct ShrineMarker { POINT point; std::uint32_t object_id; std::uint8_t effect; };
std::vector<ShrineMarker> shrine_markers;
enum class MonsterMarkerKind : std::uint8_t {
    minion, champion, unique, act_boss, uber
};
enum MonsterElement : std::uint8_t {
    element_physical = 1u << 0,
    element_cold = 1u << 1,
    element_fire = 1u << 2,
    element_lightning = 1u << 3,
    element_poison = 1u << 4,
};
struct SpecialMonster {
    POINT point;
    MonsterMarkerKind kind;
    std::uint8_t immunities;
    std::uint8_t enchantments;
    std::uint8_t life_percent;
};
std::vector<SpecialMonster> special_monsters;
std::vector<POINT> normal_monsters;
std::vector<POINT> special_chests;
struct ContainerMarker { POINT point; std::uint32_t object_id; };
std::vector<ContainerMarker> normal_containers;
std::vector<POINT> opened_containers;
std::vector<POINT> waypoint_markers;
struct PendingShrineRoom {
    void* act;
    Room2* room;
    std::uint32_t level, x, y;
    DWORD ready_at;
};
std::vector<PendingShrineRoom> pending_shrine_rooms;
std::unordered_set<std::uint64_t> processed_rooms;

bool resolve_target(std::uint8_t* player, Level* level,
    const navigation_data::Target& target, POINT& point) noexcept;

namespace imported_shopper {

#pragma pack(push, 1)
struct UnitInteraction {
    DWORD move_type;
    UnitAny* player;
    UnitAny* target;
    DWORD target_x, target_y;
    DWORD unused0, unused1;
};
struct NpcMenu {
    DWORD npc_class_id, entry_count;
    WORD entry_id[4];
    WORD unused;
    DWORD entry_function[4];
    BYTE unused_tail[5];
};
#pragma pack(pop)

using ShopAction = void(__fastcall*)(void*, void*, void*, DWORD, DWORD, DWORD,
    DWORD, DWORD);

NpcMenu* npc_menu_table = nullptr;
DWORD* npc_menu_count = nullptr;
void* interact_internal = nullptr;
ShopAction shop_action = nullptr;
DWORD* client_mouse_x = nullptr;
DWORD* client_mouse_y = nullptr;
int* client_viewport_x = nullptr;
int* client_viewport_y = nullptr;
bool shopper_key_down = false;
bool shopper_active = false;
DWORD shopper_feedback_until = 0;
wchar_t shopper_feedback[96]{};
DWORD shopper_next_action = 0;
DWORD shopper_pending_since = 0;
std::uint32_t shopper_pending_item = 0;
std::uint32_t shopper_reported_winner = 0;
enum class ShopperWalkState : std::uint8_t {
    shopping, leave_town, return_town, approach_drognan, open_drognan, select_trade
};
enum class ShopperProfile : std::uint8_t { none, drognan, anya };
ShopperWalkState shopper_walk_state = ShopperWalkState::shopping;
ShopperProfile shopper_profile = ShopperProfile::none;
DWORD shopper_empty_since = 0;
DWORD shopper_walk_next = 0;
POINT shopper_walk_target{};
bool shopper_walk_target_valid = false;

Level* player_level(std::uint8_t* player) noexcept {
    if (!player) return nullptr;
    auto* path = *reinterpret_cast<std::uint8_t**>(player + 0x2c);
    if (!path) return nullptr;
    auto* room = *reinterpret_cast<Room1**>(path + 0x1c);
    return room && room->room2 ? room->room2->level : nullptr;
}

UnitAny* find_level_unit(Level* level, std::uint32_t type,
    std::uint32_t class_id) noexcept {
    if (!level) return nullptr;
    for (Room2* room = level->first_room; room; room = room->next) {
        if (!room->room1) continue;
        int guard = 0;
        for (UnitAny* unit = room->room1->first_unit;
             unit && guard++ < 1024; unit = unit->room_next) {
            if (unit->type == type && unit->id == class_id) return unit;
        }
    }
    return nullptr;
}

void click_world(long world_x, long world_y) noexcept {
    if (!map_to_screen || !client_viewport_x || !client_viewport_y) return;
    long screen_x = world_x;
    long screen_y = world_y;
    map_to_screen(&screen_x, &screen_y);
    screen_x -= *client_viewport_x;
    screen_y -= *client_viewport_y;
    HWND window = GetForegroundWindow();
    DWORD process_id = 0;
    GetWindowThreadProcessId(window, &process_id);
    if (!window || process_id != GetCurrentProcessId()) return;
    RECT client{};
    if (!GetClientRect(window, &client)) return;
    // Long destinations are projected beyond the viewport. Clicking a point
    // on the same bearing gives Diablo's own walker a short, reachable step.
    screen_x = std::clamp<long>(screen_x, 100, std::max<long>(100, client.right - 140));
    // The bottom ~300 pixels contain the belt and the life/mana bowls at
    // widescreen resolutions. Mouse input there never reaches the world.
    screen_y = std::clamp<long>(screen_y, 90, std::max<long>(90, client.bottom - 320));
    POINT cursor{screen_x, screen_y};
    if (!ClientToScreen(window, &cursor)) return;
    SetCursorPos(cursor.x, cursor.y);
    INPUT input[2]{};
    input[0].type = INPUT_MOUSE;
    input[0].mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
    input[1].type = INPUT_MOUSE;
    input[1].mi.dwFlags = MOUSEEVENTF_LEFTUP;
    SendInput(2, input, sizeof(INPUT));
}

bool select_npc_menu(std::uint32_t npc_class_id, std::uint16_t menu_id) noexcept {
    if (!npc_menu_table || !npc_menu_count) return false;
    const DWORD count = std::min<DWORD>(*npc_menu_count, 256);
    for (DWORD i = 0; i < count; ++i) {
        NpcMenu& menu = npc_menu_table[i];
        if (menu.npc_class_id != npc_class_id) continue;
        for (int entry = 0; entry < 4; ++entry) {
            if (menu.entry_id[entry] != menu_id || !menu.entry_function[entry])
                continue;
            reinterpret_cast<void(*)()>(menu.entry_function[entry])();
            return true;
        }
    }
    return false;
}

__declspec(naked) void __fastcall invoke_interact(void*) {
    __asm {
        mov esi, ecx
        mov eax, interact_internal
        jmp eax
    }
}

void interact_with(UnitAny* player, UnitAny* target) noexcept {
    if (!player || !target) return;
    if (send_packet) {
        BYTE packet[9]{};
        packet[0] = 0x13; // interact with entity
        *reinterpret_cast<DWORD*>(packet + 1) = target->type;
        *reinterpret_cast<DWORD*>(packet + 5) = target->unit_id;
        send_packet(sizeof(packet), 1, packet);
        return;
    }
    if (!interact_internal) return;
    UnitInteraction interaction{
        0, player, target, target->x, target->y, 0, 0};
    invoke_interact(&interaction);
}

struct SkillTreeGroup {
    int tab;
    const int* skills;
    std::size_t count;
};
#define SKILLS(name, ...) static constexpr int name[]{__VA_ARGS__}
SKILLS(asn1,254,255,260,259,265,269,270,275,274,280);
SKILLS(asn2,252,273,278);
SKILLS(asn3,262,366,272,271,276);
SKILLS(bar1,130,131,138,154,142,137,149,150,155,146);
SKILLS(bar2,128,135,134,141,145,148,153,368);
SKILLS(bar3,126,133,147,139,144,140,132,143,152,151,375);
SKILLS(dru1,225,230,229,235,234,240,370,244,245,250,249);
SKILLS(dru2,223,228,224,232,233,242,238,243,239,248);
SKILLS(dru3,221,222,236,227,231,246,237,241,226,247);
// Necromancer shop winners are restricted to build-defining skills. Do not
// alert for one-point utility curses/defenses such as Dim Vision or Terror.
SKILLS(nec1,70,69,80,367);
SKILLS(nec2,92,93);
SKILLS(pal1,99,100,105,110,104,109,115,120,124,125);
SKILLS(pal2,98,102,103,108,113,114,118,119,122,123);
SKILLS(pal3,96,101,97,106,371,107,111,112,116,378,121,117,364);
SKILLS(sor1,44,369,59,64);
SKILLS(sor2,48,49,53);
SKILLS(sor3,383,56,376,62);
#undef SKILLS
#define GROUP(tab, name) {tab, name, std::size(name)}
static constexpr SkillTreeGroup skill_groups[]{
    GROUP(50,asn1),GROUP(49,asn2),GROUP(48,asn3),
    GROUP(34,bar1),GROUP(33,bar2),GROUP(32,bar3),
    GROUP(42,dru1),GROUP(41,dru2),GROUP(40,dru3),
    GROUP(18,nec1),GROUP(17,nec2),{16,nullptr,0},
    GROUP(26,pal1),GROUP(25,pal2),GROUP(24,pal3),
    GROUP(10,sor1),GROUP(9,sor2),GROUP(8,sor3)
};
#undef GROUP

bool has_plus_three(void* item, const int* skills, std::size_t count) noexcept {
    for (std::size_t i = 0; i < count; ++i)
        if (get_unit_stat(item, 107, skills[i]) >= 3) return true;
    return false;
}

int highest_skill_bonus(void* item, const int* skills, std::size_t count) noexcept {
    int highest = 0;
    for (std::size_t i = 0; i < count; ++i) {
        const int bonus = static_cast<int>(get_unit_stat(item, 107, skills[i]));
        if (bonus > highest) highest = bonus;
    }
    return highest;
}

int count_plus_three(void* item, const int* skills, std::size_t count) noexcept {
    int matches = 0;
    for (std::size_t i = 0; i < count; ++i)
        if (get_unit_stat(item, 107, skills[i]) >= 3) ++matches;
    return matches;
}

bool has_matching_sorceress_element(void* item, int tab) noexcept {
    constexpr int stat_fire_damage = 329;
    constexpr int stat_lightning_damage = 330;
    constexpr int stat_cold_damage = 331;
    constexpr int stat_enemy_fire_res = 333;
    constexpr int stat_enemy_lightning_res = 334;
    constexpr int stat_enemy_cold_res = 335;
    if (tab == 8) return get_unit_stat(item, stat_fire_damage, 0) != 0 ||
        get_unit_stat(item, stat_enemy_fire_res, 0) != 0;
    if (tab == 9) return get_unit_stat(item, stat_lightning_damage, 0) != 0 ||
        get_unit_stat(item, stat_enemy_lightning_res, 0) != 0;
    if (tab == 10) return get_unit_stat(item, stat_cold_damage, 0) != 0 ||
        get_unit_stat(item, stat_enemy_cold_res, 0) != 0;
    return false;
}

int sorceress_support_count(void* item, int tab) noexcept {
    // Include useful masteries and utility staffmods when deciding whether a
    // +6 caster weapon is exceptional enough to buy rather than merely flag.
    static constexpr int fire[]{383,56,376,62,63,37};
    static constexpr int lightning[]{48,49,53,61,58,54};
    static constexpr int cold[]{44,369,59,64,65,58};
    if (tab == 8) return count_plus_three(item, fire, std::size(fire));
    if (tab == 9) return count_plus_three(item, lightning, std::size(lightning));
    if (tab == 10) return count_plus_three(item, cold, std::size(cold));
    return 0;
}

int necromancer_support_count(void* item, int tab) noexcept {
    static constexpr int summoning[]{70,69,80,367};
    static constexpr int poison_bone[]{92,83,73,93,84,67,74};
    if (tab == 18)
        return count_plus_three(item, summoning, std::size(summoning));
    if (tab == 17)
        return count_plus_three(item, poison_bone, std::size(poison_bone));
    return 0;
}

bool sorceress_affixes_match_tree(void* item, int tab) noexcept {
    constexpr int stat_fcr = 105;
    constexpr int stat_fire_damage = 329;
    constexpr int stat_lightning_damage = 330;
    constexpr int stat_cold_damage = 331;
    constexpr int stat_enemy_fire_res = 333;
    constexpr int stat_enemy_lightning_res = 334;
    constexpr int stat_enemy_cold_res = 335;

    if (get_unit_stat(item, stat_fcr, 0) < 50) return false;

    const bool has_fire_affix = get_unit_stat(item, stat_fire_damage, 0) != 0 ||
        get_unit_stat(item, stat_enemy_fire_res, 0) != 0;
    const bool has_lightning_affix = get_unit_stat(item, stat_lightning_damage, 0) != 0 ||
        get_unit_stat(item, stat_enemy_lightning_res, 0) != 0;
    const bool has_cold_affix = get_unit_stat(item, stat_cold_damage, 0) != 0 ||
        get_unit_stat(item, stat_enemy_cold_res, 0) != 0;

    // Sorceress tabs: 8 Fire, 9 Lightning, 10 Cold. Matching elemental
    // affixes are optional, but an affix for either wrong element rejects it.
    if (tab == 8) return !has_lightning_affix && !has_cold_affix;
    if (tab == 9) return !has_fire_affix && !has_cold_affix;
    if (tab == 10) return !has_fire_affix && !has_lightning_affix;
    return true;
}

int shop_winner_kind(void* item) noexcept {
    if (!item || !get_unit_stat) return 0;
    for (const auto& group : skill_groups) {
        const bool sorceress_tree = group.tab >= 8 && group.tab <= 10;
        if (sorceress_tree) {
            const int tree_bonus = static_cast<int>(get_unit_stat(item, 188, group.tab));
            const int skill_bonus = highest_skill_bonus(item, group.skills, group.count);
            const int class_bonus = static_cast<int>(get_unit_stat(item, 83, 1));
            if (config().automated_shopper_test_sorc_plus_four &&
                class_bonus + tree_bonus + skill_bonus >= 4) return 4;
            if (class_bonus + tree_bonus + skill_bonus >= 6 &&
                sorceress_affixes_match_tree(item, group.tab)) {
                if (sorceress_support_count(item, group.tab) >= 2 ||
                    has_matching_sorceress_element(item, group.tab)) return 6;
                return 1006; // strong enough to inspect, not auto-buy
            }
        } else if (group.tab == 48 &&
                   get_unit_stat(item, 188, group.tab) >= 3 &&
                   has_plus_three(item, group.skills, group.count)) {
            return 6; // exceptional Trap claws remain valid specialist gear
        } else if ((group.tab == 17 || group.tab == 18) &&
                   get_unit_stat(item, 188, group.tab) >= 3 &&
                   has_plus_three(item, group.skills, group.count) &&
                   get_unit_stat(item, 105, 0) >= 20) {
            if (necromancer_support_count(item, group.tab) >= 2) return 6;
            return 1006; // a plain +6 wand is normally beaten by unique/RW gear
        }
    }
    // Amazon tab bonuses can be granted directly at +6 on class-specific gear.
    for (int tab = 0; tab <= 2; ++tab)
        if (get_unit_stat(item, 188, tab) >= 6) return 6;
    if (is_matching_type) {
        constexpr int item_type_gloves = 16;
        constexpr int item_type_primal_helm = 71;
        constexpr int item_type_claw = 67;
        constexpr int item_type_claw2 = 88;
        constexpr int stat_ias = 93;
        // +3 Bow and Crossbow gloves of Alacrity.
        if (is_matching_type(item, item_type_gloves) &&
            get_unit_stat(item, 188, 0) >= 3 &&
            get_unit_stat(item, stat_ias, 0) >= 20) return 320;
        // Barbarian helms must combine +3 Warcries with +3 BO or Command.
        if (is_matching_type(item, item_type_primal_helm) &&
            get_unit_stat(item, 188, 34) >= 3 &&
            (get_unit_stat(item, 107, 149) >= 3 ||
             get_unit_stat(item, 107, 155) >= 3)) return 6;
        // Shadow Discipline weapons must make +6 Dagger Mastery and also
        // carry Venom or Shadow Warrior. All other Shadow weapons are ignored.
        if ((is_matching_type(item, item_type_claw) ||
             is_matching_type(item, item_type_claw2)) &&
            get_unit_stat(item, stat_ias, 0) >= 40 &&
            get_unit_stat(item, 188, 49) >= 3 &&
            get_unit_stat(item, 107, 252) >= 3 &&
            (get_unit_stat(item, 107, 278) > 0 ||
             get_unit_stat(item, 107, 268) > 0)) return 340;
        // Cunning Trap claws of Quickness; Martial Arts claws are ignored.
        if ((is_matching_type(item, item_type_claw) ||
             is_matching_type(item, item_type_claw2)) &&
            get_unit_stat(item, stat_ias, 0) >= 40 &&
            get_unit_stat(item, 188, 48) >= 3) return 340;
    }
    return 0;
}

bool is_auto_buy_kind(int kind) noexcept {
    return kind > 0 && kind < 1000;
}

void draw_shop_winners() noexcept {
    if (!get_current_npc || !draw_rectangle || !draw_text || !set_text_size ||
        !store_layout) return;
    auto* npc = static_cast<std::uint8_t*>(get_current_npc());
    if (!npc) return;
    auto* inventory = *reinterpret_cast<Inventory**>(npc + 0x60);
    if (!inventory || !inventory->first_item) return;
    int winners = 0;
    int inspect_only = 0;
    std::uint32_t first_winner_id = 0;
    wchar_t winner_name[96]{};
    const bool bright_phase = ((GetTickCount() / 350) & 1) == 0;
    void* raw = inventory->first_item;
    for (int guard = 0; raw && guard < 512; ++guard) {
        auto* item = static_cast<std::uint8_t*>(raw);
        auto* data = *reinterpret_cast<ItemData**>(item + 0x14);
        if (!data) break;
        const int kind = shop_winner_kind(item);
        if (kind) {
            if (!first_winner_id)
                first_winner_id = *reinterpret_cast<std::uint32_t*>(item + 0x0c);
            if (is_auto_buy_kind(kind)) ++winners;
            else ++inspect_only;
            if (winners + inspect_only == 1 && get_item_name) {
                wchar_t raw_name[128]{};
                if (get_item_name(item, raw_name, std::size(raw_name))) {
                    std::size_t out = 0;
                    for (std::size_t in = 0; raw_name[in] && out + 1 < std::size(winner_name); ++in) {
                        if (raw_name[in] == L'\n' || raw_name[in] == L'\r') break;
                        // Diablo color controls are 0xFF, 'c', then one color byte.
                        if (raw_name[in] == 0xff && raw_name[in + 1] == L'c' && raw_name[in + 2]) {
                            in += 2;
                            continue;
                        }
                        winner_name[out++] = raw_name[in];
                    }
                    winner_name[out] = 0;
                }
            }
            const int col = *reinterpret_cast<std::uint16_t*>(item + 0x8c);
            const int row = *reinterpret_cast<std::uint16_t*>(item + 0x8e);
            const int x1 = static_cast<int>(store_layout->left) +
                col * store_layout->pixel_width;
            const int y1 = static_cast<int>(store_layout->top) +
                row * store_layout->pixel_height;
            const int x2 = x1 + std::max<int>(store_layout->pixel_width, 28);
            const int y2 = y1 + std::max<int>(store_layout->pixel_height, 28);
            // Draw only the four edges so the item remains fully visible.
            // Alternate yellow/white to make the location unmistakably flash.
            const std::uint32_t color = is_auto_buy_kind(kind) ?
                (bright_phase ? 0x0d : 0x00) : 0x05;
            constexpr int thickness = 3;
            draw_rectangle(x1, y1, x2, y1 + thickness, color, 1);
            draw_rectangle(x1, y2 - thickness, x2, y2, color, 1);
            draw_rectangle(x1, y1, x1 + thickness, y2, color, 1);
            draw_rectangle(x2 - thickness, y1, x2, y2, color, 1);
        }
        raw = data->next_inventory_item;
    }
    if (!first_winner_id) {
        shopper_reported_winner = 0;
    } else if (first_winner_id != shopper_reported_winner) {
        shopper_reported_winner = first_winner_id;
        char narrow_name[192]{};
        if (winner_name[0])
            WideCharToMultiByte(CP_UTF8, 0, winner_name, -1, narrow_name,
                static_cast<int>(std::size(narrow_name)), nullptr, nullptr);
        char log_message[256]{};
        wsprintfA(log_message, "PASSIVE SHOP WINNER DETECTED: %s (buy=%d inspect=%d)",
            narrow_name[0] ? narrow_name : "name unavailable", winners, inspect_only);
        logger::write(log_message);
    }
    if (winners || inspect_only) {
        wchar_t message[180]{};
        if (!winners && winner_name[0])
            wsprintfW(message, L"SHOP INSPECT ONLY: %s", winner_name);
        else if (winner_name[0] && winners == 1 && !inspect_only)
            wsprintfW(message, L"SHOP WINNER: %s", winner_name);
        else if (winner_name[0])
            wsprintfW(message, L"SHOP BUY %d / INSPECT %d, FIRST: %s",
                winners, inspect_only, winner_name);
        else
            wsprintfW(message, L"SHOP BUY %d / INSPECT %d", winners, inspect_only);
        const auto old = set_text_size(1);
        draw_text(message, 20, 135, 0x0d, 0);
        set_text_size(old);
    }
}

void automated_shopper_frame() noexcept {
    if (!config().automated_shopper || !draw_text || !set_text_size) return;

    const int hotkey = config().automated_shopper_hotkey;
    const SHORT hotkey_state = GetAsyncKeyState(hotkey);
    const bool key_down = (hotkey_state & 0x8000) != 0;
    const bool key_pressed = (hotkey_state & 0x0001) != 0;
    if (key_pressed || (key_down && !shopper_key_down)) {
        if (shopper_active) {
            shopper_active = false;
            shopper_profile = ShopperProfile::none;
            lstrcpyW(shopper_feedback, L"F8 AUTO BUY: OFF");
            logger::write("Automated shopper stopped by hotkey");
        } else {
            auto* selected_npc = get_current_npc ?
                static_cast<std::uint8_t*>(get_current_npc()) : nullptr;
            const auto selected_class = selected_npc ?
                *reinterpret_cast<std::uint32_t*>(selected_npc + 0x04) : 0;
            if (selected_class == 177) shopper_profile = ShopperProfile::drognan;
            else if (selected_class == 512) shopper_profile = ShopperProfile::anya;
            else shopper_profile = ShopperProfile::none;
            shopper_active = shopper_profile != ShopperProfile::none;
            if (shopper_active) {
                lstrcpyW(shopper_feedback, shopper_profile == ShopperProfile::anya ?
                    L"F8 AUTO BUY ANYA: ON" : L"F8 AUTO BUY DROGNAN: ON");
                logger::write(shopper_profile == ShopperProfile::anya
                    ? "Automated shopper armed for Anya"
                    : "Automated shopper armed for Drognan");
            } else {
                lstrcpyW(shopper_feedback,
                    L"F8: OPEN ANYA OR DROGNAN SHOP FIRST");
                logger::write("Automated shopper not armed: open Drognan or Anya shop first");
            }
        }
        shopper_feedback_until = GetTickCount() + 3500;
        shopper_pending_item = 0;
        shopper_pending_since = 0;
        shopper_empty_since = 0;
        shopper_walk_state = ShopperWalkState::shopping;
        shopper_walk_target_valid = false;
        shopper_next_action = GetTickCount() + 500;
    }
    shopper_key_down = key_down;

    if (!shopper_active) {
        if (shopper_feedback[0] &&
            static_cast<LONG>(GetTickCount() - shopper_feedback_until) < 0) {
            const auto old = set_text_size(1);
            draw_text(shopper_feedback, 20, 110, 0x0d, 0);
            set_text_size(old);
        }
        return;
    }

    wchar_t status[96]{};
    const wchar_t* phase = L"SHOP";
    if (shopper_walk_state == ShopperWalkState::leave_town) phase = L"WALK OUT";
    else if (shopper_walk_state == ShopperWalkState::return_town) phase = L"WALK BACK";
    else if (shopper_walk_state == ShopperWalkState::approach_drognan)
        phase = L"DROGNAN";
    else if (shopper_walk_state == ShopperWalkState::open_drognan)
        phase = L"OPEN NPC";
    else if (shopper_walk_state == ShopperWalkState::select_trade)
        phase = L"OPEN TRADE";
    wsprintfW(status, L"SHOPPER %s: %s (F8 stops)",
        shopper_profile == ShopperProfile::anya ? L"ANYA" : L"DROGNAN", phase);
    const auto old_size = set_text_size(1);
    draw_text(status, 20, 155, 0x0d, 0);
    set_text_size(old_size);

    auto* player = player_slot ? static_cast<std::uint8_t*>(*player_slot) : nullptr;
    Level* level = player_level(player);
    const DWORD now = GetTickCount();
    if (!player || !level) return;

    if (shopper_walk_state != ShopperWalkState::shopping) {
        if (!click_map || static_cast<LONG>(now - shopper_walk_next) < 0) return;

        const std::uint32_t merchant_class =
            shopper_profile == ShopperProfile::anya ? 512u : 177u;
        const std::uint32_t town_level =
            shopper_profile == ShopperProfile::anya ? 109u : 40u;
        const std::uint32_t refresh_level =
            shopper_profile == ShopperProfile::anya ? 121u : 41u;

        if (shopper_walk_state == ShopperWalkState::leave_town &&
            level->number == refresh_level) {
            shopper_walk_state = ShopperWalkState::return_town;
            shopper_walk_target_valid = false;
            shopper_walk_next = now +
                (shopper_profile == ShopperProfile::anya ? 50 : 0);
            logger::write(shopper_profile == ShopperProfile::anya
                ? "Automated shopper entered Anya portal; returning immediately"
                : "Automated shopper reached Rocky Waste; returning to town");
        } else if (shopper_walk_state == ShopperWalkState::return_town &&
                   level->number == town_level) {
            shopper_walk_state = ShopperWalkState::approach_drognan;
            shopper_walk_target_valid = false;
            logger::write(shopper_profile == ShopperProfile::anya
                ? "Automated shopper returned to Harrogath"
                : "Automated shopper returned to Lut Gholein");
        }

        if (shopper_walk_state == ShopperWalkState::open_drognan) {
            auto* current = get_current_npc ?
                static_cast<std::uint8_t*>(get_current_npc()) : nullptr;
            if (current && *reinterpret_cast<std::uint32_t*>(current + 0x04) ==
                    merchant_class) {
                shopper_walk_state = ShopperWalkState::select_trade;
                shopper_walk_next = now + 350;
                logger::write(shopper_profile == ShopperProfile::anya
                    ? "Automated shopper opened Anya dialogue"
                    : "Automated shopper opened Drognan dialogue");
                return;
            }
            UnitAny* merchant = find_level_unit(level, 1, merchant_class);
            if (merchant) interact_with(reinterpret_cast<UnitAny*>(player), merchant);
            shopper_walk_next = now + 800;
            return;
        }
        if (shopper_walk_state == ShopperWalkState::select_trade) {
            constexpr std::uint16_t trade_menu_id = 0x0d44;
            if (select_npc_menu(merchant_class, trade_menu_id)) {
                shopper_walk_state = ShopperWalkState::shopping;
                shopper_next_action = now + 1000;
                shopper_empty_since = 0;
                logger::write(shopper_profile == ShopperProfile::anya
                    ? "Automated shopper selected Anya Trade"
                    : "Automated shopper selected Drognan Trade");
            } else {
                shopper_walk_next = now + 500;
            }
            return;
        }

        if (shopper_walk_state == ShopperWalkState::leave_town ||
            shopper_walk_state == ShopperWalkState::return_town) {
            if (shopper_profile == ShopperProfile::anya) {
                // The verified red portal is object class 60 on both level
                // 109 and 121. Interact as soon as it becomes active; do not
                // walk into Nihlathak's Temple or linger after refreshing.
                UnitAny* portal = find_level_unit(level, 2, 60);
                if (!portal) {
                    shopper_walk_next = now + 100;
                    return;
                }
                interact_with(reinterpret_cast<UnitAny*>(player), portal);
                shopper_walk_next = now + 150;
                return;
            }
            const auto* path = *reinterpret_cast<std::uint8_t**>(player + 0x2c);
            if (!path) return;
            const long px = *reinterpret_cast<const std::uint16_t*>(path + 2);
            const long py = *reinterpret_cast<const std::uint16_t*>(path + 6);
            // The east Lut Gholein layout places Drognan beside the Rocky
            // Waste gate. Short northward world steps follow the doorway;
            // reverse them after the level transition.
            if ((shopper_walk_state == ShopperWalkState::leave_town &&
                 level->number == 40) ||
                (shopper_walk_state == ShopperWalkState::return_town &&
                 level->number == 41)) {
                click_world(px, py +
                    (shopper_walk_state == ShopperWalkState::leave_town ? -12 : 12));
                shopper_walk_next = now + 650;
                return;
            }
            const std::uint32_t destination =
                shopper_walk_state == ShopperWalkState::leave_town ? 41u : 40u;
            if (!shopper_walk_target_valid) {
                shopper_walk_target_valid = resolve_target(player, level,
                    navigation_data::Target{6u, destination, 0u, 0u},
                    shopper_walk_target);
                if (!shopper_walk_target_valid) {
                    shopper_active = false;
                    logger::write("Automated shopper stopped: town gate route not found");
                    return;
                }
            }
            click_world(shopper_walk_target.x, shopper_walk_target.y);
            shopper_walk_next = now + 650;
            return;
        }

        UnitAny* merchant = find_level_unit(level, 1, merchant_class);
        if (!merchant) {
            if (shopper_profile == ShopperProfile::anya) {
                shopper_walk_next = now + 100;
                return;
            }
            // Fixed Act II town waypoint used by the established 1.13 town
            // path. It brings Drognan's room into the active-room set; after
            // that we follow the NPC's live coordinates.
            click_world(5097, 5035);
            shopper_walk_next = now + 650;
            return;
        }
        const auto* path = *reinterpret_cast<std::uint8_t**>(player + 0x2c);
        if (!path) return;
        const long px = *reinterpret_cast<const std::uint16_t*>(path + 2);
        const long py = *reinterpret_cast<const std::uint16_t*>(path + 6);
        const long distance = std::abs(px - static_cast<long>(merchant->x)) +
            std::abs(py - static_cast<long>(merchant->y));
        if (distance <= 6) {
            shopper_walk_state = ShopperWalkState::open_drognan;
            interact_with(reinterpret_cast<UnitAny*>(player), merchant);
            shopper_walk_next = now + 800;
            logger::write(shopper_profile == ShopperProfile::anya
                ? "Automated shopper reached Anya; opening dialogue"
                : "Automated shopper reached Drognan; opening dialogue");
            return;
        }
        click_world(merchant->x, merchant->y);
        shopper_walk_next = now + 650;
        return;
    }

    if (!get_current_npc || !shop_action) return;
    auto* npc = static_cast<std::uint8_t*>(get_current_npc());
    if (!npc) return;
    const std::uint32_t merchant_class =
        shopper_profile == ShopperProfile::anya ? 512u : 177u;
    if (*reinterpret_cast<std::uint32_t*>(npc + 0x04) != merchant_class) {
        return;
    }

    auto* inventory = *reinterpret_cast<Inventory**>(npc + 0x60);
    if (!inventory) return;
    void* first_winner = nullptr;
    bool pending_still_in_shop = false;
    void* raw = inventory->first_item;
    for (int guard = 0; raw && guard < 512; ++guard) {
        auto* item = static_cast<std::uint8_t*>(raw);
        auto* data = *reinterpret_cast<ItemData**>(item + 0x14);
        if (!data) break;
        const auto unit_id = *reinterpret_cast<std::uint32_t*>(item + 0x0c);
        if (unit_id == shopper_pending_item) pending_still_in_shop = true;
        if (!first_winner && is_auto_buy_kind(shop_winner_kind(item)))
            first_winner = item;
        raw = data->next_inventory_item;
    }

    if (shopper_pending_item) {
        if (!pending_still_in_shop) {
            logger::write("Automated shopper confirmed purchase");
            shopper_pending_item = 0;
            shopper_pending_since = 0;
            shopper_next_action = now +
                static_cast<DWORD>(config().automated_shopper_buy_cooldown_ms);
        } else if (static_cast<LONG>(now - shopper_pending_since) >= 2000) {
            shopper_active = false;
            shopper_pending_item = 0;
            logger::write("Automated shopper stopped: purchase was not confirmed");
        }
        return;
    }

    if (!first_winner) {
        if (!shopper_empty_since) shopper_empty_since = now;
        if (static_cast<LONG>(now - shopper_empty_since) >= 1500) {
            if (close_npc_interact) close_npc_interact();
            shopper_walk_state = ShopperWalkState::leave_town;
            shopper_walk_target_valid = false;
            shopper_walk_next = now + 500;
            shopper_empty_since = 0;
            logger::write("Automated shopper found no more winners; walking reset started");
        }
        return;
    }
    shopper_empty_since = 0;
    if (static_cast<LONG>(now - shopper_next_action) < 0) return;
    auto* item = static_cast<std::uint8_t*>(first_winner);
    shopper_pending_item = *reinterpret_cast<std::uint32_t*>(item + 0x0c);
    shopper_pending_since = now;
    // Mode 2 is the normal vendor purchase action used by the verified
    // 1.13-era client interface. Buy at most one item before confirmation.
    shop_action(item, npc, npc, 0, 0, 2, 1, 0);
    logger::write("Automated shopper submitted one winner purchase");
}


}  // namespace imported_shopper

// F9 Pindleskin prototype. The right mouse skill must
// already be Chain Lightning Sentry; F9 never changes the player's skill.
enum class PindleState : std::uint8_t { off, travel_portal, enter_portal, approach, fight, loot_probe };
PindleState pindle_state = PindleState::off;
bool pindle_key_down = false;
DWORD pindle_started_at = 0;
DWORD pindle_next_action = 0;
DWORD pindle_last_seen_at = 0;
std::uint32_t pindle_unit_id = 0;
bool pindle_exit_requested = false;
bool pindle_lobby_seen = false;
DWORD pindle_saved_run_mode = 0;
bool pindle_run_mode_forced = false;
POINT pindle_town_last_position{};
DWORD pindle_town_last_moved_at = 0;
bool pindle_town_target_logged = false;
std::size_t pindle_town_route_index = static_cast<std::size_t>(-1);
POINT pindle_last_progress_position{};
std::uint32_t pindle_last_progress_level = 0;
DWORD pindle_last_progress_at = 0;
DWORD pindle_loot_probe_started_at = 0;
bool pindle_loot_probe_logged = false;
std::uint32_t pindle_loot_target_id = 0;
DWORD pindle_loot_pickup_sent_at = 0;
int pindle_loot_pickup_count = 0;
// Track pickups for diagnostics. Item unit IDs are reassigned on joining a
// new game, so cross-game sale decisions must use current backpack data.
std::unordered_set<std::uint32_t> pindle_collected_item_ids;
enum class PindleTownChore : std::uint8_t {
    unplanned, approach_stash, open_stash, transfer_stash,
    approach_anya, open_anya, select_trade, sell, finished
};
PindleTownChore pindle_town_chore = PindleTownChore::unplanned;
std::array<std::uint32_t, 32> pindle_town_sell_ids{};
std::size_t pindle_town_sell_count = 0;
std::size_t pindle_town_sell_index = 0;
std::uint32_t pindle_town_sell_pending_id = 0;
DWORD pindle_town_sell_sent_at = 0;
DWORD pindle_town_chore_started_at = 0;
DWORD pindle_sale_route_trace_at = 0;
std::array<std::uint32_t, 32> pindle_town_stash_ids{};
std::size_t pindle_town_stash_count = 0;
std::size_t pindle_town_stash_index = 0;
std::uint32_t pindle_town_stash_pending_id = 0;
DWORD pindle_town_stash_sent_at = 0;
int pindle_town_stash_tab = 0;
DWORD pindle_town_stash_opened_at = 0;
bool pindle_town_loot_audit_pending = false;
std::array<std::uint32_t, 32> pindle_town_identify_ids{};
std::size_t pindle_town_identify_count = 0;
std::size_t pindle_town_identify_index = 0;
std::uint32_t pindle_town_identify_tome = 0;
DWORD pindle_town_identify_sent_at = 0;
int pindle_town_identify_retries = 0;
bool pindle_town_id_panel_close_sent = false;
constexpr std::array<POINT, 10> pindle_town_route{{
    {5102, 5027}, {5104, 5041}, {5106, 5046}, {5108, 5051},
    // Stay east of the Harrogath waypoint at (5113,5068): clicking its
    // tile opens the travel menu and a later movement click selects an area.
    {5123, 5068}, {5123, 5082}, {5122, 5095},
    // Swing south of the tree/building corner near (5124,5101).
    {5132, 5109}, {5130, 5120}, {5118, 5120}
}};
bool pindle_run_to_town_tile(long x, long y) noexcept {
    if (!click_map || !map_to_screen || !get_mouse_x_offset ||
        !get_mouse_y_offset || x < 5000 || x > 5200 || y < 5000 || y > 5200)
        return false;
    // Use the same internal movement call as the established shop route.
    // Unlike a Windows cursor click, this does not hit the bottom UI bar.
    long screen_x = x;
    long screen_y = y;
    map_to_screen(&screen_x, &screen_y);
    screen_x -= static_cast<long>(get_mouse_x_offset());
    screen_y -= static_cast<long>(get_mouse_y_offset());
    click_map(0, static_cast<std::uint32_t>(screen_x),
        static_cast<std::uint32_t>(screen_y), 0);
    return true;
}
volatile LONG pindle_new_game_pending = 0;
volatile LONG pindle_menu_worker_running = 0;
volatile LONG pindle_create_submitted_at = 0;
int pindle_join_retry_count = 0;

bool pindle_menu_click(HWND window, int x, int y) noexcept {
    if (GetForegroundWindow() != window) return false;
    // cnc-ddraw hooks cursor APIs using its 1068x600 logical game surface.
    // The 1920x1080 screenshots are an upscaled presentation of that surface.
    if (!SetCursorPos(x, y)) return false;
    Sleep(250); // Let the menu sample the new cursor position before pressing.
    // Let the wrapper process the mouse button at the corrected cursor
    // position. Synthetic window messages did not activate the menu button.
    INPUT input{};
    input.type = INPUT_MOUSE;
    input.mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
    if (SendInput(1, &input, sizeof(INPUT)) != 1) return false;
    Sleep(140);
    input.mi.dwFlags = MOUSEEVENTF_LEFTUP;
    return SendInput(1, &input, sizeof(INPUT)) == 1;
}

bool pindle_menu_dialog_visible() noexcept {
    // A small, static patch in the Create Game form's Cancel button is
    // light grey; the same lobby background patch is nearly black.
    HDC dc = GetDC(nullptr);
    if (!dc) return false;
    const COLORREF color = GetPixel(dc, 1200, 745);
    ReleaseDC(nullptr, dc);
    return color != CLR_INVALID && GetRValue(color) > 70 &&
        GetGValue(color) > 65 && GetBValue(color) > 55;
}

DWORD WINAPI pindle_menu_worker(void*) noexcept {
    Sleep(5000); // Give ExitGame and the online lobby transition time to finish.
    HWND window = GetForegroundWindow();
    DWORD process_id = 0;
    GetWindowThreadProcessId(window, &process_id);
    if (!window || process_id != GetCurrentProcessId() ||
        GetSystemMetrics(SM_CXSCREEN) != 1920 ||
        GetSystemMetrics(SM_CYSCREEN) != 1080) {
        char message[128]{};
        wsprintfA(message, "F9 new game stopped: foreground pid=%lu screen=%dx%d",
            process_id, GetSystemMetrics(SM_CXSCREEN),
            GetSystemMetrics(SM_CYSCREEN));
        logger::write(message);
        InterlockedExchange(&pindle_menu_worker_running, 0);
        return 0;
    }
    bool dialog_visible = false;
    for (int attempt = 1; attempt <= 10; ++attempt) {
        if (!pindle_menu_click(window, 590, 460)) break;
        char message[80]{};
        wsprintfA(message, "F9 lobby Create attempt %d", attempt);
        logger::write(message);
        Sleep(2000);
        if (attempt == 1) {
            RECT bounds{};
            GetClientRect(window, &bounds);
            wsprintfA(message, "F9 menu input: calibrated=590,460 window=%ldx%ld",
                bounds.right, bounds.bottom);
            logger::write(message);
        }
        if (pindle_menu_dialog_visible()) {
            dialog_visible = true;
            break;
        }
    }
    if (!dialog_visible) {
        logger::write("F9 new game stopped: Create dialog did not open");
        InterlockedExchange(&pindle_menu_worker_running, 0);
        return 0;
    }
    if (!pindle_menu_click(window, 680, 418)) {
        logger::write("F9 new game stopped: Create Game click failed");
        InterlockedExchange(&pindle_menu_worker_running, 0);
        return 0;
    }
    InterlockedExchange(&pindle_create_submitted_at, static_cast<LONG>(GetTickCount()));
    InterlockedExchange(&pindle_new_game_pending, 1);
    logger::write("F9 clicked Create Game; awaiting Harrogath spawn");
    InterlockedExchange(&pindle_menu_worker_running, 0);
    return 0;
}

void pindle_stop(const char* reason) noexcept {
    pindle_state = PindleState::off;
    if (pindle_run_mode_forced && always_run) *always_run = pindle_saved_run_mode;
    pindle_run_mode_forced = false;
    logger::write(reason);
}

void pindle_audit_inventory(std::uint8_t* player) noexcept {
    pindle_town_loot_audit_pending = false;
    pindle_town_chore = PindleTownChore::unplanned;
    pindle_town_sell_count = 0;
    pindle_town_sell_index = 0;
    pindle_town_sell_pending_id = 0;
    pindle_town_sell_sent_at = 0;
    pindle_town_chore_started_at = 0;
    pindle_sale_route_trace_at = 0;
    pindle_town_stash_count = 0;
    pindle_town_stash_index = 0;
    pindle_town_stash_pending_id = 0;
    pindle_town_stash_sent_at = 0;
    pindle_town_stash_tab = 0;
    pindle_town_stash_opened_at = 0;
    pindle_town_identify_count = 0;
    pindle_town_identify_index = 0;
    pindle_town_identify_tome = 0;
    pindle_town_identify_sent_at = 0;
    pindle_town_identify_retries = 0;
    pindle_town_id_panel_close_sent = false;
    auto* inventory = *reinterpret_cast<Inventory**>(player + 0x60);
    if (!inventory) {
        logger::write("F9 LOOT AUDIT: inventory unavailable");
        return;
    }
    int total = 0;
    int observed = 0;
    int location_counts[256]{};
    int node_counts[256]{};
    void* raw = inventory->first_item;
    for (int guard = 0; raw && guard < 8192; ++guard) {
        auto* item = static_cast<std::uint8_t*>(raw);
        auto* data = *reinterpret_cast<ItemData**>(item + 0x14);
        if (!data) break;
        void* next = data->next_inventory_item;
        const auto quality = *reinterpret_cast<std::uint32_t*>(data);
        const auto flags = *reinterpret_cast<std::uint32_t*>(
            reinterpret_cast<std::uint8_t*>(data) + 0x18);
        const auto page = *(reinterpret_cast<std::uint8_t*>(data) + 0x45);
        const auto node_page = *(reinterpret_cast<std::uint8_t*>(data) + 0x69);
        ++observed;
        ++location_counts[page];
        ++node_counts[node_page];
        if (observed <= 12) {
            char location[160]{};
            wsprintfA(location,
                "F9 LOOT LOCATION: item=%lu base=%lu page45=%u node69=%u quality=%lu flags=%08lX",
                *reinterpret_cast<std::uint32_t*>(item + 0x0c),
                *reinterpret_cast<std::uint32_t*>(item + 0x04),
                page, node_page, quality, flags);
            logger::write(location);
        }
        // ItemData page 0 is carried inventory; exclude equipped,
        // belt, stash and cube items from the previous-run audit.
        if (page == 0) {
            const auto item_id = *reinterpret_cast<std::uint32_t*>(item + 0x0c);
            const auto base_id = *reinterpret_cast<std::uint32_t*>(item + 0x04);
            if (base_id == 534) pindle_town_identify_tome = item_id;
            if ((flags & 0x10) == 0 && quality >= 4 &&
                pindle_town_identify_count < pindle_town_identify_ids.size())
                pindle_town_identify_ids[pindle_town_identify_count++] = item_id;
            wchar_t wide_name[128]{};
            if (get_item_name)
                get_item_name(item, wide_name, std::size(wide_name));
            wchar_t cleaned[96]{};
            std::size_t out = 0;
            for (std::size_t in = 0; wide_name[in] && out + 1 < std::size(cleaned); ++in) {
                if (wide_name[in] == L'\n' || wide_name[in] == L'\r') break;
                if (wide_name[in] == 0xff && wide_name[in + 1] == L'c' &&
                    wide_name[in + 2]) { in += 2; continue; }
                cleaned[out++] = wide_name[in];
            }
            char name[128]{};
            WideCharToMultiByte(CP_UTF8, 0, cleaned, -1, name,
                static_cast<int>(std::size(name)), nullptr, nullptr);
            ++total;
            char message[280]{};
            wsprintfA(message,
                "F9 LOOT AUDIT: item=%lu base=%lu quality=%lu flags=%08lX at=%u,%u grid=%d,%d name=%s",
                *reinterpret_cast<std::uint32_t*>(item + 0x0c),
                *reinterpret_cast<std::uint32_t*>(item + 0x04), quality, flags,
                *reinterpret_cast<std::uint16_t*>(item + 0x8c),
                *reinterpret_cast<std::uint16_t*>(item + 0x8e),
                get_unit_x ? get_unit_x(item) : -1,
                get_unit_y ? get_unit_y(item) : -1,
                name[0] ? name : "(unavailable)");
            logger::write(message);
        }
        raw = next;
    }
    char summary[160]{};
    wsprintfA(summary,
        "F9 LOOT AUDIT: observed=%d carried-page0=%d; no items moved or sold",
        observed, total);
    logger::write(summary);
    char identify_summary[120]{};
    wsprintfA(identify_summary, "F9 ID TOME: %u unidentified backpack items; tome=%s",
        static_cast<unsigned>(pindle_town_identify_count),
        pindle_town_identify_tome ? "present" : "missing");
    logger::write(identify_summary);
    for (int value = 0; value < 256; ++value) {
        if (!location_counts[value] && !node_counts[value]) continue;
        char counts[120]{};
        wsprintfA(counts, "F9 LOOT LOCATIONS: value=%d page45=%d node69=%d",
            value, location_counts[value], node_counts[value]);
        logger::write(counts);
    }
}

bool pindle_identify_town_items(std::uint8_t* player, DWORD now) noexcept {
    if (pindle_town_identify_index >= pindle_town_identify_count) {
        // The ID-tome interaction leaves the backpack open on this client.
        // Send Escape once, only after this run actually identified loot.
        // Never toggle an unrelated UI during a run with no ID targets.
        if (pindle_town_identify_count && !pindle_town_id_panel_close_sent) {
            HWND foreground = GetForegroundWindow();
            DWORD foreground_pid = 0;
            if (foreground)
                GetWindowThreadProcessId(foreground, &foreground_pid);
            if (foreground_pid != GetCurrentProcessId()) return false;
            INPUT input[2]{};
            input[0].type = input[1].type = INPUT_KEYBOARD;
            input[0].ki.wVk = input[1].ki.wVk = VK_ESCAPE;
            input[1].ki.dwFlags = KEYEVENTF_KEYUP;
            if (SendInput(2, input, sizeof(INPUT)) != 2) {
                pindle_stop("F9 ID stopped: could not close inventory panel");
                return false;
            }
            pindle_town_id_panel_close_sent = true;
            pindle_next_action = now + 500;
            logger::write("F9 ID complete; sent one Escape to close backpack");
            return false;
        }
        return true;
    }
    if (!send_packet || !pindle_town_identify_tome) {
        pindle_stop("F9 ID stopped: identification tome or packet sender unavailable");
        return false;
    }
    const auto target_id = pindle_town_identify_ids[pindle_town_identify_index];
    auto* inventory = *reinterpret_cast<Inventory**>(player + 0x60);
    if (!inventory) {
        pindle_stop("F9 ID stopped: inventory unavailable");
        return false;
    }
    void* raw = inventory->first_item;
    std::uint32_t flags = 0;
    bool found = false;
    for (int guard = 0; raw && guard < 8192; ++guard) {
        auto* item = static_cast<std::uint8_t*>(raw);
        auto* data = *reinterpret_cast<ItemData**>(item + 0x14);
        if (!data) break;
        void* next = data->next_inventory_item;
        if (*reinterpret_cast<std::uint32_t*>(item + 0x0c) == target_id &&
            *(reinterpret_cast<std::uint8_t*>(data) + 0x45) == 0) {
            found = true;
            flags = *reinterpret_cast<std::uint32_t*>(
                reinterpret_cast<std::uint8_t*>(data) + 0x18);
            break;
        }
        raw = next;
    }
    if (!found) {
        pindle_stop("F9 ID stopped: target moved from backpack");
        return false;
    }
    if (flags & 0x10) {
        char message[100]{};
        wsprintfA(message, "F9 ID confirmed: item=%lu (%u/%u)", target_id,
            static_cast<unsigned>(pindle_town_identify_index + 1),
            static_cast<unsigned>(pindle_town_identify_count));
        logger::write(message);
        ++pindle_town_identify_index;
        pindle_town_identify_sent_at = 0;
        pindle_town_identify_retries = 0;
        pindle_next_action = now + 350;
        return false;
    }
    if (pindle_town_identify_sent_at &&
        static_cast<LONG>(now - pindle_town_identify_sent_at) < 1200) return false;
    if (pindle_town_identify_retries >= 3) {
        pindle_stop("F9 ID stopped: item did not become identified after three attempts");
        return false;
    }
    std::uint8_t packet[9]{};
    packet[0] = 0x27; // D2GS_IDENTIFYITEM: item ID, ID tome ID.
    std::memcpy(packet + 1, &target_id, sizeof(target_id));
    std::memcpy(packet + 5, &pindle_town_identify_tome,
        sizeof(pindle_town_identify_tome));
    send_packet(sizeof(packet), 1, packet);
    ++pindle_town_identify_retries;
    pindle_town_identify_sent_at = now;
    char message[100]{};
    wsprintfA(message, "F9 ID request: item=%lu attempt=%d",
        target_id, pindle_town_identify_retries);
    logger::write(message);
    return false;
}

std::uint8_t* pindle_find_backpack_item(std::uint8_t* player,
    std::uint32_t item_id) noexcept {
    if (!player) return nullptr;
    auto* inventory = *reinterpret_cast<Inventory**>(player + 0x60);
    if (!inventory) return nullptr;
    void* raw = inventory->first_item;
    for (int guard = 0; raw && guard < 8192; ++guard) {
        auto* item = static_cast<std::uint8_t*>(raw);
        auto* data = *reinterpret_cast<ItemData**>(item + 0x14);
        if (!data) break;
        void* next = data->next_inventory_item;
        if (*reinterpret_cast<std::uint32_t*>(item + 0x0c) == item_id &&
            *(reinterpret_cast<std::uint8_t*>(data) + 0x45) == 0)
            return item;
        raw = next;
    }
    return nullptr;
}

bool pindle_is_sell_candidate(std::uint8_t* item,
    bool collected_by_f9) noexcept {
    if (!item || !is_matching_type) return false;
    (void)collected_by_f9;
    // Sell spare rejuvenation potions in the backpack, never belt potions.
    if (is_matching_type(item, 78)) return true;
    auto* data = *reinterpret_cast<ItemData**>(item + 0x14);
    if (!data) return false;
    const auto quality = *reinterpret_cast<const std::uint32_t*>(data);
    const auto flags = *reinterpret_cast<const std::uint32_t*>(
        reinterpret_cast<const std::uint8_t*>(data) + 0x18);
    // The user currently wants both magic and rare backpack equipment sold.
    if ((quality != 4 && quality != 6) || !(flags & 0x10)) return false;
    // Keep charms and jewels, regardless of magic/rare quality.
    if (is_matching_type(item, 13) || is_matching_type(item, 58)) return false;
    // Protect +2 class-skill circlets/tiaras even when rare.
    if (is_matching_type(item, 75)) {
        if (!get_unit_stat) return false;
        for (std::uint32_t cls = 0; cls < 7; ++cls)
            if (get_unit_stat(item, 83, cls) >= 2) return false;
    }
    return true;
}

bool pindle_is_stash_candidate(std::uint8_t* item) noexcept {
    if (!item) return false;
    auto* data = *reinterpret_cast<ItemData**>(item + 0x14);
    if (!data) return false;
    const auto base = *reinterpret_cast<std::uint32_t*>(item + 0x04);
    const auto quality = *reinterpret_cast<std::uint32_t*>(data);
    // Initial safe set: Worldstone Shards and uniques. Magic charms in the
    // permanent backpack deliberately remain untouched until provenance is
    // tracked across games; a quality-only rule would steal equipped charms.
    return base == 674 || quality == 7;
}

// Withdrawn after the 2026-09-14 town-route regression. Never re-enable
// without a verified inventory-provenance rule and an isolated stash test.
constexpr bool pindle_stash_experiment_enabled = false;

bool pindle_stash_item_is_on_page(std::uint8_t* player,
    std::uint32_t item_id) noexcept {
    auto* inventory = player ? *reinterpret_cast<Inventory**>(player + 0x60) : nullptr;
    if (!inventory) return false;
    void* raw = inventory->first_item;
    for (int guard = 0; raw && guard < 8192; ++guard) {
        auto* item = static_cast<std::uint8_t*>(raw);
        auto* data = *reinterpret_cast<ItemData**>(item + 0x14);
        if (!data) break;
        void* next = data->next_inventory_item;
        if (*reinterpret_cast<std::uint32_t*>(item + 0x0c) == item_id)
            return *(reinterpret_cast<std::uint8_t*>(data) + 0x45) == 5;
        raw = next;
    }
    return false;
}

void pindle_log_stashed_item(std::uint8_t* player, std::uint32_t item_id,
    int tab) noexcept {
    auto* inventory = player ? *reinterpret_cast<Inventory**>(player + 0x60) : nullptr;
    if (!inventory) return;
    std::uint32_t base = 0;
    std::uint32_t quality = 0;
    char name[128]{};
    void* raw = inventory->first_item;
    for (int guard = 0; raw && guard < 8192; ++guard) {
        auto* item = static_cast<std::uint8_t*>(raw);
        auto* data = *reinterpret_cast<ItemData**>(item + 0x14);
        if (!data) break;
        void* next = data->next_inventory_item;
        if (*reinterpret_cast<std::uint32_t*>(item + 0x0c) == item_id) {
            base = *reinterpret_cast<std::uint32_t*>(item + 0x04);
            quality = *reinterpret_cast<std::uint32_t*>(data);
            wchar_t wide[128]{};
            if (get_item_name && get_item_name(item, wide, std::size(wide))) {
                wchar_t clean[128]{};
                std::size_t out = 0;
                for (std::size_t i = 0; wide[i] && out + 1 < std::size(clean); ++i) {
                    if (wide[i] == L'\r' || wide[i] == L'\n') break;
                    if (wide[i] == 0xff && wide[i + 1] == L'c' && wide[i + 2]) {
                        i += 2; continue;
                    }
                    clean[out++] = wide[i] == L',' || wide[i] == L'"' ? L' ' : wide[i];
                }
                WideCharToMultiByte(CP_UTF8, 0, clean, -1, name,
                    static_cast<int>(std::size(name)), nullptr, nullptr);
            }
            break;
        }
        raw = next;
    }
    HMODULE module = nullptr;
    if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
            GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
            reinterpret_cast<LPCWSTR>(&pindle_log_stashed_item), &module)) return;
    wchar_t path[MAX_PATH]{};
    const DWORD length = GetModuleFileNameW(module, path, MAX_PATH);
    if (!length || length >= MAX_PATH) return;
    wchar_t* separator = wcsrchr(path, L'\\');
    if (!separator) return;
    *(separator + 1) = L'\0';
    if (wcscat_s(path, L"StashedItems.csv") != 0) return;
    HANDLE file = CreateFileW(path, FILE_APPEND_DATA, FILE_SHARE_READ, nullptr,
        OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (file == INVALID_HANDLE_VALUE) return;
    SYSTEMTIME time{};
    GetLocalTime(&time);
    char line[300]{};
    const int size = wsprintfA(line,
        "%04u-%02u-%02u %02u:%02u:%02u,%d,%lu,%lu,%lu,%s\r\n",
        time.wYear, time.wMonth, time.wDay, time.wHour, time.wMinute,
        time.wSecond, tab, item_id, base, quality,
        name[0] ? name : "(unknown)");
    DWORD written = 0;
    WriteFile(file, line, static_cast<DWORD>(size), &written, nullptr);
    CloseHandle(file);
}

bool pindle_stash_click(int screenshot_x, int screenshot_y,
    bool shift_right) noexcept {
    HWND window = GetForegroundWindow();
    DWORD pid = 0;
    if (window) GetWindowThreadProcessId(window, &pid);
    if (!window || pid != GetCurrentProcessId()) return false;
    RECT bounds{};
    if (!GetClientRect(window, &bounds) || bounds.right <= 0 || bounds.bottom <= 0)
        return false;
    POINT cursor{
        MulDiv(screenshot_x, bounds.right, 1920),
        MulDiv(screenshot_y, bounds.bottom, 1080)};
    if (!ClientToScreen(window, &cursor) || !SetCursorPos(cursor.x, cursor.y))
        return false;
    INPUT events[4]{};
    if (shift_right) {
        events[0].type = events[1].type = events[2].type = events[3].type = INPUT_KEYBOARD;
        events[0].ki.wVk = VK_SHIFT;
        events[1].type = events[2].type = INPUT_MOUSE;
        events[1].mi.dwFlags = MOUSEEVENTF_RIGHTDOWN;
        events[2].mi.dwFlags = MOUSEEVENTF_RIGHTUP;
        events[3].ki.wVk = VK_SHIFT;
        events[3].ki.dwFlags = KEYEVENTF_KEYUP;
        return SendInput(4, events, sizeof(INPUT)) == 4;
    }
    events[0].type = events[1].type = INPUT_MOUSE;
    events[0].mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
    events[1].mi.dwFlags = MOUSEEVENTF_LEFTUP;
    return SendInput(2, events, sizeof(INPUT)) == 2;
}

void pindle_plan_town_sales(std::uint8_t* player) noexcept {
    pindle_town_sell_count = 0;
    pindle_town_stash_count = 0;
    auto* inventory = player ? *reinterpret_cast<Inventory**>(player + 0x60) : nullptr;
    if (!inventory) {
        pindle_stop("F9 town chores stopped: backpack unavailable");
        return;
    }
    void* raw = inventory->first_item;
    for (int guard = 0; raw && guard < 8192; ++guard) {
        auto* item = static_cast<std::uint8_t*>(raw);
        auto* data = *reinterpret_cast<ItemData**>(item + 0x14);
        if (!data) break;
        void* next = data->next_inventory_item;
        if (*(reinterpret_cast<std::uint8_t*>(data) + 0x45) == 0) {
            const auto item_id = *reinterpret_cast<std::uint32_t*>(item + 0x0c);
            const bool collected = pindle_collected_item_ids.contains(item_id);
            if (pindle_is_sell_candidate(item, collected) &&
                pindle_town_sell_count < pindle_town_sell_ids.size()) {
                pindle_town_sell_ids[pindle_town_sell_count++] = item_id;
                char message[120]{};
                wsprintfA(message, "F9 sale candidate: item=%lu source=backpack magic/rare/rejuv",
                    item_id);
                logger::write(message);
            } else if (pindle_stash_experiment_enabled &&
                pindle_is_stash_candidate(item) &&
                pindle_town_stash_count < pindle_town_stash_ids.size()) {
                pindle_town_stash_ids[pindle_town_stash_count++] = item_id;
            }
        }
        raw = next;
    }
    char summary[100]{};
    wsprintfA(summary, "F9 town plan: %u stash, %u sale candidates",
        static_cast<unsigned>(pindle_town_stash_count),
        static_cast<unsigned>(pindle_town_sell_count));
    logger::write(summary);
    pindle_town_chore = pindle_town_stash_count ?
        PindleTownChore::approach_stash : (pindle_town_sell_count ?
            PindleTownChore::approach_anya : PindleTownChore::finished);
    pindle_town_chore_started_at = GetTickCount();
}

bool pindle_process_town_sales(std::uint8_t* player, Level* level,
    DWORD now) noexcept {
    if (pindle_town_chore == PindleTownChore::unplanned) {
        pindle_plan_town_sales(player);
        return false;
    }
    if (pindle_town_chore == PindleTownChore::finished) return true;
    if (static_cast<LONG>(now - pindle_town_chore_started_at) >= 120000) {
        pindle_stop("F9 town chores stopped: stash/sale timeout; no game remake");
        return false;
    }
    if (static_cast<LONG>(now - pindle_next_action) < 0) return false;
    if (pindle_town_chore == PindleTownChore::approach_stash) {
        auto* path = *reinterpret_cast<std::uint8_t**>(player + 0x2c);
        if (!path) return false;
        const long px = *reinterpret_cast<std::uint16_t*>(path + 2);
        const long py = *reinterpret_cast<std::uint16_t*>(path + 6);
        if (pindle_town_route_index == static_cast<std::size_t>(-1)) {
            long closest = LONG_MAX;
            for (std::size_t i = 0; i < pindle_town_route.size(); ++i) {
                const long distance = std::abs(pindle_town_route[i].x - px) +
                    std::abs(pindle_town_route[i].y - py);
                if (distance < closest) { closest = distance; pindle_town_route_index = i; }
            }
        }
        while (pindle_town_route_index < pindle_town_route.size() &&
            std::max(std::abs(pindle_town_route[pindle_town_route_index].x - px),
                std::abs(pindle_town_route[pindle_town_route_index].y - py)) <= 3)
            ++pindle_town_route_index;
        auto* stash = imported_shopper::find_level_unit(level, 2, 267);
        if (pindle_town_route_index < pindle_town_route.size() || !stash) {
            const POINT destination = pindle_town_route[std::min(pindle_town_route_index,
                pindle_town_route.size() - 1)];
            const long dx = destination.x - px, dy = destination.y - py;
            const long distance = std::max(std::abs(dx), std::abs(dy));
            if (distance > 0) {
                const long step = std::min<long>(8, distance);
                pindle_run_to_town_tile(px + dx * step / distance,
                    py + dy * step / distance);
            }
            pindle_next_action = now + 500;
            return false;
        }
        const int distance = std::max(std::abs(px - static_cast<long>(stash->x)),
            std::abs(py - static_cast<long>(stash->y)));
        if (distance > 6) {
            const long dx = static_cast<long>(stash->x) - px;
            const long dy = static_cast<long>(stash->y) - py;
            const long step = std::min<long>(8, distance);
            pindle_run_to_town_tile(px + dx * step / distance,
                py + dy * step / distance);
        } else {
            imported_shopper::interact_with(
                reinterpret_cast<UnitAny*>(player), stash);
            pindle_town_chore = PindleTownChore::open_stash;
            pindle_town_stash_opened_at = now;
            logger::write("F9 stash: interacting with Harrogath bank");
        }
        pindle_next_action = now + 600;
        return false;
    }
    if (pindle_town_chore == PindleTownChore::open_stash) {
        if (static_cast<LONG>(now - pindle_town_stash_opened_at) < 900)
            return false;
        // Always select the personal page first; the last selected tab is not
        // stable across games. The screenshot shows P, I..IX at 52 px steps.
        if (!pindle_stash_click(438, 65, false)) {
            pindle_stop("F9 stash stopped: cannot select personal tab");
            return false;
        }
        pindle_town_stash_tab = 0;
        pindle_town_chore = PindleTownChore::transfer_stash;
        pindle_next_action = now + 500;
        logger::write("F9 stash: selected personal tab");
        return false;
    }
    if (pindle_town_chore == PindleTownChore::transfer_stash) {
        if (pindle_town_stash_pending_id) {
            if (pindle_stash_item_is_on_page(player, pindle_town_stash_pending_id)) {
                char message[120]{};
                wsprintfA(message, "F9 stash confirmed: item=%lu tab=%d",
                    pindle_town_stash_pending_id, pindle_town_stash_tab);
                logger::write(message);
                pindle_log_stashed_item(player, pindle_town_stash_pending_id,
                    pindle_town_stash_tab);
                pindle_town_stash_pending_id = 0;
                ++pindle_town_stash_index;
                pindle_next_action = now + 500;
                return false;
            }
            if (!pindle_find_backpack_item(player, pindle_town_stash_pending_id)) {
                pindle_stop("F9 stash stopped: item left backpack but not found in stash");
                return false;
            }
            if (static_cast<LONG>(now - pindle_town_stash_sent_at) < 1800)
                return false;
            if (++pindle_town_stash_tab >= 10) {
                pindle_stop("F9 stash full or transfer failed on all 10 tabs; sort manually");
                return false;
            }
            if (!pindle_stash_click(438 + 52 * pindle_town_stash_tab, 65, false)) {
                pindle_stop("F9 stash stopped: cannot change tab");
                return false;
            }
            pindle_town_stash_pending_id = 0;
            pindle_next_action = now + 550;
            return false;
        }
        if (pindle_town_stash_index >= pindle_town_stash_count) {
            INPUT input[2]{};
            input[0].type = input[1].type = INPUT_KEYBOARD;
            input[0].ki.wVk = input[1].ki.wVk = VK_ESCAPE;
            input[1].ki.dwFlags = KEYEVENTF_KEYUP;
            SendInput(2, input, sizeof(INPUT));
            pindle_town_chore = pindle_town_sell_count ?
                PindleTownChore::approach_anya : PindleTownChore::finished;
            pindle_next_action = now + 500;
            logger::write("F9 stash batch complete; closing stash");
            return false;
        }
        const auto item_id = pindle_town_stash_ids[pindle_town_stash_index];
        auto* item = pindle_find_backpack_item(player, item_id);
        if (!item || !pindle_is_stash_candidate(item) || !get_unit_x || !get_unit_y) {
            pindle_stop("F9 stash stopped: keeper changed or grid unavailable");
            return false;
        }
        const int col = get_unit_x(item), row = get_unit_y(item);
        if (col < 0 || col >= 10 || row < 0 || row >= 8) {
            char message[112]{};
            wsprintfA(message, "F9 stash stopped: item grid coordinate (%d,%d) invalid",
                col, row);
            pindle_stop(message);
            return false;
        }
        // A bad item-coordinate binding can report (0,0) for every item.
        // Never click a grid cell unless its origin is unique in the backpack.
        auto* inventory = *reinterpret_cast<Inventory**>(player + 0x60);
        void* raw = inventory ? inventory->first_item : nullptr;
        for (int guard = 0; raw && guard < 8192; ++guard) {
            auto* other = static_cast<std::uint8_t*>(raw);
            auto* data = *reinterpret_cast<ItemData**>(other + 0x14);
            if (!data) break;
            void* next = data->next_inventory_item;
            if (other != item &&
                *(reinterpret_cast<std::uint8_t*>(data) + 0x45) == 0 &&
                get_unit_x(other) == col && get_unit_y(other) == row) {
                pindle_stop("F9 stash stopped: ambiguous backpack grid coordinate");
                return false;
            }
            raw = next;
        }
        if (!pindle_stash_click(1011 + 52 * col, 476 + 52 * row, true)) {
            pindle_stop("F9 stash stopped: shift-right-click failed");
            return false;
        }
        pindle_town_stash_pending_id = item_id;
        pindle_town_stash_sent_at = now;
        char message[128]{};
        wsprintfA(message, "F9 stash transfer requested: item=%lu grid=%d,%d tab=%d",
            item_id, col, row, pindle_town_stash_tab);
        logger::write(message);
        return false;
    }
    constexpr std::uint32_t anya_class = 512;
    auto* anya = imported_shopper::find_level_unit(level, 1, anya_class);
    if (pindle_town_chore == PindleTownChore::approach_anya) {
        if (!anya || pindle_town_route_index < pindle_town_route.size()) {
            // Anya is not in an active room at Harrogath spawn. Follow the
            // already-proven portal route all the way to her side of town.
            // Seeing her early does not mean a direct path across the stairs
            // is walkable; that shortcut caused the repeated stall.
            auto* path = *reinterpret_cast<std::uint8_t**>(player + 0x2c);
            if (!path) return false;
            const long px = *reinterpret_cast<std::uint16_t*>(path + 2);
            const long py = *reinterpret_cast<std::uint16_t*>(path + 6);
            if (pindle_town_route_index == static_cast<std::size_t>(-1)) {
                long closest = LONG_MAX;
                for (std::size_t i = 0; i < pindle_town_route.size(); ++i) {
                    const long distance = std::abs(pindle_town_route[i].x - px) +
                        std::abs(pindle_town_route[i].y - py);
                    if (distance < closest) {
                        closest = distance;
                        pindle_town_route_index = i;
                    }
                }
                logger::write("F9 sale: walking from spawn toward Anya's room");
            }
            while (pindle_town_route_index < pindle_town_route.size() &&
                std::max(std::abs(pindle_town_route[pindle_town_route_index].x - px),
                    std::abs(pindle_town_route[pindle_town_route_index].y - py)) <= 3)
                ++pindle_town_route_index;
            if (pindle_town_route_index < pindle_town_route.size()) {
                const POINT destination = pindle_town_route[pindle_town_route_index];
                const long dx = destination.x - px;
                const long dy = destination.y - py;
                const long distance = std::max(std::abs(dx), std::abs(dy));
                if (distance > 0) {
                    const long step = std::min<long>(8, distance);
                    const long target_x = px + dx * step / distance;
                    const long target_y = py + dy * step / distance;
                    const bool sent = pindle_run_to_town_tile(target_x, target_y);
                    if (!pindle_sale_route_trace_at ||
                        static_cast<LONG>(now - pindle_sale_route_trace_at) >= 3000) {
                        char trace[156]{};
                        wsprintfA(trace,
                            "F9 sale route: player=(%ld,%ld) waypoint=%u target=(%ld,%ld) click=%d",
                            px, py, static_cast<unsigned>(pindle_town_route_index),
                            target_x, target_y, sent ? 1 : 0);
                        logger::write(trace);
                        pindle_sale_route_trace_at = now;
                    }
                }
            }
            pindle_next_action = now + 500;
            return false;
        }
        auto* path = *reinterpret_cast<std::uint8_t**>(player + 0x2c);
        if (!path) return false;
        const int px = *reinterpret_cast<std::uint16_t*>(path + 2);
        const int py = *reinterpret_cast<std::uint16_t*>(path + 6);
        const int distance = std::max(std::abs(px - static_cast<int>(anya->x)),
            std::abs(py - static_cast<int>(anya->y)));
        if (distance > 6) {
            pindle_run_to_town_tile(anya->x, anya->y);
            pindle_next_action = now + 650;
        } else {
            imported_shopper::interact_with(
                reinterpret_cast<UnitAny*>(player), anya);
            pindle_town_chore = PindleTownChore::open_anya;
            pindle_next_action = now + 600;
            logger::write("F9 town chores: opening Anya dialogue");
        }
        return false;
    }
    auto* current_npc = get_current_npc ?
        static_cast<UnitAny*>(get_current_npc()) : nullptr;
    if (!current_npc || current_npc->id != anya_class) {
        if (pindle_town_chore == PindleTownChore::open_anya && anya)
            imported_shopper::interact_with(
                reinterpret_cast<UnitAny*>(player), anya);
        pindle_next_action = now + 600;
        return false;
    }
    if (pindle_town_chore == PindleTownChore::open_anya)
        pindle_town_chore = PindleTownChore::select_trade;
    if (pindle_town_chore == PindleTownChore::select_trade) {
        if (imported_shopper::select_npc_menu(anya_class, 0x0d44)) {
            pindle_town_chore = PindleTownChore::sell;
            pindle_next_action = now + 700;
            logger::write("F9 town chores: selected Anya Trade");
        } else pindle_next_action = now + 400;
        return false;
    }
    if (pindle_town_sell_pending_id) {
        if (!pindle_find_backpack_item(player, pindle_town_sell_pending_id)) {
            char message[100]{};
            wsprintfA(message, "F9 sale confirmed: item=%lu (%u/%u)",
                pindle_town_sell_pending_id,
                static_cast<unsigned>(pindle_town_sell_index + 1),
                static_cast<unsigned>(pindle_town_sell_count));
            logger::write(message);
            pindle_collected_item_ids.erase(pindle_town_sell_pending_id);
            pindle_town_sell_pending_id = 0;
            ++pindle_town_sell_index;
            pindle_next_action = now + 450;
        } else if (static_cast<LONG>(now - pindle_town_sell_sent_at) >= 2500)
            pindle_stop("F9 sale not confirmed; stopped without retry");
        return false;
    }
    if (pindle_town_sell_index >= pindle_town_sell_count) {
        if (close_npc_interact) close_npc_interact();
        pindle_town_chore = PindleTownChore::finished;
        pindle_next_action = now + 500;
        logger::write("F9 town chores: sale batch complete");
        return false;
    }
    const auto item_id = pindle_town_sell_ids[pindle_town_sell_index];
    auto* item = pindle_find_backpack_item(player, item_id);
    if (!item) {
        pindle_stop("F9 sale stopped: candidate changed location before sale");
        return false;
    }
    const bool collected = pindle_collected_item_ids.contains(item_id);
    if (!pindle_is_sell_candidate(item, collected) || !send_packet) {
        pindle_stop("F9 sale stopped: candidate failed final safety check");
        return false;
    }
    std::uint8_t packet[17]{};
    packet[0] = 0x33; // D2GS_NPCSELL: NPC ID, item ID, buffer type, cost.
    std::memcpy(packet + 1, &current_npc->unit_id, 4);
    std::memcpy(packet + 5, &item_id, 4);
    send_packet(sizeof(packet), 1, packet);
    pindle_town_sell_pending_id = item_id;
    pindle_town_sell_sent_at = now;
    logger::write("F9 sale submitted one confirmed candidate to Anya");
    return false;
}

void pindle_leave_game(const char* reason) noexcept {
    pindle_state = PindleState::off;
    if (pindle_run_mode_forced && always_run) *always_run = pindle_saved_run_mode;
    pindle_run_mode_forced = false;
    if (!exit_game) {
        logger::write("F9 Pindleskin cannot leave game: ExitGame binding missing");
        return;
    }
    logger::write(reason);
    pindle_exit_requested = true;
    pindle_lobby_seen = false;
    pindle_join_retry_count = 0;
    InterlockedExchange(&pindle_create_submitted_at, 0);
    InterlockedExchange(&pindle_new_game_pending, 0);
    if (InterlockedCompareExchange(&pindle_menu_worker_running, 1, 0) == 0) {
        HANDLE worker = CreateThread(nullptr, 0, pindle_menu_worker,
            nullptr, 0, nullptr);
        if (worker) CloseHandle(worker);
        else {
            InterlockedExchange(&pindle_menu_worker_running, 0);
            logger::write("F9 new game stopped: menu worker could not start");
        }
    }
    exit_game(); // normal client save-and-exit; keep Game.exe running
}

void pindle_cast_at(const UnitAny* target) noexcept {
    if (!target || !map_to_screen ||
        !imported_shopper::client_viewport_x ||
        !imported_shopper::client_viewport_y) return;
    long x = target->x, y = target->y;
    map_to_screen(&x, &y);
    x -= *imported_shopper::client_viewport_x;
    y -= *imported_shopper::client_viewport_y;
    HWND window = GetForegroundWindow();
    DWORD process_id = 0;
    GetWindowThreadProcessId(window, &process_id);
    if (!window || process_id != GetCurrentProcessId()) return;
    RECT client{};
    if (!GetClientRect(window, &client) || x < 80 || y < 60 ||
        x >= client.right - 80 || y >= client.bottom - 300) return;
    POINT cursor{x, y};
    if (!ClientToScreen(window, &cursor) || !SetCursorPos(cursor.x, cursor.y))
        return;
    INPUT input[2]{};
    input[0].type = input[1].type = INPUT_MOUSE;
    input[0].mi.dwFlags = MOUSEEVENTF_RIGHTDOWN;
    input[1].mi.dwFlags = MOUSEEVENTF_RIGHTUP;
    SendInput(2, input, sizeof(INPUT));
}

enum class MalahTestState : std::uint8_t {
    off, walk, dialogue, trade, buy, confirm
};
MalahTestState malah_test_state = MalahTestState::off;
bool malah_test_key_down = false;
DWORD malah_test_started_at = 0;
DWORD malah_test_next_action = 0;
DWORD malah_test_last_progress_at = 0;
POINT malah_test_last_position{};
std::uint32_t malah_test_tome_id = 0;
std::uint32_t malah_test_quantity_before = 0;
DWORD malah_test_buy_at = 0;

std::uint8_t* malah_test_id_tome(std::uint8_t* player) noexcept {
    auto* inventory = player ? *reinterpret_cast<Inventory**>(player + 0x60) : nullptr;
    if (!inventory) return nullptr;
    void* raw = inventory->first_item;
    for (int guard = 0; raw && guard < 8192; ++guard) {
        auto* item = static_cast<std::uint8_t*>(raw);
        auto* data = *reinterpret_cast<ItemData**>(item + 0x14);
        if (!data) break;
        void* next = data->next_inventory_item;
        if (*reinterpret_cast<std::uint32_t*>(item + 0x04) == 534 &&
            *(reinterpret_cast<std::uint8_t*>(data) + 0x45) == 0)
            return item;
        raw = next;
    }
    return nullptr;
}

void malah_test_stop(const char* reason) noexcept {
    logger::write(reason);
    malah_test_state = MalahTestState::off;
    if (pindle_run_mode_forced && pindle_state == PindleState::off && always_run) {
        *always_run = pindle_saved_run_mode;
        pindle_run_mode_forced = false;
    }
}

void malah_test_frame() noexcept {
    const bool down = (GetAsyncKeyState(VK_F10) & 0x8000) != 0;
    if (down && !malah_test_key_down) {
        if (malah_test_state != MalahTestState::off) {
            malah_test_stop("F10 Malah test cancelled");
        } else {
            auto* player = player_slot ? static_cast<std::uint8_t*>(*player_slot) : nullptr;
            Level* level = imported_shopper::player_level(player);
            if (pindle_state == PindleState::off && level && level->number == 109) {
                auto* tome = malah_test_id_tome(player);
                if (!tome || !get_unit_stat) {
                    logger::write("F10 Malah test unavailable: ID tome/stat binding missing");
                } else {
                    malah_test_tome_id = *reinterpret_cast<std::uint32_t*>(tome + 0x0c);
                    malah_test_state = MalahTestState::walk;
                    malah_test_started_at = GetTickCount();
                    malah_test_last_progress_at = 0;
                    malah_test_next_action = 0;
                    if (always_run && !pindle_run_mode_forced) {
                        pindle_saved_run_mode = *always_run;
                        *always_run = 1;
                        pindle_run_mode_forced = true;
                    }
                    char message[112]{};
                    wsprintfA(message, "F10 Malah test started: ID tome=%lu quantity=%lu",
                        malah_test_tome_id, get_unit_stat(tome, 70, 0));
                    logger::write(message);
                }
            } else logger::write("F10 Malah test: start in Harrogath with F9 off");
        }
    }
    malah_test_key_down = down;
    if (malah_test_state == MalahTestState::off) return;
    if (pindle_state != PindleState::off) {
        malah_test_stop("F10 Malah test stopped: F9 took control");
        return;
    }
    const DWORD now = GetTickCount();
    if (static_cast<LONG>(now - malah_test_started_at) >= 90000) {
        malah_test_stop("F10 Malah test stopped: 90-second timeout");
        return;
    }
    if (draw_text && set_text_size) {
        wchar_t label[] = L"F10 MALAH ID-SCROLL TEST";
        const auto old = set_text_size(1);
        draw_text(label, 20, 205, 0x0d, 0);
        set_text_size(old);
    }
    auto* player = player_slot ? static_cast<std::uint8_t*>(*player_slot) : nullptr;
    Level* level = imported_shopper::player_level(player);
    auto* tome = malah_test_id_tome(player);
    if (!player || !level || level->number != 109 || !tome ||
        *reinterpret_cast<std::uint32_t*>(tome + 0x0c) != malah_test_tome_id) {
        malah_test_stop("F10 Malah test stopped: town or ID tome changed");
        return;
    }
    if (static_cast<LONG>(now - malah_test_next_action) < 0) return;
    constexpr std::uint32_t malah_class = 513;
    if (malah_test_state == MalahTestState::walk) {
        auto* path = *reinterpret_cast<std::uint8_t**>(player + 0x2c);
        if (!path) return;
        const POINT position{*reinterpret_cast<std::uint16_t*>(path + 2),
            *reinterpret_cast<std::uint16_t*>(path + 6)};
        if (!malah_test_last_progress_at ||
            position.x != malah_test_last_position.x ||
            position.y != malah_test_last_position.y) {
            malah_test_last_position = position;
            malah_test_last_progress_at = now;
        } else if (static_cast<LONG>(now - malah_test_last_progress_at) >= 10000) {
            malah_test_stop("F10 Malah test stopped: no movement for 10 seconds");
            return;
        }
        POINT destination{};
        auto* malah = imported_shopper::find_level_unit(level, 1, malah_class);
        if (malah) destination = {malah->x, malah->y};
        else if (!resolve_target(player, level,
            navigation_data::Target{1u, malah_class, 0u, 0u}, destination)) {
            malah_test_stop("F10 Malah test stopped: NPC/preset not found");
            return;
        }
        const long dx = destination.x - position.x;
        const long dy = destination.y - position.y;
        const long distance = std::max(std::abs(dx), std::abs(dy));
        if (distance > 6) {
            const long step = std::min<long>(8, distance);
            if (!pindle_run_to_town_tile(position.x + dx * step / distance,
                position.y + dy * step / distance)) {
                malah_test_stop("F10 Malah test stopped: movement click unavailable");
                return;
            }
            if (static_cast<LONG>(now - malah_test_started_at) < 1200 ||
                (now / 3000) != ((now - 500) / 3000)) {
                char message[120]{};
                wsprintfA(message, "F10 Malah route: player=%ld,%ld target=%ld,%ld",
                    position.x, position.y, destination.x, destination.y);
                logger::write(message);
            }
            malah_test_next_action = now + 500;
            return;
        }
        if (!malah) {
            malah_test_next_action = now + 400;
            return;
        }
        imported_shopper::interact_with(reinterpret_cast<UnitAny*>(player), malah);
        malah_test_state = MalahTestState::dialogue;
        malah_test_next_action = now + 650;
        logger::write("F10 Malah test: interacting with Malah");
        return;
    }
    auto* current = get_current_npc ? static_cast<UnitAny*>(get_current_npc()) : nullptr;
    if (!current || current->id != malah_class) {
        if (malah_test_state == MalahTestState::dialogue) {
            auto* malah = imported_shopper::find_level_unit(level, 1, malah_class);
            if (malah) imported_shopper::interact_with(
                reinterpret_cast<UnitAny*>(player), malah);
            malah_test_next_action = now + 650;
            return;
        }
        malah_test_stop("F10 Malah test stopped: vendor interaction lost");
        return;
    }
    if (malah_test_state == MalahTestState::dialogue)
        malah_test_state = MalahTestState::trade;
    if (malah_test_state == MalahTestState::trade) {
        if (imported_shopper::select_npc_menu(malah_class, 0x0d44)) {
            malah_test_state = MalahTestState::buy;
            logger::write("F10 Malah test: selected Trade");
        }
        malah_test_next_action = now + 700;
        return;
    }
    if (malah_test_state == MalahTestState::confirm) {
        const auto quantity = get_unit_stat(tome, 70, 0);
        if (quantity > malah_test_quantity_before) {
            char message[100]{};
            wsprintfA(message, "F10 Malah test: ID tome increased %lu -> %lu",
                malah_test_quantity_before, quantity);
            logger::write(message);
            if (quantity >= 20) {
                if (close_npc_interact) close_npc_interact();
                malah_test_stop("F10 Malah test complete: ID tome full");
            } else {
                malah_test_state = MalahTestState::buy;
                malah_test_next_action = now + 450;
            }
        } else if (static_cast<LONG>(now - malah_test_buy_at) >= 3000)
            malah_test_stop("F10 Malah test stopped: purchase did not increase ID tome");
        return;
    }
    const auto quantity = get_unit_stat(tome, 70, 0);
    if (quantity >= 20) {
        if (close_npc_interact) close_npc_interact();
        malah_test_stop("F10 Malah test complete: ID tome already full");
        return;
    }
    auto* inventory = *reinterpret_cast<Inventory**>(
        reinterpret_cast<std::uint8_t*>(current) + 0x60);
    if (!inventory || !imported_shopper::shop_action) return;
    void* raw = inventory->first_item;
    for (int guard = 0; raw && guard < 512; ++guard) {
        auto* item = static_cast<std::uint8_t*>(raw);
        auto* data = *reinterpret_cast<ItemData**>(item + 0x14);
        if (!data) break;
        void* next = data->next_inventory_item;
        wchar_t name[128]{};
        if (get_item_name) get_item_name(item, name, std::size(name));
        if (wcsstr(name, L"Scroll of Identify")) {
            malah_test_quantity_before = quantity;
            malah_test_buy_at = now;
            imported_shopper::shop_action(item, current, current, 0, 0, 2, 1, 0);
            malah_test_state = MalahTestState::confirm;
            logger::write("F10 Malah test: purchased one ID scroll; awaiting tome change");
            return;
        }
        raw = next;
    }
    raw = inventory->first_item;
    for (int guard = 0; raw && guard < 32; ++guard) {
        auto* item = static_cast<std::uint8_t*>(raw);
        auto* data = *reinterpret_cast<ItemData**>(item + 0x14);
        if (!data) break;
        wchar_t wide[96]{};
        if (get_item_name) get_item_name(item, wide, std::size(wide));
        char name[128]{};
        WideCharToMultiByte(CP_UTF8, 0, wide, -1, name,
            static_cast<int>(std::size(name)), nullptr, nullptr);
        char message[200]{};
        wsprintfA(message, "F10 Malah vendor item: base=%lu name=%s",
            *reinterpret_cast<std::uint32_t*>(item + 0x04), name);
        logger::write(message);
        raw = data->next_inventory_item;
    }
    malah_test_stop("F10 Malah test stopped: ID scroll absent from vendor inventory");
}

void pindle_test_frame() noexcept {
    if (InterlockedCompareExchange(&pindle_new_game_pending, 0, 1) == 1) {
        auto* player = player_slot ? static_cast<std::uint8_t*>(*player_slot) : nullptr;
        Level* level = imported_shopper::player_level(player);
        if (level && level->number == 109 && get_difficulty &&
            get_difficulty() <= 2) {
            pindle_join_retry_count = 0;
            InterlockedExchange(&pindle_create_submitted_at, 0);
            pindle_state = PindleState::travel_portal;
            if (always_run && !pindle_run_mode_forced) {
                pindle_saved_run_mode = *always_run;
                *always_run = 1;
                pindle_run_mode_forced = true;
            }
            pindle_started_at = GetTickCount();
            pindle_next_action = 0;
            pindle_last_seen_at = 0;
            pindle_unit_id = 0;
            pindle_town_last_moved_at = 0;
            pindle_town_target_logged = false;
            pindle_town_route_index = static_cast<std::size_t>(-1);
            pindle_last_progress_at = 0;
            pindle_last_progress_level = 0;
            pindle_loot_probe_started_at = 0;
            pindle_loot_probe_logged = false;
            pindle_loot_target_id = 0;
            pindle_loot_pickup_sent_at = 0;
            pindle_loot_pickup_count = 0;
            pindle_town_loot_audit_pending = true;
            pindle_exit_requested = false;
            pindle_lobby_seen = false;
            logger::write("F9 new game loaded; walking toward Anya portal");
        } else if (!level) {
            const DWORD submitted_at = static_cast<DWORD>(
                InterlockedCompareExchange(&pindle_create_submitted_at, 0, 0));
            const DWORD now = GetTickCount();
            if (submitted_at && static_cast<LONG>(now - submitted_at) >= 18000) {
                if (pindle_join_retry_count >= 3) {
                    logger::write("F9 new game stopped: failed to join after 3 retries");
                } else if (InterlockedCompareExchange(
                        &pindle_menu_worker_running, 1, 0) == 0) {
                    ++pindle_join_retry_count;
                    char message[96]{};
                    wsprintfA(message, "F9 join timeout; retrying Create (%d/3)",
                        pindle_join_retry_count);
                    logger::write(message);
                    HANDLE worker = CreateThread(nullptr, 0, pindle_menu_worker,
                        nullptr, 0, nullptr);
                    if (worker) CloseHandle(worker);
                    else {
                        InterlockedExchange(&pindle_menu_worker_running, 0);
                        logger::write("F9 join retry stopped: menu worker could not start");
                    }
                }
            } else {
                InterlockedExchange(&pindle_new_game_pending, 1);
            }
        } else {
            logger::write("F9 new game stopped: wrong town or difficulty");
        }
    }
    const bool down = (GetAsyncKeyState(VK_F9) & 0x8000) != 0;
    if (down && !pindle_key_down) {
        auto* player = player_slot ? static_cast<std::uint8_t*>(*player_slot) : nullptr;
        Level* level = imported_shopper::player_level(player);
        if (pindle_state != PindleState::off) {
            pindle_stop("F9 Pindleskin test stopped by hotkey");
        } else if (!level || (level->number != 109 && level->number != 121)) {
            logger::write("F9 Pindleskin test: start beside Anya's portal");
        } else if (!get_difficulty || get_difficulty() > 2) {
            logger::write("F9 Pindleskin test: difficulty unavailable");
        } else {
            imported_shopper::shopper_active = false;
            imported_shopper::shopper_profile =
                imported_shopper::ShopperProfile::none;
            pindle_state = level->number == 109 ?
                PindleState::travel_portal : PindleState::approach;
            if (always_run && !pindle_run_mode_forced) {
                pindle_saved_run_mode = *always_run;
                *always_run = 1;
                pindle_run_mode_forced = true;
            }
            pindle_started_at = GetTickCount();
            pindle_next_action = 0;
            pindle_last_seen_at = 0;
            pindle_unit_id = 0;
            pindle_town_last_moved_at = 0;
            pindle_town_target_logged = false;
            pindle_town_route_index = static_cast<std::size_t>(-1);
            pindle_last_progress_at = 0;
            pindle_last_progress_level = 0;
            pindle_loot_probe_started_at = 0;
            pindle_loot_probe_logged = false;
            pindle_loot_target_id = 0;
            pindle_loot_pickup_sent_at = 0;
            pindle_loot_pickup_count = 0;
            pindle_town_loot_audit_pending = level->number == 109;
            logger::write("F9 Pindleskin test started; Mouse 2 trap skill required");
        }
    }
    pindle_key_down = down;
    if (pindle_state == PindleState::off) return;
    const DWORD now = GetTickCount();
    if (static_cast<LONG>(now - pindle_started_at) >= 240000) {
        pindle_leave_game("F9 four-minute run timeout; remaking game");
        return;
    }
    if (draw_text && set_text_size) {
        wchar_t status[40] = L"F9 PINDLE TEST: PORTAL";
        if (pindle_state == PindleState::travel_portal)
            lstrcpyW(status, L"F9 PINDLE TEST: TO PORTAL");
        else if (pindle_state == PindleState::approach)
            lstrcpyW(status, L"F9 PINDLE TEST: APPROACH");
        else if (pindle_state == PindleState::fight)
            lstrcpyW(status, L"F9 PINDLE TEST: TRAPS");
        else if (pindle_state == PindleState::loot_probe)
            lstrcpyW(status, L"F9 PICKUP: VISIBLE DROPS");
        if (pindle_town_identify_index < pindle_town_identify_count)
            lstrcpyW(status, L"F9 IDENTIFYING BACKPACK LOOT");
        const auto old = set_text_size(1);
        draw_text(status, 20, 180, 0x0d, 0);
        set_text_size(old);
    }
    auto* player = player_slot ? static_cast<std::uint8_t*>(*player_slot) : nullptr;
    Level* level = imported_shopper::player_level(player);
    if (!player || !level) return;
    // Give the mercenary and town units time to load before any portal movement.
    if (level->number == 109 &&
        static_cast<LONG>(now - pindle_started_at) < 5000) return;
    if (level->number == 109 && pindle_town_loot_audit_pending)
        pindle_audit_inventory(player);
    if (level->number == 109 &&
        !pindle_identify_town_items(player, now)) return;
    if (level->number == 109 &&
        !pindle_process_town_sales(player, level, now)) return;
    auto* progress_path = *reinterpret_cast<std::uint8_t**>(player + 0x2c);
    if (progress_path) {
        const POINT position{
            *reinterpret_cast<std::uint16_t*>(progress_path + 2),
            *reinterpret_cast<std::uint16_t*>(progress_path + 6)};
        if (!pindle_last_progress_at ||
            pindle_last_progress_level != level->number ||
            pindle_last_progress_position.x != position.x ||
            pindle_last_progress_position.y != position.y) {
            pindle_last_progress_at = now;
            pindle_last_progress_level = level->number;
            pindle_last_progress_position = position;
        } else if (static_cast<LONG>(now - pindle_last_progress_at) >= 30000) {
            char message[112]{};
            wsprintfA(message, "F9 no movement for 30 seconds at level %u (%ld,%ld); remaking game",
                level->number, position.x, position.y);
            pindle_leave_game(message);
            return;
        }
    }
    if (static_cast<LONG>(now - pindle_next_action) < 0) return;
    if (level->number == 109 && pindle_state == PindleState::travel_portal) {
        UnitAny* portal = imported_shopper::find_level_unit(level, 2, 60);
        auto* path = *reinterpret_cast<std::uint8_t**>(player + 0x2c);
        if (!path) return;
        const long px = *reinterpret_cast<std::uint16_t*>(path + 2);
        const long py = *reinterpret_cast<std::uint16_t*>(path + 6);
        if (pindle_town_route_index == static_cast<std::size_t>(-1)) {
            long closest = LONG_MAX;
            for (std::size_t i = 0; i < pindle_town_route.size(); ++i) {
                const long distance = std::abs(pindle_town_route[i].x - px) +
                    std::abs(pindle_town_route[i].y - py);
                if (distance < closest) {
                    closest = distance;
                    pindle_town_route_index = i;
                }
            }
        }
        while (pindle_town_route_index < pindle_town_route.size() &&
            std::max(std::abs(pindle_town_route[pindle_town_route_index].x - px),
                std::abs(pindle_town_route[pindle_town_route_index].y - py)) <= 3)
            ++pindle_town_route_index;
        POINT destination = pindle_town_route[std::min(pindle_town_route_index,
            pindle_town_route.size() - 1)];
        if (pindle_town_route_index >= pindle_town_route.size() && portal &&
            get_unit_x && get_unit_y) {
            const int portal_x = get_unit_x(portal);
            const int portal_y = get_unit_y(portal);
            if (portal_x >= 5000 && portal_x <= 5200 &&
                portal_y >= 5000 && portal_y <= 5200)
                destination = {portal_x, portal_y};
        }
        if (!pindle_town_last_moved_at ||
            pindle_town_last_position.x != px ||
            pindle_town_last_position.y != py) {
            pindle_town_last_position = {px, py};
            pindle_town_last_moved_at = now;
        }
        if (!pindle_town_target_logged) {
            char message[128]{};
            wsprintfA(message, "F9 town route: (%ld,%ld) -> waypoint %u (%ld,%ld)",
                px, py, static_cast<unsigned>(pindle_town_route_index),
                destination.x, destination.y);
            logger::write(message);
            pindle_town_target_logged = true;
        }
        const long dx = destination.x - px, dy = destination.y - py;
        const long distance = std::max(std::abs(dx), std::abs(dy));
        if (portal && pindle_town_route_index >= pindle_town_route.size() &&
            distance <= 8) {
            pindle_state = PindleState::enter_portal;
            logger::write("F9 reached Anya portal; entering");
        } else if (distance > 0) {
            const long step = std::min<long>(8, distance);
            pindle_run_to_town_tile(px + dx * step / distance,
                py + dy * step / distance);
        }
        pindle_next_action = now + 500;
        return;
    }
    if (level->number == 109 && pindle_state == PindleState::enter_portal) {
        UnitAny* portal = imported_shopper::find_level_unit(level, 2, 60);
        if (portal) imported_shopper::interact_with(
            reinterpret_cast<UnitAny*>(player), portal);
        pindle_next_action = now + 350;
        return;
    }
    if (level->number != 121) {
        pindle_stop("F9 Pindleskin test stopped: unexpected area");
        return;
    }
    if (pindle_state == PindleState::loot_probe) {
        constexpr std::uint32_t invisible_flag = 0x00040000;
        UnitAny* target = nullptr;
        int best_distance = INT_MAX;
        auto* player_path = *reinterpret_cast<std::uint8_t**>(player + 0x2c);
        if (!player_path) return;
        const int player_x = *reinterpret_cast<std::uint16_t*>(player_path + 2);
        const int player_y = *reinterpret_cast<std::uint16_t*>(player_path + 6);
        if (!pindle_loot_probe_logged &&
            static_cast<LONG>(now - pindle_loot_probe_started_at) >= 700) {
            pindle_loot_probe_logged = true;
            int found = 0;
            for (Room2* room = level->first_room; room && found < 64;
                 room = room->next) {
                if (!room->room1) continue;
                int guard = 0;
                for (UnitAny* unit = room->room1->first_unit;
                     unit && guard++ < 1024 && found < 64;
                     unit = unit->room_next) {
                    if (unit->type != 4 || unit->mode != 3) continue;
                    wchar_t wide_name[128]{};
                    char name[192]{};
                    const int name_result = get_item_name ?
                        get_item_name(unit, wide_name, std::size(wide_name)) : -1;
                    if (wide_name[0]) {
                        WideCharToMultiByte(CP_ACP, 0, wide_name, -1,
                            name, std::size(name), nullptr, nullptr);
                    }
                    const int item_x = get_unit_x ? get_unit_x(unit) : -1;
                    const int item_y = get_unit_y ? get_unit_y(unit) : -1;
                    // BH marks filter-hidden ground units with
                    // UNITFLAGEX_INVISIBLE in UnitAny::dwFlags2 (+0xC8).
                    const auto flags2 = *reinterpret_cast<const std::uint32_t*>(
                        reinterpret_cast<const std::uint8_t*>(unit) + 0xC8);
                    char message[300]{};
                    wsprintfA(message,
                        "F9 LOOT PROBE item id=%u class=%u mode=%u pos=(%d,%d) flags2=%08X hidden=%u name_result=%d first_char=%u name=%s",
                        unit->unit_id, unit->id, unit->mode, item_x,
                        item_y, flags2, (flags2 & invisible_flag) != 0, name_result,
                        static_cast<unsigned>(wide_name[0]), name);
                    logger::write(message);
                    ++found;
                }
            }
            char message[80]{};
            wsprintfA(message, "F9 LOOT PROBE ground units=%d; picking visible drops", found);
            logger::write(message);
        }
        if (static_cast<LONG>(now - pindle_loot_probe_started_at) < 700)
            return;
        if (static_cast<LONG>(now - pindle_next_action) < 0) return;
        for (Room2* room = level->first_room; room; room = room->next) {
            if (!room->room1) continue;
            int guard = 0;
            for (UnitAny* unit = room->room1->first_unit;
                 unit && guard++ < 1024; unit = unit->room_next) {
                if (unit->type != 4 || unit->mode != 3) continue;
                if (pindle_loot_target_id &&
                    unit->unit_id == pindle_loot_target_id) target = unit;
                if (pindle_loot_pickup_sent_at ||
                    !get_unit_x || !get_unit_y) continue;
                const auto flags2 = *reinterpret_cast<const std::uint32_t*>(
                    reinterpret_cast<const std::uint8_t*>(unit) + 0xC8);
                if (flags2 & invisible_flag) continue;
                const int x = get_unit_x(unit), y = get_unit_y(unit);
                if (x < 9900 || x > 10200 || y < 13000 || y > 13400)
                    continue;
                const int distance = std::max(std::abs(x - player_x),
                    std::abs(y - player_y));
                if (distance < best_distance) {
                    best_distance = distance;
                    target = unit;
                }
            }
        }
        if (pindle_loot_pickup_sent_at) {
            if (!target || target->mode != 3) {
                pindle_collected_item_ids.insert(pindle_loot_target_id);
                ++pindle_loot_pickup_count;
                char message[96]{};
                wsprintfA(message, "F9 pickup confirmed: item left ground; count=%d",
                    pindle_loot_pickup_count);
                logger::write(message);
                pindle_loot_target_id = 0;
                pindle_loot_pickup_sent_at = 0;
                pindle_next_action = now + 300;
                if (pindle_loot_pickup_count >= 12)
                    pindle_leave_game("F9 pickup limit reached; remaking game");
            } else if (static_cast<LONG>(now - pindle_loot_pickup_sent_at) >= 1800) {
                pindle_leave_game("F9 pickup not confirmed; remaking game");
            }
            return;
        }
        if (static_cast<LONG>(now - pindle_loot_probe_started_at) >= 25000) {
            pindle_leave_game("F9 pickup timeout; remaking game");
            return;
        }
        if (!target) {
            if (static_cast<LONG>(now - pindle_loot_probe_started_at) >= 2500)
                pindle_leave_game("F9 no filter-visible ground item; remaking game");
            return;
        }
        const int item_x = get_unit_x(target), item_y = get_unit_y(target);
        const int distance = std::max(std::abs(item_x - player_x),
            std::abs(item_y - player_y));
        if (distance > 3) {
            const int step = std::min(7, distance - 2);
            imported_shopper::click_world(player_x +
                (item_x - player_x) * step / distance, player_y +
                (item_y - player_y) * step / distance);
            pindle_next_action = now + 450;
            return;
        }
        if (!send_packet) {
            pindle_leave_game("F9 pickup unavailable: SendPacket missing");
            return;
        }
        BYTE packet[13]{};
        packet[0] = 0x16; // D2GS_PICKUPITEM: type, unit ID, inventory action.
        *reinterpret_cast<DWORD*>(packet + 1) = 4;
        *reinterpret_cast<DWORD*>(packet + 5) = target->unit_id;
        *reinterpret_cast<DWORD*>(packet + 9) = 0;
        pindle_loot_target_id = target->unit_id;
        pindle_loot_pickup_sent_at = now;
        send_packet(sizeof(packet), 1, packet);
        char message[96]{};
        wsprintfA(message, "F9 pickup sent for visible item id=%u class=%u",
            target->unit_id, target->id);
        logger::write(message);
        pindle_next_action = now + 350;
        return;
    }
    if (pindle_state == PindleState::enter_portal) {
        pindle_state = PindleState::approach;
        logger::write("F9 Pindleskin test entered red portal");
    }
    // Pindleskin is the super-unique Defiled Warrior (MonStats class 440).
    UnitAny* pindle = nullptr;
    for (Room2* room = level->first_room; room && !pindle; room = room->next) {
        if (!room->room1) continue;
        int guard = 0;
        for (UnitAny* unit = room->room1->first_unit;
             unit && guard++ < 1024; unit = unit->room_next) {
            if (unit->type == 1 && unit->id == 440 && unit->object_data &&
                (reinterpret_cast<MonsterData*>(unit->object_data)->flags & 0x08)) {
                pindle = unit;
                break;
            }
        }
    }
    if (pindle) {
        pindle_unit_id = pindle->unit_id;
        pindle_last_seen_at = now;
        if (pindle->mode == 0 || pindle->mode == 12) {
            pindle_state = PindleState::loot_probe;
            pindle_loot_probe_started_at = now;
            pindle_loot_probe_logged = false;
            logger::write("F9 Pindleskin confirmed dead; collecting filter-visible drops");
            return;
        }
        if (get_unit_stat && get_unit_stat(pindle, 36, 0) >= 100 &&
            get_unit_stat(pindle, 41, 0) >= 100) {
            pindle_leave_game(
                "F9 Pindleskin physical + lightning immune; leaving to lobby");
            return;
        }
    } else if (pindle_state == PindleState::fight && pindle_unit_id &&
        static_cast<LONG>(now - pindle_last_seen_at) >= 1500) {
        pindle_stop("F9 Pindleskin target lost; stopped without assuming a kill");
        return;
    }
    auto* path = *reinterpret_cast<std::uint8_t**>(player + 0x2c);
    if (!path) return;
    const long px = *reinterpret_cast<std::uint16_t*>(path + 2);
    const long py = *reinterpret_cast<std::uint16_t*>(path + 6);
    if (pindle_state == PindleState::approach) {
        POINT destination{};
        if (pindle) destination = {pindle->x, pindle->y};
        else if (!resolve_target(player, level,
            navigation_data::Target{6u, 122u, 0u, 0u}, destination)) {
            pindle_next_action = now + 250;
            return;
        }
        const long dx = destination.x - px, dy = destination.y - py;
        const long distance = std::max(std::abs(dx), std::abs(dy));
        // Stop short of Pindleskin and the Halls stairway. Only short clicks
        // are sent so the game's own pathfinder handles the corridor.
        if (pindle && distance <= 22) {
            pindle_state = PindleState::fight;
            logger::write("F9 Pindleskin in trap range; casting Mouse 2");
        } else if (distance > 22) {
            const long step = std::min<long>(8, distance - 20);
            imported_shopper::click_world(px + dx * step / distance,
                py + dy * step / distance);
        }
        pindle_next_action = now + 450;
        return;
    }
    if (pindle_state == PindleState::fight && pindle) {
        pindle_cast_at(pindle);
        pindle_next_action = now + 700;
    }
}


std::uint64_t room_key(const Room2* room) noexcept {
    return (static_cast<std::uint64_t>(room->x) << 32) |
        static_cast<std::uint64_t>(room->y);
}

struct SkillTreeGroup {
    int tab;
    const int* skills;
    std::size_t count;
};
#define SKILLS(name, ...) static constexpr int name[]{__VA_ARGS__}
SKILLS(asn1,254,255,260,259,265,269,270,275,274,280);
SKILLS(asn2,252,253,258,263,264,273,267,268,279,278);
SKILLS(asn3,251,256,257,261,262,266,277,366,272,271,276);
SKILLS(bar1,130,131,138,154,142,137,149,150,155,146);
SKILLS(bar2,128,135,134,141,145,148,153,368);
SKILLS(bar3,126,133,147,139,144,140,132,143,152,151,375);
SKILLS(dru1,225,230,229,235,234,240,370,244,245,250,249);
SKILLS(dru2,223,228,224,232,233,242,238,243,239,248);
SKILLS(dru3,221,222,236,227,231,246,237,241,226,247);
SKILLS(nec1,70,69,75,80,79,85,367,90,89,94,95);
SKILLS(nec2,67,73,68,74,78,83,84,88,92,93);
SKILLS(nec3,66,374,71,381,76,82,77,72,81,86,87,91);
SKILLS(pal1,99,100,105,110,104,109,115,120,124,125);
SKILLS(pal2,98,102,103,108,113,114,118,119,122,123);
SKILLS(pal3,96,101,97,106,371,107,111,112,116,378,121,117,364);
SKILLS(sor1,39,40,44,45,50,55,60,369,59,64,65);
SKILLS(sor2,38,43,42,48,49,54,53,57,58,63);
SKILLS(sor3,36,37,41,46,51,47,383,52,56,376,62,61);
#undef SKILLS
#define GROUP(tab, name) {tab, name, std::size(name)}
static constexpr SkillTreeGroup skill_groups[]{
    GROUP(50,asn1),GROUP(49,asn2),GROUP(48,asn3),
    GROUP(34,bar1),GROUP(33,bar2),GROUP(32,bar3),
    GROUP(42,dru1),GROUP(41,dru2),GROUP(40,dru3),
    GROUP(18,nec1),GROUP(17,nec2),GROUP(16,nec3),
    GROUP(26,pal1),GROUP(25,pal2),GROUP(24,pal3),
    GROUP(10,sor1),GROUP(9,sor2),GROUP(8,sor3)
};
#undef GROUP

bool has_plus_three(void* item, const int* skills, std::size_t count) noexcept {
    for (std::size_t i = 0; i < count; ++i)
        if (get_unit_stat(item, 107, skills[i]) >= 3) return true;
    return false;
}

int sorceress_staff_skill_bonus(void* item) noexcept {
    constexpr int item_type_staff = 26;
    constexpr int sorceress_class = 1;
    if (!item || !get_unit_stat || !is_matching_type ||
        !is_matching_type(item, item_type_staff)) return 0;
    const int all_sorceress = static_cast<int>(
        get_unit_stat(item, 83, sorceress_class));
    int best = 0;
    const SkillTreeGroup sorceress_groups[]{
        {10, sor1, std::size(sor1)},
        {9, sor2, std::size(sor2)},
        {8, sor3, std::size(sor3)},
    };
    for (const auto& group : sorceress_groups) {
        const int tree = static_cast<int>(get_unit_stat(item, 188, group.tab));
        for (std::size_t index = 0; index < group.count; ++index) {
            const int staffmod = static_cast<int>(
                get_unit_stat(item, 107, group.skills[index]));
            best = std::max(best, all_sorceress + tree + staffmod);
        }
    }
    return best;
}

bool is_target_sorceress_staff(void* item) noexcept {
    constexpr std::uint32_t stat_faster_cast_rate = 105;
    if (!item || !get_unit_stat) return false;
    return sorceress_staff_skill_bonus(item) >=
            auto_buyer_min_sorceress_bonus &&
        get_unit_stat(item, stat_faster_cast_rate, 0) >=
            auto_buyer_min_faster_cast_rate;
}

int shop_winner_kind(void* item) noexcept {
    if (!item || !get_unit_stat) return 0;
    const int sorceress_bonus = sorceress_staff_skill_bonus(item);
    if (is_target_sorceress_staff(item))
        return 600 + sorceress_bonus;
    for (const auto& group : skill_groups) {
        if (group.tab != 34 && group.tab != 49 && group.tab != 50 &&
            get_unit_stat(item, 188, group.tab) >= 3 &&
            has_plus_three(item, group.skills, group.count)) return 6;
    }
    // Amazon tab bonuses can be granted directly at +6 on class-specific gear.
    for (int tab = 0; tab <= 2; ++tab)
        if (get_unit_stat(item, 188, tab) >= 6) return 6;
    if (get_unit_stat(item, 83, 2) >= 2 &&
        (has_plus_three(item, nec1, std::size(nec1)) ||
         has_plus_three(item, nec2, std::size(nec2)) ||
         has_plus_three(item, nec3, std::size(nec3)))) return 5;

    if (is_matching_type) {
        constexpr int item_type_gloves = 16;
        constexpr int item_type_primal_helm = 71;
        constexpr int item_type_claw = 67;
        constexpr int item_type_claw2 = 88;
        constexpr int stat_ias = 93;
        if (is_matching_type(item, item_type_gloves) &&
            get_unit_stat(item, 188, 0) >= 3 &&
            get_unit_stat(item, stat_ias, 0) >= 20) return 320;
        if (is_matching_type(item, item_type_primal_helm) &&
            get_unit_stat(item, 188, 34) >= 3 &&
            (get_unit_stat(item, 107, 149) >= 3 ||
             get_unit_stat(item, 107, 155) >= 3)) return 6;
        // Only this exact Shadow Discipline weapon combination qualifies.
        if ((is_matching_type(item, item_type_claw) ||
             is_matching_type(item, item_type_claw2)) &&
            get_unit_stat(item, stat_ias, 0) >= 40 &&
            get_unit_stat(item, 188, 49) >= 3 &&
            get_unit_stat(item, 107, 252) >= 3 &&
            (get_unit_stat(item, 107, 278) > 0 ||
             get_unit_stat(item, 107, 268) > 0)) return 340;
        // Trap claws remain valid; Martial Arts claws are ignored.
        if ((is_matching_type(item, item_type_claw) ||
             is_matching_type(item, item_type_claw2)) &&
            get_unit_stat(item, stat_ias, 0) >= 40 &&
            get_unit_stat(item, 188, 48) >= 3) return 340;
    }
    return 0;
}


bool buy_shop_item(void* item, void* npc) noexcept {
    if (!item || !npc || !player_slot || !*player_slot || !get_difficulty ||
        !get_quest_info || !get_item_price || !send_packet) return false;
    const std::uint32_t cost = get_item_price(*player_slot, item,
        get_difficulty(), reinterpret_cast<std::uint32_t>(get_quest_info()),
        0x201, 0);
    if (!cost) return false;
#pragma pack(push, 1)
    struct NpcBuyPacket {
        std::uint8_t opcode;
        std::uint32_t npc_id, item_id, buffer_type, cost;
    };
#pragma pack(pop)
    NpcBuyPacket packet{0x32,
        *reinterpret_cast<std::uint32_t*>(static_cast<std::uint8_t*>(npc) + 0x0c),
        *reinterpret_cast<std::uint32_t*>(static_cast<std::uint8_t*>(item) + 0x0c),
        0, cost};
    send_packet(sizeof(packet), 1, &packet);
    return true;
}

void begin_shop_refresh(void* npc, DWORD delay) noexcept {
    if (!npc || shop_refresh_state != ShopRefreshState::idle) return;
    shop_refresh_npc_id = *reinterpret_cast<std::uint32_t*>(
        static_cast<std::uint8_t*>(npc) + 0x0c);
    shop_refresh_state = ShopRefreshState::close_shop;
    shop_refresh_next_action = GetTickCount() + delay;
    shop_refresh_deadline = GetTickCount() + 45000;
    shop_refresh_route_step = 0;
    auto_buyer_enabled = false;
    logger::write("Shop refresh queued: east-gate directional route");
}

void draw_shop_winners() noexcept {
    if (!get_current_npc || !draw_rectangle || !draw_text || !set_text_size ||
        !store_layout) return;
    const bool key_down = (GetAsyncKeyState(VK_F8) & 0x8000) != 0;
    if (key_down && !auto_buyer_key_down) {
        if (shop_refresh_state != ShopRefreshState::idle) {
            shop_refresh_state = ShopRefreshState::idle;
            auto_buyer_enabled = false;
            logger::write("F8 shop refresh cancelled");
        } else {
            auto_buyer_enabled = !auto_buyer_enabled;
        }
        auto_buyer_last_item = 0;
        logger::write(auto_buyer_enabled
            ? "F8 Sorceress staff auto-buyer enabled"
            : "F8 Sorceress staff auto-buyer disabled");
    }
    auto_buyer_key_down = key_down;
    wchar_t buyer_status[64]{};
    wsprintfW(buyer_status, L"F8 AUTO BUY +%d / %d FCR: %s",
        auto_buyer_min_sorceress_bonus, auto_buyer_min_faster_cast_rate,
        auto_buyer_enabled ? L"ON" : L"OFF");
    const auto status_old_size = set_text_size(1);
    draw_text(buyer_status, 20, 112, auto_buyer_enabled ? 2 : 1, 0);
    wchar_t route_status[80]{};
    if (shop_route_recording)
        wsprintfW(route_status, L"F9 ROUTE: RECORDING - WALK OUTSIDE");
    else if (learned_shop_route.size() >= 3)
        wsprintfW(route_status, L"F9 ROUTE: READY (%u POINTS)",
            static_cast<unsigned>(learned_shop_route.size()));
    else
        wsprintfW(route_status, L"F9 ROUTE: PRESS BESIDE DROGNAN");
    draw_text(route_status, 20, 135,
        learned_shop_route.size() >= 3 ? 2 : 1, 0);
    if (static_cast<LONG>(auto_buyer_bought_until - GetTickCount()) > 0) {
        wchar_t bought_message[64]{};
        wsprintfW(bought_message, L"BOUGHT: +%d / %d FCR",
            auto_buyer_bought_skill, auto_buyer_bought_fcr);
        draw_text(bought_message, 20, 180, 2, 0);
    }
    set_text_size(status_old_size);
    auto* npc = static_cast<std::uint8_t*>(get_current_npc());
    if (!npc) {
        if (auto_buyer_enabled &&
            shop_refresh_state == ShopRefreshState::idle) {
            shop_refresh_state = ShopRefreshState::open_npc_session;
            shop_refresh_next_action = GetTickCount();
            shop_refresh_deadline = GetTickCount() + 10000;
            logger::write("F8: requesting Drognan interaction");
        }
        return;
    }
    constexpr std::uint32_t drognan_class_id = 177;
    const bool correct_vendor =
        *reinterpret_cast<std::uint32_t*>(npc + 4) == drognan_class_id;
    auto* inventory = *reinterpret_cast<Inventory**>(npc + 0x60);
    if (!inventory || !inventory->first_item) return;
    int winners = 0;
    int sorceress_targets = 0;
    wchar_t winner_name[96]{};
    const bool bright_phase = ((GetTickCount() / 350) & 1) == 0;
    void* raw = inventory->first_item;
    for (int guard = 0; raw && guard < 512; ++guard) {
        auto* item = static_cast<std::uint8_t*>(raw);
        auto* data = *reinterpret_cast<ItemData**>(item + 0x14);
        if (!data) break;
        const int sorceress_bonus = sorceress_staff_skill_bonus(item);
        const int faster_cast_rate = static_cast<int>(
            get_unit_stat(item, 105, 0));
        if (is_target_sorceress_staff(item))
            ++sorceress_targets;
        const int kind = shop_winner_kind(item);
        if (kind) {
            ++winners;
            if (winners == 1 && get_item_name) {
                wchar_t raw_name[128]{};
                if (get_item_name(item, raw_name, std::size(raw_name))) {
                    std::size_t out = 0;
                    for (std::size_t in = 0; raw_name[in] && out + 1 < std::size(winner_name); ++in) {
                        if (raw_name[in] == L'\n' || raw_name[in] == L'\r') break;
                        // Diablo color controls are 0xFF, 'c', then one color byte.
                        if (raw_name[in] == 0xff && raw_name[in + 1] == L'c' && raw_name[in + 2]) {
                            in += 2;
                            continue;
                        }
                        winner_name[out++] = raw_name[in];
                    }
                    winner_name[out] = 0;
                }
            }
            const int col = *reinterpret_cast<std::uint16_t*>(item + 0x8c);
            const int row = *reinterpret_cast<std::uint16_t*>(item + 0x8e);
            const int x1 = static_cast<int>(store_layout->left) +
                col * store_layout->pixel_width;
            const int y1 = static_cast<int>(store_layout->top) +
                row * store_layout->pixel_height;
            const int x2 = x1 + std::max<int>(store_layout->pixel_width, 28);
            const int y2 = y1 + std::max<int>(store_layout->pixel_height, 28);
            // Draw only the four edges so the item remains fully visible.
            // Alternate yellow/white to make the location unmistakably flash.
            const std::uint32_t color = bright_phase ? 0x0d : 0x00;
            constexpr int thickness = 3;
            draw_rectangle(x1, y1, x2, y1 + thickness, color, 1);
            draw_rectangle(x1, y2 - thickness, x2, y2, color, 1);
            draw_rectangle(x1, y1, x1 + thickness, y2, color, 1);
            draw_rectangle(x2 - thickness, y1, x2, y2, color, 1);
            const std::uint32_t item_id =
                *reinterpret_cast<std::uint32_t*>(item + 0x0c);
            const DWORD now = GetTickCount();
            if (auto_buyer_enabled && correct_vendor &&
                is_target_sorceress_staff(item) &&
                item_id != auto_buyer_last_item &&
                static_cast<LONG>(now - auto_buyer_next_action) >= 0) {
                auto_buyer_last_item = item_id;
                auto_buyer_next_action = now + 750;
                char message[112]{};
                wsprintfA(message,
                    "Auto-buying Drognan staff id=%u: +%d skill, %d FCR",
                    item_id, sorceress_bonus, faster_cast_rate);
                if (buy_shop_item(item, npc)) {
                    logger::write(message);
                    auto_buyer_bought_skill = sorceress_bonus;
                    auto_buyer_bought_fcr = faster_cast_rate;
                    auto_buyer_bought_until = now + 6000;
                    begin_shop_refresh(npc, 1000);
                } else {
                    logger::write("Auto-buy packet rejected: price or binding unavailable");
                    auto_buyer_enabled = false;
                }
                break;
            }
        }
        raw = data->next_inventory_item;
    }
    if (auto_buyer_enabled && correct_vendor && sorceress_targets == 0)
        begin_shop_refresh(npc, 250);
    if (winners) {
        wchar_t message[180]{};
        if (winner_name[0] && winners == 1)
            wsprintfW(message, L"SHOP WINNER: %s", winner_name);
        else if (winner_name[0])
            wsprintfW(message, L"SHOP WINNERS (%d), FIRST: %s", winners, winner_name);
        else
            wsprintfW(message, L"SHOP WINNER FOUND (%d)", winners);
        const auto old = set_text_size(1);
        draw_text(message, 20, 135, 0x0d, 0);
        set_text_size(old);
    }
    if (correct_vendor) {
        wchar_t target_message[80]{};
        wsprintfW(target_message, L"SORC TARGETS +%d / %d FCR: %d",
            auto_buyer_min_sorceress_bonus,
            auto_buyer_min_faster_cast_rate, sorceress_targets);
        const auto old = set_text_size(1);
        draw_text(target_message, 20, 158,
            sorceress_targets ? 2 : 1, 0);
        set_text_size(old);
    }
}

bool is_cow(std::uint32_t class_id) noexcept {
    static constexpr std::array<std::uint32_t, 4> ids{391, 826, 827, 828};
    return std::find(ids.begin(), ids.end(), class_id) != ids.end();
}

std::uint8_t monster_immunities(void* unit) noexcept {
    if (!get_unit_stat || !unit) return 0;
    // ItemStatCost IDs used by the verified 1.13/ProjectD2 stat function.
    constexpr std::uint32_t damage_resist = 36;
    constexpr std::uint32_t fire_resist = 39;
    constexpr std::uint32_t lightning_resist = 41;
    constexpr std::uint32_t cold_resist = 43;
    constexpr std::uint32_t poison_resist = 45;
    std::uint8_t result = 0;
    if (get_unit_stat(unit, damage_resist, 0) >= 100) result |= element_physical;
    if (get_unit_stat(unit, cold_resist, 0) >= 100) result |= element_cold;
    if (get_unit_stat(unit, fire_resist, 0) >= 100) result |= element_fire;
    if (get_unit_stat(unit, lightning_resist, 0) >= 100) result |= element_lightning;
    if (get_unit_stat(unit, poison_resist, 0) >= 100) result |= element_poison;
    return result;
}

bool has_monster_modifier(const MonsterData* monster,
    std::uint8_t wanted) noexcept {
    if (!monster) return false;
    for (const std::uint8_t modifier : monster->modifiers) {
        if (modifier == wanted) return true;
    }
    return false;
}

std::uint8_t monster_enchantments(void* unit,
    const MonsterData* monster) noexcept {
    // Vanilla/PD2 MonUMod IDs. Poison enchanted is not a normal random LoD
    // modifier, so live poison attack damage is also accepted for specials.
    constexpr std::uint8_t fire_enchanted = 9;
    constexpr std::uint8_t lightning_enchanted = 10;
    constexpr std::uint8_t cold_enchanted = 11;
    constexpr std::uint32_t poison_min_damage = 57;
    std::uint8_t result = 0;
    if (has_monster_modifier(monster, cold_enchanted)) result |= element_cold;
    if (has_monster_modifier(monster, fire_enchanted)) result |= element_fire;
    if (has_monster_modifier(monster, lightning_enchanted)) result |= element_lightning;
    if (get_unit_stat && get_unit_stat(unit, poison_min_damage, 0) != 0)
        result |= element_poison;
    return result;
}

bool is_special_chest(std::uint32_t id) noexcept {
    return id == 371 || id == 397 || id == 455 || id == 580;
}

bool is_normal_container(std::uint32_t id) noexcept {
    // ProjectD2 official normal chests, stashes, coffins/sarcophagi, plus
    // Loose Boulder (175). Barrels are intentionally excluded.
    static constexpr auto ids = std::array{
        5u,6u,87u,88u,89u,125u,127u,128u,139u,140u,141u,144u,146u,
        147u,148u,155u,159u,175u,176u,177u,181u,182u,183u,185u,186u,
        187u,188u,198u,203u,204u,205u,240u,241u,242u,243u,274u,284u,
        329u,330u,331u,332u,333u,334u,335u,336u,354u,355u,356u,372u,
        387u,389u,390u,391u,405u,406u,407u,413u,416u,420u,424u,425u,
        430u,431u,432u,433u,463u,501u,502u,504u,505u,588u};
    return std::find(ids.begin(), ids.end(), id) != ids.end();
}

bool point_is_opened(const POINT& point) noexcept {
    return std::any_of(opened_containers.begin(), opened_containers.end(),
        [&](const POINT& opened) {
            return std::abs(opened.x - point.x) <= 2 &&
                std::abs(opened.y - point.y) <= 2;
        });
}

bool is_act_boss(std::uint32_t class_id) noexcept {
    static constexpr std::array<std::uint32_t, 5> ids{
        156, 211, 242, 243, 544};
    return std::find(ids.begin(), ids.end(), class_id) != ids.end();
}

bool is_known_uber(std::uint32_t class_id) noexcept {
    // ProjectD2 official MonStats IDs: Diablo Clone, Pandemonium Ubers,
    // new Uber Diablo/souls, and Uber Ancients.
    static constexpr std::array<std::uint32_t, 17> ids{
        333, 704, 705, 706, 707, 708, 709, 789, 790,
        791, 792, 793, 794, 989, 990, 991, 755};
    return std::find(ids.begin(), ids.end(), class_id) != ids.end();
}

bool show_boss_life(std::uint32_t class_id, std::uint32_t level_number,
    MonsterMarkerKind kind) noexcept {
    if (kind == MonsterMarkerKind::act_boss || kind == MonsterMarkerKind::uber)
        return true;
    // PD2 key holders. Level checks keep ordinary monsters that share a base
    // class (notably Countess and Bloodwitch) from receiving an HP label.
    return (level_number == 25 && (class_id == 740 || class_id == 45)) ||
        (level_number == 17 && class_id == 267) ||  // Blood Raven
        (level_number == 60 && class_id == 83) ||   // Bloodwitch the Wild
        (level_number == 74 && class_id == 250) ||  // The Summoner
        (level_number == 124 && class_id == 526) || // Nihlathak
        (level_number == 105 && class_id == 256);   // Izual
}

bool is_waypoint_object(std::uint32_t id) noexcept {
    static constexpr std::array<std::uint32_t, 17> ids{
        119,157,156,323,288,402,324,237,238,398,496,511,494,392,394,396,255};
    return std::find(ids.begin(), ids.end(), id) != ids.end();
}

bool is_shrine_or_well(std::uint32_t id) noexcept {
    // Extracted from ProjectD2's active official Objects.txt. These entries are
    // named as shrines or wells, including the act-specific visual variants.
    static constexpr std::array<std::uint32_t, 102> ids{
        2,77,81,83,84,85,93,96,97,109,111,113,115,116,118,123,124,130,
        132,133,134,135,136,137,138,150,151,164,165,166,167,168,170,172,
        173,184,190,191,197,199,200,201,202,206,226,231,232,236,249,260,
        262,263,264,265,275,276,277,278,279,280,281,282,299,300,302,303,
        320,322,325,343,344,361,414,415,421,422,423,426,427,428,464,465,
        472,479,483,484,488,491,492,493,495,497,498,499,503,509,512,513,
        519,520,521,522};
    return std::binary_search(ids.begin(), ids.end(), id);
}

bool room_has_shrine(Room2* room) noexcept {
    if (!room) return false;
    for (auto* preset = static_cast<PresetUnit*>(room->presets);
         preset; preset = preset->next) {
        if (preset->type == 2 && is_shrine_or_well(preset->id)) return true;
    }
    return false;
}

void capture_shrine_effects(Room1* room) noexcept;

void finish_pending_shrine_rooms(DWORD now) noexcept {
    for (auto it = pending_shrine_rooms.begin();
         it != pending_shrine_rooms.end();) {
        if (static_cast<LONG>(now - it->ready_at) < 0) {
            ++it;
            continue;
        }
        if (it->room && it->room->room1)
            capture_shrine_effects(it->room->room1);
        if (remove_room && it->act)
            remove_room(it->act, static_cast<int>(it->level),
                static_cast<int>(it->x), static_cast<int>(it->y), nullptr);
        it = pending_shrine_rooms.erase(it);
    }
}

void capture_shrines(Room2* room) {
    if (!room) return;
    for (auto* preset = static_cast<PresetUnit*>(room->presets);
         preset; preset = preset->next) {
        if (preset->type != 2 || !is_shrine_or_well(preset->id)) continue;
        POINT point{static_cast<LONG>(room->x * 5 + preset->x),
            static_cast<LONG>(room->y * 5 + preset->y)};
        const bool exists = std::any_of(shrine_markers.begin(), shrine_markers.end(),
            [&](const ShrineMarker& old) {
                return old.point.x == point.x && old.point.y == point.y;
            });
        if (!exists) shrine_markers.push_back({point, preset->id, 0});
    }
}

void capture_special_chests(Room2* room) {
    if (!room) return;
    for (auto* preset = static_cast<PresetUnit*>(room->presets);
         preset; preset = preset->next) {
        // Countess chest, small/large sparkly chest, and super chest.
        if (preset->type != 2 || !is_special_chest(preset->id)) continue;
        POINT point{static_cast<LONG>(room->x * 5 + preset->x),
            static_cast<LONG>(room->y * 5 + preset->y)};
        const bool exists = std::any_of(special_chests.begin(), special_chests.end(),
            [&](const POINT& old) { return old.x == point.x && old.y == point.y; });
        if (!exists) special_chests.push_back(point);
    }
}

void capture_normal_containers(Room2* room) {
    if (!room) return;
    for (auto* preset = static_cast<PresetUnit*>(room->presets);
         preset; preset = preset->next) {
        if (preset->type != 2 || !is_normal_container(preset->id)) continue;
        POINT point{static_cast<LONG>(room->x * 5 + preset->x),
            static_cast<LONG>(room->y * 5 + preset->y)};
        const bool exists = std::any_of(normal_containers.begin(),
            normal_containers.end(), [&](const ContainerMarker& old) {
                return old.point.x == point.x && old.point.y == point.y;
            });
        if (!exists) normal_containers.push_back({point, preset->id});
    }
}

void capture_container_states(Room1* room) noexcept {
    if (!room) return;
    int guard = 0;
    for (UnitAny* unit = room->first_unit; unit && guard++ < 2048;
         unit = unit->room_next) {
        if (unit->type != 2 || !unit->path ||
            (!is_normal_container(unit->id) && !is_special_chest(unit->id)))
            continue;
        const auto* path = static_cast<const std::uint8_t*>(unit->path);
        POINT point{
            static_cast<LONG>(*reinterpret_cast<const std::uint32_t*>(path + 0x0c)),
            static_cast<LONG>(*reinterpret_cast<const std::uint32_t*>(path + 0x10))};
        if (unit->mode != 0) {
            if (!point_is_opened(point)) opened_containers.push_back(point);
        } else if (is_normal_container(unit->id)) {
            const bool exists = std::any_of(normal_containers.begin(),
                normal_containers.end(), [&](const ContainerMarker& old) {
                    return std::abs(old.point.x - point.x) <= 2 &&
                        std::abs(old.point.y - point.y) <= 2;
                });
            if (!exists) normal_containers.push_back({point, unit->id});
        }
    }
}

void capture_waypoints(Room2* room) {
    if (!room) return;
    for (auto* preset = static_cast<PresetUnit*>(room->presets);
         preset; preset = preset->next) {
        if (preset->type != 2 || !is_waypoint_object(preset->id)) continue;
        POINT point{static_cast<LONG>(room->x * 5 + preset->x),
            static_cast<LONG>(room->y * 5 + preset->y)};
        const bool exists = std::any_of(waypoint_markers.begin(), waypoint_markers.end(),
            [&](const POINT& old) { return old.x == point.x && old.y == point.y; });
        if (!exists) waypoint_markers.push_back(point);
    }
}

void capture_shrine_effects(Room1* room) noexcept {
    if (!room) return;
    int guard = 0;
    for (UnitAny* unit = room->first_unit; unit && guard++ < 2048;
         unit = unit->room_next) {
        if (unit->type != 2 || !unit->object_data || !is_shrine_or_well(unit->id))
            continue;
        if (!unit->path) continue;
        const auto* object_path = static_cast<const std::uint8_t*>(unit->path);
        const auto object_x = *reinterpret_cast<const std::uint32_t*>(object_path + 0x0c);
        const auto object_y = *reinterpret_cast<const std::uint32_t*>(object_path + 0x10);
        auto found = std::find_if(shrine_markers.begin(), shrine_markers.end(),
            [&](const ShrineMarker& marker) {
                return std::abs(marker.point.x - static_cast<LONG>(object_x)) <= 2 &&
                    std::abs(marker.point.y - static_cast<LONG>(object_y)) <= 2;
            });
        if (found != shrine_markers.end()) {
            found->effect = unit->object_data->shrine_type;
        } else {
            // Some active rooms (notably Act 3) no longer expose the preset
            // that was used to create the shrine. Create its map marker from
            // the live object instead of requiring a preset marker first.
            shrine_markers.push_back({
                {static_cast<LONG>(object_x), static_cast<LONG>(object_y)},
                unit->id, unit->object_data->shrine_type});
        }
    }
}

void refresh_shrine_effects(std::uint8_t* player) noexcept {
    auto* act = *reinterpret_cast<std::uint8_t**>(player + 0x1c);
    if (!act) return;
    Room1* room = *reinterpret_cast<Room1**>(act + 0x10);
    int guard = 0;
    while (room && guard++ < 256) {
        capture_shrine_effects(room);
        capture_container_states(room);
        room = room->next_active;
    }
}

std::uint32_t tile_destination(Room2* room, std::uint32_t tile_id) noexcept {
    for (auto* tile = static_cast<RoomTile*>(room->room_tiles); tile; tile = tile->next) {
        if (tile->number && *tile->number == tile_id && tile->room && tile->room->level)
            return tile->room->level->number;
    }
    return 0;
}

bool resolve_target(std::uint8_t* player, Level* level,
    const navigation_data::Target& target, POINT& point) noexcept {
    if (target.type == 0) return false;
    // Type 8 is the Act 2 true tomb selected for this game. The value is
    // stored in ActMisc::dwStaffTombLevel and changes between games.
    if (target.type == 8) {
        if (!level->act_misc) return false;
        const auto* misc = static_cast<const std::uint8_t*>(level->act_misc);
        const std::uint32_t true_tomb =
            *reinterpret_cast<const std::uint32_t*>(misc + 0x94);
        if (true_tomb < 66 || true_tomb > 72) return false;
        return resolve_target(player, level,
            navigation_data::Target{6u, true_tomb, 0u, 0u}, point);
    }
    void* act = *reinterpret_cast<void**>(player + 0x1c);
    if (!act) return false;
    for (Room2* room = level->first_room; room; room = room->next) {
        const bool added = room->room1 == nullptr;
        if (added) add_room(act, static_cast<int>(level->number),
            static_cast<int>(room->x), static_cast<int>(room->y), nullptr);
        bool found = false;
        for (auto* preset = static_cast<PresetUnit*>(room->presets);
             preset; preset = preset->next) {
            if ((target.type == preset->type && target.id == preset->id) ||
                (target.type == 6 && preset->type == 5 &&
                    tile_destination(room, preset->id) == target.id)) {
                point.x = static_cast<LONG>(room->x * 5 + preset->x);
                point.y = static_cast<LONG>(room->y * 5 + preset->y);
                found = true;
                break;
            }
        }
        if (!found && target.type == 6 && room->near_rooms) {
            for (std::uint32_t i = 0; i < room->near_count; ++i) {
                Room2* adjacent = room->near_rooms[i];
                if (adjacent && adjacent->level && adjacent->level->number == target.id) {
                    point.x = static_cast<LONG>(room->x * 5 + room->size_x * 5 / 2);
                    point.y = static_cast<LONG>(room->y * 5 + room->size_y * 5 / 2);
                    found = true;
                    break;
                }
            }
        }
        if (added) remove_room(act, static_cast<int>(level->number),
            static_cast<int>(room->x), static_cast<int>(room->y), nullptr);
        if (found) return true;
    }
    return false;
}

void record_shop_route_frame(UnitAny* player, std::uint32_t level_number) noexcept {
    const bool key_down = (GetAsyncKeyState(VK_F9) & 0x8000) != 0;
    if (key_down && !shop_route_key_down) {
        if (shop_route_recording) {
            shop_route_recording = false;
            logger::write("F9 shop route recording cancelled");
        } else if (level_number == 40 && player && get_unit_x && get_unit_y) {
            learned_shop_route.clear();
            learned_shop_route.push_back({get_unit_x(player), get_unit_y(player)});
            shop_route_recording = true;
            logger::write("F9 shop route recording started beside Drognan");
        }
    }
    shop_route_key_down = key_down;
    if (!shop_route_recording || !player || !get_unit_x || !get_unit_y) return;
    const POINT current{get_unit_x(player), get_unit_y(player)};
    const POINT last = learned_shop_route.back();
    if (std::abs(current.x - last.x) + std::abs(current.y - last.y) >= 2)
        learned_shop_route.push_back(current);
    if (level_number == 41) {
        if (learned_shop_route.back().x != current.x ||
            learned_shop_route.back().y != current.y)
            learned_shop_route.push_back(current);
        shop_route_recording = false;
        char saa[160]{};
        const POINT first = learned_shop_route.front();
        const POINT last_point = learned_shop_route.back();
        wsprintfA(saa,
            "F9 shop route learned: %u points, (%ld,%ld) -> (%ld,%ld)",
            static_cast<unsigned>(learned_shop_route.size()),
            first.x, first.y, last_point.x, last_point.y);
        logger::write(saa);
    }
}

void run_to_location(const POINT& point) noexcept {
    if (!click_map || !map_to_screen || !get_mouse_x_offset ||
        !get_mouse_y_offset) return;
    long x = point.x;
    long y = point.y;
    map_to_screen(&x, &y);
    x -= static_cast<long>(get_mouse_x_offset());
    y -= static_cast<long>(get_mouse_y_offset());
    click_map(0, static_cast<std::uint32_t>(x),
        static_cast<std::uint32_t>(y), 0);
}

UnitAny* find_active_drognan(std::uint8_t* player) noexcept {
    if (!player) return nullptr;
    auto* act = *reinterpret_cast<std::uint8_t**>(player + 0x1c);
    if (!act) return nullptr;
    Room1* room = *reinterpret_cast<Room1**>(act + 0x10);
    for (int rooms = 0; room && rooms++ < 256; room = room->next_active) {
        int units = 0;
        for (UnitAny* unit = room->first_unit; unit && units++ < 4096;
             unit = unit->room_next) {
            if (unit->type == 1 && unit->id == 177) return unit;
        }
    }
    return nullptr;
}

void request_drognan_session(std::uint32_t npc_id) noexcept {
#pragma pack(push, 1)
    struct InteractPacket {
        std::uint8_t opcode;
        std::uint32_t entity_type;
        std::uint32_t entity_id;
    };
#pragma pack(pop)
    InteractPacket interact{0x13, 1, npc_id};
    InteractPacket initialize{0x2f, 1, npc_id};
    send_packet(sizeof(interact), 1, &interact);
    send_packet(sizeof(initialize), 1, &initialize);
}

void request_drognan_shop(std::uint32_t npc_id) noexcept {
#pragma pack(push, 1)
    struct NpcTradePacket {
        std::uint8_t opcode;
        std::uint32_t action;
        std::uint32_t npc_id;
        std::uint32_t complement;
    };
#pragma pack(pop)
    NpcTradePacket packet{0x38, 1, npc_id, 0};
    send_packet(sizeof(packet), 1, &packet);
}

void enable_run_mode() noexcept {
    if (!always_run || *always_run != 0) return;
    const HWND window = GetForegroundWindow();
    if (!window) return;
    const WPARAM mouse5 = MAKEWPARAM(0, XBUTTON2);
    PostMessageW(window, WM_XBUTTONDOWN, mouse5, 0);
    PostMessageW(window, WM_XBUTTONUP, mouse5, 0);
    logger::write("Shop refresh: Mouse 5 run toggle sent");
}

void shop_refresh_frame(std::uint8_t* player, Level* level) noexcept {
    record_shop_route_frame(reinterpret_cast<UnitAny*>(player), level->number);
    if (shop_refresh_state == ShopRefreshState::idle || !send_packet) return;
    const DWORD now = GetTickCount();
    if (static_cast<LONG>(now - shop_refresh_deadline) >= 0) {
        shop_refresh_state = ShopRefreshState::idle;
        logger::write("Shop refresh stopped: 45-second route timeout");
        return;
    }
    if (static_cast<LONG>(now - shop_refresh_next_action) < 0) return;
    if (shop_refresh_state == ShopRefreshState::open_npc_session) {
        UnitAny* drognan = find_active_drognan(player);
        if (!drognan) {
            shop_refresh_next_action = now + 400;
            return;
        }
        shop_refresh_npc_id = drognan->unit_id;
        request_drognan_session(shop_refresh_npc_id);
        shop_refresh_state = ShopRefreshState::open_shop;
        shop_refresh_next_action = now + 500;
        logger::write("Shop refresh: Drognan interaction requested");
        return;
    }
    if (shop_refresh_state == ShopRefreshState::open_shop) {
        request_drognan_shop(shop_refresh_npc_id);
        shop_refresh_state = ShopRefreshState::idle;
        auto_buyer_enabled = true;
        auto_buyer_next_action = now + 500;
        logger::write("Shop refresh: Drognan trade requested");
        return;
    }
    if (shop_refresh_state == ShopRefreshState::close_shop) {
        if (!close_npc_interact) {
            shop_refresh_state = ShopRefreshState::idle;
            logger::write("Shop refresh stopped: close-interact routine unavailable");
            return;
        }
        if (learned_shop_route.size() < 3) {
            shop_refresh_state = ShopRefreshState::idle;
            logger::write("Shop refresh stopped: press F9 beside Drognan and teach the route first");
            return;
        }
        close_npc_interact();
        enable_run_mode();
        shop_refresh_state = ShopRefreshState::leave_town;
        shop_route_index = 1;
        shop_refresh_next_action = now + 400;
        logger::write("Shop refresh: trade closed, replaying learned route outward");
        return;
    }
    if (level->number == 41 && shop_refresh_state == ShopRefreshState::leave_town) {
        shop_refresh_state = ShopRefreshState::return_town;
        shop_route_index = learned_shop_route.size() > 1
            ? learned_shop_route.size() - 2 : 0;
        shop_refresh_next_action = now + 600;
        logger::write("Shop refresh: Rocky Waste confirmed, returning to town");
        return;
    }
    const bool leaving = shop_refresh_state == ShopRefreshState::leave_town;
    if (!leaving && shop_refresh_state != ShopRefreshState::return_town) return;
    if (leaving && level->number != 40u) {
        shop_refresh_state = ShopRefreshState::idle;
        logger::write("Shop refresh stopped: unexpected area");
        return;
    }
    const POINT current{get_unit_x(player), get_unit_y(player)};
    if (leaving) {
        if (shop_route_index < learned_shop_route.size()) {
            const POINT target = learned_shop_route[shop_route_index];
            run_to_location(target);
            if (std::abs(current.x - target.x) <= 2 &&
                std::abs(current.y - target.y) <= 2)
                ++shop_route_index;
        }
    } else {
        const POINT target = learned_shop_route[shop_route_index];
        run_to_location(target);
        const bool reached = std::abs(current.x - target.x) <= 2 &&
            std::abs(current.y - target.y) <= 2;
        if (reached && shop_route_index == 0 && level->number == 40) {
            shop_refresh_state = ShopRefreshState::open_npc_session;
            shop_refresh_next_action = now + 600;
            shop_refresh_deadline = now + 10000;
            logger::write("Shop refresh: learned route returned to Drognan; reopening trade");
            return;
        }
        if (reached && shop_route_index > 0) --shop_route_index;
    }
    shop_refresh_next_action = now + 220;
}

POINT to_automap(long x, long y) noexcept {
    map_to_screen(&x, &y);
    const int scale = automap_mode && *automap_mode ? *automap_mode : 1;
    return {x / scale - automap_offset->x + 8,
        y / scale - automap_offset->y - 8};
}

void refresh_render_bounds() noexcept {
    // This target's D2HD surface is at most 1068x600. cnc-ddraw can stretch
    // that surface to a much larger desktop/client area, but D2CMP still draws
    // into the smaller logical surface.
    constexpr int maximum_width = 1068;
    constexpr int maximum_height = 600;
    int client_width = maximum_width;
    int client_height = maximum_height;
    const HWND window = GetForegroundWindow();
    DWORD process_id = 0;
    if (window && GetWindowThreadProcessId(window, &process_id) != 0 &&
        process_id == GetCurrentProcessId()) {
        RECT client{};
        if (GetClientRect(window, &client) && client.right > client.left &&
            client.bottom > client.top) {
            client_width = client.right - client.left;
            client_height = client.bottom - client.top;
        }
    }
    render_width = std::clamp(client_width, 640, maximum_width);
    render_height = std::clamp(client_height, 480, maximum_height);
}

bool automap_line_is_safe(int x1, int y1, int x2, int y2) noexcept {
    // D2Gfx forwards these coordinates to D2CMP without reliably clipping
    // extreme values. A stale/wrong automap offset can therefore turn a
    // harmless off-screen marker into an access violation in D2CMP.
    return x1 >= 0 && x1 < render_width && x2 >= 0 && x2 < render_width &&
        y1 >= 0 && y1 < render_height && y2 >= 0 && y2 < render_height;
}

bool automap_point_is_safe(const POINT& point, int margin = 0) noexcept {
    return point.x >= margin && point.x < render_width - margin &&
        point.y >= margin && point.y < render_height - margin;
}

void draw_automap_line(int x1, int y1, int x2, int y2,
    std::uint32_t color) noexcept {
    if (!draw_line || !automap_line_is_safe(x1, y1, x2, y2)) {
        static volatile long rejection_logged = 0;
        if (draw_line && InterlockedCompareExchange(&rejection_logged, 1, 0) == 0) {
            char message[160]{};
            wsprintfA(message,
                "Rejected unsafe automap line: (%d,%d)-(%d,%d), color=%u",
                x1, y1, x2, y2, color);
            logger::write(message);
        }
        return;
    }
    draw_line(x1, y1, x2, y2, color, 0xff);
}

bool clip_navigation_line(int& x1, int& y1, int& x2, int& y2) noexcept {
    // Liang-Barsky clipping keeps the true bearing to an off-screen target,
    // while ensuring D2CMP receives only coordinates inside the viewport.
    constexpr double margin = 2.0;
    const double xmin = margin;
    const double ymin = margin;
    const double xmax = static_cast<double>(render_width) - margin - 1.0;
    const double ymax = static_cast<double>(render_height) - margin - 1.0;
    const double ax = static_cast<double>(x1);
    const double ay = static_cast<double>(y1);
    const double dx = static_cast<double>(x2) - ax;
    const double dy = static_cast<double>(y2) - ay;
    double enter = 0.0;
    double leave = 1.0;
    const auto edge = [&enter, &leave](double p, double q) noexcept {
        if (p == 0.0) return q >= 0.0;
        const double ratio = q / p;
        if (p < 0.0) {
            if (ratio > leave) return false;
            if (ratio > enter) enter = ratio;
        } else {
            if (ratio < enter) return false;
            if (ratio < leave) leave = ratio;
        }
        return true;
    };
    if (!edge(-dx, ax - xmin) || !edge(dx, xmax - ax) ||
        !edge(-dy, ay - ymin) || !edge(dy, ymax - ay)) return false;
    x2 = static_cast<int>(ax + leave * dx);
    y2 = static_cast<int>(ay + leave * dy);
    x1 = static_cast<int>(ax + enter * dx);
    y1 = static_cast<int>(ay + enter * dy);
    return automap_line_is_safe(x1, y1, x2, y2);
}

void draw_shrines() noexcept {
    if (!automap_on || !*automap_on || !draw_line || !map_to_screen ||
        !automap_offset) return;
    for (const ShrineMarker& marker : shrine_markers) {
        const POINT p = to_automap(marker.point.x, marker.point.y);
        // A compact gold diamond remains recognizable at every automap scale.
        constexpr std::uint32_t color = 0x0d;
        constexpr int radius = 4;
        if (!automap_point_is_safe(p, radius + 8)) continue;
        draw_automap_line(p.x, p.y - radius, p.x + radius, p.y, color);
        draw_automap_line(p.x + radius, p.y, p.x, p.y + radius, color);
        draw_automap_line(p.x, p.y + radius, p.x - radius, p.y, color);
        draw_automap_line(p.x - radius, p.y, p.x, p.y - radius, color);
        if (draw_text && set_text_size) {
            wchar_t health[] = L"HP";
            wchar_t mana[] = L"MA";
            wchar_t armor[] = L"AR";
            wchar_t combat[] = L"CO";
            wchar_t skill[] = L"SK";
            wchar_t stamina[] = L"ST";
            wchar_t experience[] = L"XP";
            wchar_t gem[] = L"GEM";
            wchar_t well[] = L"W";
            wchar_t* label = nullptr;
            if (marker.effect == 2) label = health;
            else if (marker.effect == 6) label = armor;
            else if (marker.effect == 7) label = combat;
            else if (marker.effect == 12) label = skill;
            else if (marker.effect == 13) label = mana;
            else if (marker.effect == 14) label = stamina;
            else if (marker.effect == 15) label = experience;
            else if (marker.effect == 18) label = gem;
            else if (marker.object_id == 111 || marker.object_id == 113 ||
                marker.object_id == 115 || marker.object_id == 118 ||
                marker.object_id == 130 || marker.object_id == 132 ||
                marker.object_id == 137 || marker.object_id == 138 ||
                marker.object_id == 322 || marker.object_id == 426 ||
                marker.object_id == 493 || marker.object_id == 498 ||
                marker.object_id == 513 || marker.object_id == 519) label = well;
            if (label) {
                const std::uint32_t old_size = set_text_size(6);
                draw_text(label, p.x - 6, p.y - 7, color, 0);
                set_text_size(old_size);
            }
        }
    }
}

void refresh_special_monsters(std::uint8_t* player,
    std::uint32_t level_number) noexcept {
    special_monsters.clear();
    normal_monsters.clear();
    const bool show_white_cows = level_number == 39;
    auto* act = *reinterpret_cast<std::uint8_t**>(player + 0x1c);
    if (!act) return;
    Room1* room = *reinterpret_cast<Room1**>(act + 0x10);
    int room_guard = 0;
    while (room && room_guard++ < 256) {
        int unit_guard = 0;
        for (UnitAny* unit = room->first_unit; unit && unit_guard++ < 4096;
             unit = unit->room_next) {
            // Monster modes 0 and 12 are death animation and corpse.
            if (unit->type != 1 || !unit->object_data ||
                unit->mode == 0 || unit->mode == 12) continue;
            const auto* monster = reinterpret_cast<const MonsterData*>(unit->object_data);
            // Bits 2, 3 and 4 are champion, unique/boss and unique-pack minion.
            if ((monster->flags & 0x1c) == 0) {
                if (show_white_cows && is_cow(unit->id)) {
                    normal_monsters.push_back(
                        {static_cast<LONG>(unit->x), static_cast<LONG>(unit->y)});
                }
                continue;
            }
            const bool minion = (monster->flags & 0x10) != 0;
            if (minion) continue;
            MonsterMarkerKind kind = MonsterMarkerKind::unique;
            if (minion) kind = MonsterMarkerKind::minion;
            else if (is_known_uber(unit->id)) kind = MonsterMarkerKind::uber;
            else if (is_act_boss(unit->id)) kind = MonsterMarkerKind::act_boss;
            else if ((monster->flags & 0x04) != 0)
                kind = MonsterMarkerKind::champion;
            std::uint8_t life_percent = 0;
            if (get_unit_stat && show_boss_life(unit->id, level_number, kind)) {
                const std::uint32_t current_life = get_unit_stat(unit, 6, 0) >> 8;
                const std::uint32_t maximum_life = get_unit_stat(unit, 7, 0) >> 8;
                if (maximum_life > 0 && current_life <= maximum_life)
                    life_percent = static_cast<std::uint8_t>(
                        std::min<std::uint32_t>(100,
                            (current_life * 100u) / maximum_life));
            }
            special_monsters.push_back({
                {static_cast<LONG>(unit->x), static_cast<LONG>(unit->y)},
                kind,
                monster_immunities(unit),
                monster_enchantments(unit, monster),
                life_percent});
        }
        room = room->next_active;
    }
}

void monster_marker_toggle_frame() noexcept {
    const bool down = (GetAsyncKeyState(VK_NUMPAD5) & 0x8000) != 0;
    if (down && !num5_down) {
        monster_marker_mode = (monster_marker_mode + 1) % 4;
        normal_monsters.clear();
        special_monsters.clear();
        next_monster_tick = GetTickCount();
        static constexpr const char* names[4]{
            "all", "bosses and special minions", "bosses only", "none"};
        char message[96]{};
        wsprintfA(message, "Num5 monster markers: %s", names[monster_marker_mode]);
        logger::write(message);
    }
    num5_down = down;
}

void draw_monster_marker_mode() noexcept {
    if (!automap_on || !*automap_on || !draw_text || !set_text_size) return;
    wchar_t all[] = L"MOBS: ALL";
    wchar_t special[] = L"MOBS: SPECIAL";
    wchar_t bosses[] = L"MOBS: BOSS";
    wchar_t off[] = L"MOBS: OFF";
    wchar_t* labels[4]{all, special, bosses, off};
    static constexpr std::uint32_t colors[4]{0xd0, 0x9b, 0x0a, 0x84};
    const std::uint32_t old_size = set_text_size(1);
    draw_text(labels[monster_marker_mode], 15, 90,
        colors[monster_marker_mode], 0);
    set_text_size(old_size);
}

void draw_normal_monsters() noexcept {
    if (!automap_on || !*automap_on || !draw_line || !map_to_screen ||
        !automap_offset) return;
    constexpr std::uint32_t color = 0xd0;
    constexpr std::uint32_t outline = 0x00;
    constexpr int radius = 3;
    for (const POINT& monster : normal_monsters) {
        const POINT p = to_automap(monster.x, monster.y);
        if (!automap_point_is_safe(p, radius + 1)) continue;
        for (int offset = -1; offset <= 1; ++offset) {
            draw_automap_line(p.x - radius - 1, p.y + offset,
                p.x + radius + 1, p.y + offset, outline);
            draw_automap_line(p.x + offset, p.y - radius - 1,
                p.x + offset, p.y + radius + 1, outline);
        }
        draw_automap_line(p.x - radius, p.y, p.x + radius, p.y, color);
        draw_automap_line(p.x, p.y - radius, p.x, p.y + radius, color);
    }
}

void draw_special_monster_labels(const SpecialMonster& monster,
    const POINT& point) noexcept {
    if (!draw_text || !set_text_size) return;
    struct Label { wchar_t* text; std::uint32_t color; };
    wchar_t physical_immune[] = L"Psy imu";
    wchar_t cold_immune[] = L"Cold imu";
    wchar_t fire_immune[] = L"Fire imu";
    wchar_t lightning_immune[] = L"Light imu";
    wchar_t poison_immune[] = L"Psn. imu";
    wchar_t cold_enchanted[] = L"Cold";
    wchar_t fire_enchanted[] = L"Fire";
    wchar_t lightning_enchanted[] = L"Light";
    wchar_t poison_enchanted[] = L"Psn.";
    wchar_t life[16]{};
    constexpr std::uint32_t white = 0;
    constexpr std::uint32_t red = 1;
    constexpr std::uint32_t green = 2;
    constexpr std::uint32_t blue = 3;
    constexpr std::uint32_t yellow = 9;
    std::array<Label, 10> labels{};
    std::size_t count = 0;
    const auto add = [&labels, &count](bool present, wchar_t* text,
                         std::uint32_t color) noexcept {
        if (present && count < labels.size()) labels[count++] = {text, color};
    };
    if (monster.life_percent > 0) {
        wsprintfW(life, L"HP %u%%", static_cast<unsigned>(monster.life_percent));
        add(true, life, white);
    }
    add((monster.immunities & element_physical) != 0, physical_immune, white);
    add((monster.immunities & element_cold) != 0, cold_immune, blue);
    add((monster.immunities & element_fire) != 0, fire_immune, red);
    add((monster.immunities & element_lightning) != 0, lightning_immune, yellow);
    add((monster.immunities & element_poison) != 0, poison_immune, green);
    add((monster.enchantments & element_cold) != 0, cold_enchanted, blue);
    add((monster.enchantments & element_fire) != 0, fire_enchanted, red);
    add((monster.enchantments & element_lightning) != 0, lightning_enchanted, yellow);
    add((monster.enchantments & element_poison) != 0, poison_enchanted, green);
    if (count == 0) return;

    const int x = point.x - 20;
    int y = point.y + 12;
    if (x < 0 || x >= render_width - 72 || y < 0) return;
    const std::uint32_t old_size = set_text_size(6);
    for (std::size_t index = 0; index < count && y < render_height - 10;
         ++index, y += 9) {
        draw_text(labels[index].text, x, y, labels[index].color, 0);
    }
    set_text_size(old_size);
}

void draw_special_monsters() noexcept {
    if (!automap_on || !*automap_on || !draw_line || !map_to_screen ||
        !automap_offset) return;
    constexpr int radius = 5;
    for (const SpecialMonster& monster : special_monsters) {
        std::uint32_t color = 0x0d;  // unique/super-unique: orange/gold
        if (monster.kind == MonsterMarkerKind::minion) color = 0x9b;
        else if (monster.kind == MonsterMarkerKind::champion) color = 0x97;
        else if (monster.kind == MonsterMarkerKind::act_boss) color = 0x0a;
        else if (monster.kind == MonsterMarkerKind::uber) color = 0x9b;
        const POINT p = to_automap(monster.point.x, monster.point.y);
        if (!automap_point_is_safe(p, radius + 1)) continue;
        constexpr std::uint32_t outline = 0x00;
        for (int offset = -1; offset <= 1; ++offset) {
            draw_automap_line(p.x - radius - 1, p.y + offset,
                p.x + radius + 1, p.y + offset, outline);
            draw_automap_line(p.x + offset, p.y - radius - 1,
                p.x + offset, p.y + radius + 1, outline);
            draw_automap_line(p.x - 4, p.y - 4 + offset,
                p.x + 4, p.y + 4 + offset, outline);
            draw_automap_line(p.x + 4, p.y - 4 + offset,
                p.x - 4, p.y + 4 + offset, outline);
        }
        draw_automap_line(p.x - radius, p.y, p.x + radius, p.y, color);
        draw_automap_line(p.x, p.y - radius, p.x, p.y + radius, color);
        draw_automap_line(p.x - 3, p.y - 3, p.x + 3, p.y + 3, color);
        draw_automap_line(p.x + 3, p.y - 3, p.x - 3, p.y + 3, color);
        draw_special_monster_labels(monster, p);
    }
}

void draw_special_chests() noexcept {
    if (!automap_on || !*automap_on || !draw_line || !map_to_screen ||
        !automap_offset) return;
    constexpr std::uint32_t color = 0x97;
    constexpr int radius = 7;
    for (const POINT& chest : special_chests) {
        if (point_is_opened(chest)) continue;
        const POINT p = to_automap(chest.x, chest.y);
        if (!automap_point_is_safe(p, radius + 1)) continue;
        // Three parallel strokes per diagonal make special chests stand out
        // without increasing the size of monster markers.
        for (int offset = -1; offset <= 1; ++offset) {
            draw_automap_line(p.x - radius, p.y - radius + offset,
                p.x + radius, p.y + radius + offset, color);
            draw_automap_line(p.x + radius, p.y - radius + offset,
                p.x - radius, p.y + radius + offset, color);
        }
    }
}

void draw_normal_containers() noexcept {
    if (!automap_on || !*automap_on || !draw_line || !map_to_screen ||
        !automap_offset) return;
    constexpr std::uint32_t color = 0x9b;
    constexpr int radius = 3;
    for (const ContainerMarker& marker : normal_containers) {
        if (point_is_opened(marker.point)) continue;
        const POINT p = to_automap(marker.point.x, marker.point.y);
        if (!automap_point_is_safe(p, radius + 1)) continue;
        draw_automap_line(p.x - radius, p.y - radius,
            p.x + radius, p.y + radius, color);
        draw_automap_line(p.x + radius, p.y - radius,
            p.x - radius, p.y + radius, color);
    }
}

void draw_waypoints() noexcept {
    if (!automap_on || !*automap_on || !draw_line || !map_to_screen ||
        !automap_offset) return;
    constexpr std::uint32_t color = 0x84;
    constexpr int radius = 5;
    for (const POINT& waypoint : waypoint_markers) {
        const POINT p = to_automap(waypoint.x, waypoint.y);
        if (!automap_point_is_safe(p, radius + 8)) continue;
        draw_automap_line(p.x - radius, p.y - radius, p.x + radius, p.y - radius, color);
        draw_automap_line(p.x + radius, p.y - radius, p.x + radius, p.y + radius, color);
        draw_automap_line(p.x + radius, p.y + radius, p.x - radius, p.y + radius, color);
        draw_automap_line(p.x - radius, p.y + radius, p.x - radius, p.y - radius, color);
        if (draw_text && set_text_size) {
            wchar_t label[] = L"WP";
            const std::uint32_t old_size = set_text_size(6);
            draw_text(label, p.x - 6, p.y - 7, color, 0);
            set_text_size(old_size);
        }
    }
}

int capture_overlay_exception(EXCEPTION_POINTERS* exception) noexcept {
    if (exception && exception->ExceptionRecord) {
        overlay_fault_code = exception->ExceptionRecord->ExceptionCode;
        overlay_fault_address = exception->ExceptionRecord->ExceptionAddress;
    }
    return EXCEPTION_EXECUTE_HANDLER;
}

using OverlayDraw = void(*)() noexcept;

void draw_overlay_stage(std::size_t index, const char* name,
    OverlayDraw callback) noexcept {
    if (index >= overlay_stage_enabled.size() ||
        !overlay_stage_enabled[index] || !callback) return;
    overlay_stage = name;
    __try {
        callback();
        overlay_stage = "idle";
    } __except (capture_overlay_exception(GetExceptionInformation())) {
        overlay_stage_enabled[index] = false;
        char message[192]{};
        wsprintfA(message,
            "DISABLED only automap stage %s after exception 0x%08lX at %p",
            overlay_stage,
            overlay_fault_code, overlay_fault_address);
        logger::write(message);
        overlay_stage = "idle";
    }
}

void log_graphics_module_identity(const wchar_t* module_name) noexcept {
    const HMODULE module = GetModuleHandleW(module_name);
    if (!module) return;
    const auto* base = reinterpret_cast<const std::uint8_t*>(module);
    const auto* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(base);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE || dos->e_lfanew <= 0) return;
    const auto* nt = reinterpret_cast<const IMAGE_NT_HEADERS32*>(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return;
    char path[MAX_PATH]{};
    GetModuleFileNameA(module, path, MAX_PATH);
    char message[MAX_PATH + 96]{};
    wsprintfA(message, "Graphics module %S: timestamp=0x%08lX image_size=0x%08lX path=%s",
        module_name, nt->FileHeader.TimeDateStamp,
        nt->OptionalHeader.SizeOfImage, path);
    logger::write(message);
}

void draw_automap_overlays() noexcept {
    refresh_render_bounds();
    draw_overlay_stage(0, "shrines", &draw_shrines);
    draw_overlay_stage(1, "normal_monsters", &draw_normal_monsters);
    draw_overlay_stage(2, "special_monsters", &draw_special_monsters);
    draw_overlay_stage(3, "special_chests", &draw_special_chests);
    draw_overlay_stage(4, "normal_containers", &draw_normal_containers);
    draw_overlay_stage(5, "waypoints", &draw_waypoints);
}

void navigation_frame(std::uint8_t* player, Level* level) noexcept {
    static constexpr int keys[4]{VK_NUMPAD1, VK_NUMPAD2, VK_NUMPAD3, VK_NUMPAD4};
    for (int i = 0; i < 4; ++i) {
        const bool down = (GetAsyncKeyState(keys[i]) & 0x8000) != 0;
        if (down && !num_down[i] &&
            level->number < navigation_data::targets.size()) {
            POINT candidate{};
            const auto& descriptor = navigation_data::targets[level->number][i];
            if (resolve_target(player, level, descriptor, candidate)) {
                selected_target = candidate;
                selected_key = i;
                selected_target_valid = true;
                char message[96]{};
                wsprintfA(message, "Num%d target selected: type %u id %u at %ld,%ld",
                    i + 1, descriptor.type, descriptor.id, candidate.x, candidate.y);
                logger::write(message);
            } else {
                selected_key = i;
                selected_target_valid = false;
                char message[80]{};
                wsprintfA(message, "Num%d target unavailable: type %u id %u",
                    i + 1, descriptor.type, descriptor.id);
                logger::write(message);
            }
        }
        num_down[i] = down;
    }
    if (selected_key < 0 || !selected_target_valid ||
        !automap_on || !*automap_on || !draw_line ||
        !map_to_screen || !automap_offset) return;
    auto* path = *reinterpret_cast<std::uint8_t**>(player + 0x2c);
    if (!path) return;
    const long player_x = *reinterpret_cast<std::uint16_t*>(path + 2);
    const long player_y = *reinterpret_cast<std::uint16_t*>(path + 6);
    const POINT from = to_automap(player_x, player_y);
    const POINT to = to_automap(selected_target.x, selected_target.y);
    static constexpr std::uint32_t colors[4]{0x97, 0x0a, 0x84, 0x0d};
    int x1 = from.x, y1 = from.y, x2 = to.x, y2 = to.y;
    if (clip_navigation_line(x1, y1, x2, y2))
        draw_automap_line(x1, y1, x2, y2, colors[selected_key]);
}

void reveal_frame() noexcept {
    refresh_render_bounds();
    imported_shopper::draw_shop_winners();
    imported_shopper::automated_shopper_frame();
    pindle_test_frame();
    malah_test_frame();
    const DWORD frame_now = GetTickCount();
    const bool player_present = player_slot && *player_slot;
    if (!player_present) {
        if (pindle_exit_requested) {
            pindle_lobby_seen = true;
            lobby_missing_player_since = 0;
        }
        if (game_session_seen && !pindle_exit_requested) {
            if (!lobby_missing_player_since)
                lobby_missing_player_since = frame_now;
            else if (static_cast<LONG>(frame_now -
                         lobby_missing_player_since) >= 3000) {
                logger::write("SAFETY EXIT: lobby detected after active game");
                TerminateProcess(GetCurrentProcess(), 0);
                return;
            }
        }
    } else {
        if (pindle_exit_requested && pindle_lobby_seen) {
            pindle_exit_requested = false;
            pindle_lobby_seen = false;
        }
        game_session_seen = true;
        lobby_missing_player_since = 0;
    }
    if (!player_slot || !layer_slot || !*player_slot || !*layer_slot) {
        last_level = nullptr; passes = 0; return;
    }
    auto* player = static_cast<std::uint8_t*>(*player_slot);
    auto* path = *reinterpret_cast<std::uint8_t**>(player + 0x2c);
    if (!path) return;
    auto* room1 = *reinterpret_cast<Room1**>(path + 0x1c);
    if (!room1 || !room1->room2 || !room1->room2->level) return;
    Level* level = room1->room2->level;
    const DWORD now = GetTickCount();
    constexpr bool portal_timeout_enabled = false; // F9 Normal test pause
    if constexpr (portal_timeout_enabled) {
        const bool anya_shop_safety = imported_shopper::shopper_active &&
            imported_shopper::shopper_profile ==
                imported_shopper::ShopperProfile::anya;
        if (anya_shop_safety && level->number == 121) {
            if (!anya_portal_entered_at) {
                anya_portal_entered_at = now;
                logger::write("SAFETY: entered Anya red-portal level; 5-second limit armed");
            } else if (static_cast<LONG>(now - anya_portal_entered_at) >= 5000) {
                logger::write("SAFETY EXIT: remained in Anya red-portal level for 5 seconds");
                TerminateProcess(GetCurrentProcess(), 0);
                return;
            }
        } else {
            anya_portal_entered_at = 0;
        }
    } else {
        anya_portal_entered_at = 0;
    }
    finish_pending_shrine_rooms(now);
    navigation_frame(player, level);
    if (level != last_level) {
        last_level = level; passes = 24; next_tick = now + 250;
        // Never use zero as an absolute GetTickCount deadline: after Windows
        // has been up for 24.9+ days the signed wrap-safe comparison treats it
        // as a future deadline and live markers never receive their first scan.
        next_monster_tick = now;
        next_dynamic_tick = now;
        processed_rooms.clear();
        shrine_markers.clear();
        special_monsters.clear();
        normal_monsters.clear();
        special_chests.clear();
        normal_containers.clear();
        opened_containers.clear();
        waypoint_markers.clear();
        if (selected_key >= 0 &&
            level->number < navigation_data::targets.size()) {
            POINT candidate{};
            const auto& descriptor =
                navigation_data::targets[level->number][selected_key];
            if (resolve_target(player, level, descriptor, candidate)) {
                selected_target = candidate;
                selected_target_valid = true;
                logger::write("Active Num target refreshed for the new area");
            } else {
                selected_target_valid = false;
                logger::write("Active Num target unavailable in the new area");
            }
        }
        return;
    }

    const bool endgame_map = level->number > 136;
    // Live objects and monsters used to be walked every rendered frame. Large
    // PD2 maps keep hundreds of rooms/units active, so that work grew during a
    // run and produced periodic stalls. A few refreshes per second are enough
    // for markers while drawing the cached points remains smooth.
    if (static_cast<LONG>(now - next_dynamic_tick) >= 0) {
        next_dynamic_tick = now + (endgame_map ? 500 : 200);
        refresh_shrine_effects(player);
    }
    if (monster_marker_mode == 3) {
        special_monsters.clear();
        normal_monsters.clear();
    } else if (static_cast<LONG>(now - next_monster_tick) >= 0) {
        next_monster_tick = now + (endgame_map ? 500 : 250);
        __try {
            refresh_special_monsters(player, level->number);
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            special_monsters.clear();
            normal_monsters.clear();
            monster_marker_mode = 3;
            logger::write("DISABLED monster scanning after guarded access violation");
        }
    }
    draw_automap_overlays();

    if (static_cast<LONG>(now - next_tick) < 0) return;
    if (passes > 0) {
        next_tick = now + 250;
        --passes;
    } else {
        // Act 5 and some large outdoor areas generate additional rooms after
        // the initial reveal window. Keep a low-frequency scan alive so their
        // geometry, waypoints, shrines and special chests are collected.
        next_tick = now + 2000;
    }
    void* act = *reinterpret_cast<void**>(player + 0x1c);
    if (!act) return;
    long count = 0;
    for (Room2* room = level->first_room; room && count < 1024;
         room = room->next, ++count) {
        const bool added = room->room1 == nullptr;
        if (added) add_room(act, static_cast<int>(level->number),
            static_cast<int>(room->x), static_cast<int>(room->y), nullptr);
        const auto key = room_key(room);
        if (room->room1 && processed_rooms.insert(key).second) {
            reveal_room(room->room1, 1, *layer_slot);
            capture_shrines(room);
            capture_special_chests(room);
            capture_normal_containers(room);
            capture_waypoints(room);
            capture_shrine_effects(room->room1);
            InterlockedIncrement(&revealed);
        }
        if (added && config().force_shrine_labels && room_has_shrine(room)) {
            pending_shrine_rooms.push_back({act, room, level->number,
                room->x, room->y, now + 100});
        } else if (added) {
            remove_room(act, static_cast<int>(level->number),
                static_cast<int>(room->x), static_cast<int>(room->y), nullptr);
        }
    }
}
}  // namespace

std::string_view MapReveal::name() const noexcept { return "map_reveal"; }

bool MapReveal::start() noexcept {
    if (!config().project_diablo_map) return true;
    auto* client = reinterpret_cast<std::uint8_t*>(GetModuleHandleW(L"D2Client.dll"));
    auto* project = reinterpret_cast<std::uint8_t*>(GetModuleHandleW(L"ProjectDiablo.dll"));
    if (!client || !project) {
        logger::write("Map reveal delegation unavailable: required module missing"); return false;
    }
    auto* site = client + recovered::kProjectDiabloChain.d2client_site_rva;
    if (site[0] != 0xe8) return false;
    std::int32_t displacement = 0;
    std::memcpy(&displacement, site + 1, sizeof(displacement));
    if (site + 5 + displacement != project + recovered::kProjectDiabloChain.owner_handler_rva) {
        logger::write("Map reveal delegation rejected: ProjectDiablo handler mismatch"); return false;
    }
    HMODULE common = GetModuleHandleW(L"D2Common.dll");
    FARPROC add = common ? GetProcAddress(common,
        reinterpret_cast<LPCSTR>(static_cast<ULONG_PTR>(10401))) : nullptr;
    FARPROC remove = common ? GetProcAddress(common,
        reinterpret_cast<LPCSTR>(static_cast<ULONG_PTR>(11099))) : nullptr;
    FARPROC screen = common ? GetProcAddress(common,
        reinterpret_cast<LPCSTR>(static_cast<ULONG_PTR>(11087))) : nullptr;
    HMODULE gfx = GetModuleHandleW(L"D2Gfx.dll");
    FARPROC line = gfx ? GetProcAddress(gfx,
        reinterpret_cast<LPCSTR>(static_cast<ULONG_PTR>(10010))) : nullptr;
    FARPROC rectangle = gfx ? GetProcAddress(gfx,
        reinterpret_cast<LPCSTR>(static_cast<ULONG_PTR>(10014))) : nullptr;
    HMODULE win = GetModuleHandleW(L"D2Win.dll");
    FARPROC text = win ? GetProcAddress(win,
        reinterpret_cast<LPCSTR>(static_cast<ULONG_PTR>(10150))) : nullptr;
    FARPROC text_size = win ? GetProcAddress(win,
        reinterpret_cast<LPCSTR>(static_cast<ULONG_PTR>(10184))) : nullptr;
    FARPROC unit_stat = common ? GetProcAddress(common,
        reinterpret_cast<LPCSTR>(static_cast<ULONG_PTR>(10973))) : nullptr;
    FARPROC matching_type = common ? GetProcAddress(common,
        reinterpret_cast<LPCSTR>(static_cast<ULONG_PTR>(10744))) : nullptr;
    FARPROC item_price = common ? GetProcAddress(common,
        reinterpret_cast<LPCSTR>(static_cast<ULONG_PTR>(10107))) : nullptr;
    HMODULE net = GetModuleHandleW(L"D2Net.dll");
    FARPROC packet_send = net ? GetProcAddress(net,
        reinterpret_cast<LPCSTR>(static_cast<ULONG_PTR>(10024))) : nullptr;
    if (!add || !remove || !screen || !line || !rectangle || !text ||
        !text_size || !unit_stat || !matching_type || !item_price ||
        !packet_send) return false;
    player_slot = reinterpret_cast<void**>(client + 0x11bbfc);
    layer_slot = reinterpret_cast<void**>(client + 0x11c1c4);
    add_room = reinterpret_cast<AddRoomData>(add);
    remove_room = reinterpret_cast<RemoveRoomData>(remove);
    reveal_room = reinterpret_cast<RevealRoom>(client + 0x62580);
    map_to_screen = reinterpret_cast<MapToAbsScreen>(screen);
    draw_line = reinterpret_cast<DrawLine>(line);
    draw_rectangle = reinterpret_cast<DrawRectangle>(rectangle);
    get_unit_stat = reinterpret_cast<GetUnitStat>(unit_stat);
    is_matching_type = reinterpret_cast<IsMatchingType>(matching_type);
    get_item_price = reinterpret_cast<GetItemPrice>(item_price);
    send_packet = reinterpret_cast<SendPacket>(packet_send);
    get_difficulty = reinterpret_cast<GetDifficulty>(client + 0x41930);
    get_quest_info = reinterpret_cast<GetQuestInfo>(client + 0x45a00);
    click_map = reinterpret_cast<ClickMap>(client + 0x1bf20);
    get_mouse_x_offset = reinterpret_cast<GetMouseOffset>(client + 0x3f6c0);
    get_mouse_y_offset = reinterpret_cast<GetMouseOffset>(client + 0x3f6d0);
    close_npc_interact = reinterpret_cast<CloseNpcInteract>(client + 0x492f0);
    always_run = reinterpret_cast<DWORD*>(client + 0x11c3ec);
    get_unit_x = reinterpret_cast<GetUnitCoordinate>(client + 0x1630);
    get_unit_y = reinterpret_cast<GetUnitCoordinate>(client + 0x1660);
    exit_game = reinterpret_cast<ExitGame>(client + 0x42850);
    get_current_npc = reinterpret_cast<GetCurrentNpc>(client + 0x46150);
    get_item_name = reinterpret_cast<GetItemName>(client + 0x914f0);
    store_layout = reinterpret_cast<InventoryLayout*>(client + 0x10b3b0);
    imported_shopper::shop_action =
        reinterpret_cast<imported_shopper::ShopAction>(client + 0x47d60);
    imported_shopper::interact_internal = client + 0x1bde0;
    imported_shopper::client_mouse_x =
        reinterpret_cast<DWORD*>(client + 0x11b828);
    imported_shopper::client_mouse_y =
        reinterpret_cast<DWORD*>(client + 0x11b824);
    imported_shopper::client_viewport_y =
        reinterpret_cast<int*>(client + 0x11995c);
    imported_shopper::client_viewport_x =
        reinterpret_cast<int*>(client + 0x119960);
    imported_shopper::npc_menu_table =
        reinterpret_cast<imported_shopper::NpcMenu*>(client + 0x0f3ba0);
    imported_shopper::npc_menu_count =
        reinterpret_cast<DWORD*>(client + 0x0f42f0);
    automap_mode = reinterpret_cast<int*>(client + 0xf16b0);
    automap_offset = reinterpret_cast<POINT*>(client + 0x11c1f8);
    automap_on = reinterpret_cast<BOOL*>(client + 0xfada8);
    draw_text = reinterpret_cast<DrawText>(text);
    set_text_size = reinterpret_cast<SetTextSize>(text_size);
    selected_key = 1;
    selected_target_valid = false;
    num_down.fill(false);
    num5_down = false;
    auto_buyer_enabled = false;
    auto_buyer_key_down = false;
    auto_buyer_next_action = 0;
    auto_buyer_last_item = 0;
    auto_buyer_bought_until = 0;
    auto_buyer_bought_skill = 0;
    auto_buyer_bought_fcr = 0;
    shop_refresh_state = ShopRefreshState::idle;
    shop_refresh_next_action = 0;
    shop_refresh_deadline = 0;
    shop_refresh_npc_id = 0;
    shop_refresh_route_step = 0;
    learned_shop_route.clear();
    shop_route_recording = false;
    shop_route_key_down = false;
    shop_route_index = 0;
    imported_shopper::shopper_key_down = false;
    imported_shopper::shopper_active = false;
    imported_shopper::shopper_feedback_until = 0;
    imported_shopper::shopper_feedback[0] = 0;
    imported_shopper::shopper_next_action = 0;
    imported_shopper::shopper_pending_since = 0;
    imported_shopper::shopper_pending_item = 0;
    imported_shopper::shopper_reported_winner = 0;
    imported_shopper::shopper_empty_since = 0;
    imported_shopper::shopper_walk_next = 0;
    imported_shopper::shopper_walk_state =
        imported_shopper::ShopperWalkState::shopping;
    imported_shopper::shopper_profile =
        imported_shopper::ShopperProfile::none;
    imported_shopper::shopper_walk_target_valid = false;
    pindle_state = PindleState::off;
    pindle_key_down = false;
    pindle_started_at = 0;
    pindle_next_action = 0;
    pindle_last_seen_at = 0;
    pindle_unit_id = 0;
    pindle_exit_requested = false;
    pindle_lobby_seen = false;
    monster_marker_mode = 2;
    overlay_stage = "idle";
    overlay_fault_address = nullptr;
    overlay_fault_code = 0;
    overlay_stage_enabled.fill(true);
    game_session_seen = false;
    lobby_missing_player_since = 0;
    anya_portal_entered_at = 0;
    refresh_render_bounds();
    char render_message[96]{};
    wsprintfA(render_message, "Automap logical render bounds: %dx%d",
        render_width, render_height);
    logger::write(render_message);
    log_graphics_module_identity(L"D2CMP.dll");
    log_graphics_module_identity(L"D2Gfx.dll");
    log_graphics_module_identity(L"D2Win.dll");
    log_graphics_module_identity(L"ddraw.dll");
    shrine_markers.clear();
    special_monsters.clear();
    normal_monsters.clear();
    special_chests.clear();
    normal_containers.clear();
    opened_containers.clear();
    waypoint_markers.clear();
    pending_shrine_rooms.clear();
    processed_rooms.clear();
    last_level = nullptr; next_tick = 0; next_monster_tick = 0;
    next_dynamic_tick = 0; passes = 0;
    InterlockedExchange(&revealed, 0);
    if (!recovered::install_site_2929e_hook(&reveal_frame)) return false;
    delegated_to_project_diablo_ = true;
    logger::write("Map reveal armed using verified target-build room routines");
    return true;
}

void MapReveal::stop() noexcept {
    if (delegated_to_project_diablo_) {
        logger::write(recovered::remove_site_2929e_hook(&reveal_frame)
            ? "Map reveal frame hook restored" : "WARNING: map reveal frame hook was not restored");
        char message[64]{}; wsprintfA(message, "Map rooms revealed: %ld", revealed);
        logger::write(message);
    }
    delegated_to_project_diablo_ = false;
    player_slot = layer_slot = nullptr; add_room = nullptr; remove_room = nullptr;
    reveal_room = nullptr; last_level = nullptr; next_tick = 0;
    next_monster_tick = 0; next_dynamic_tick = 0; passes = 0;
    draw_line = nullptr; map_to_screen = nullptr; automap_mode = nullptr;
    automap_offset = nullptr; automap_on = nullptr; selected_key = -1;
    selected_target_valid = false;
    num5_down = false; monster_marker_mode = 2;
    auto_buyer_enabled = false; auto_buyer_key_down = false;
    auto_buyer_next_action = 0; auto_buyer_last_item = 0;
    game_session_seen = false;
    lobby_missing_player_since = 0;
    anya_portal_entered_at = 0;
    draw_text = nullptr; set_text_size = nullptr;
    draw_rectangle = nullptr; get_unit_stat = nullptr; is_matching_type = nullptr;
    get_current_npc = nullptr; get_item_name = nullptr; store_layout = nullptr;
    imported_shopper::shop_action = nullptr;
    imported_shopper::client_mouse_x = imported_shopper::client_mouse_y = nullptr;
    imported_shopper::client_viewport_x =
        imported_shopper::client_viewport_y = nullptr;
    imported_shopper::npc_menu_table = nullptr;
    imported_shopper::npc_menu_count = nullptr;
    imported_shopper::interact_internal = nullptr;
    imported_shopper::shopper_key_down = false;
    imported_shopper::shopper_active = false;
    exit_game = nullptr;
    pindle_exit_requested = false;
    pindle_lobby_seen = false;
    shrine_markers.clear();
    special_monsters.clear();
    normal_monsters.clear();
    special_chests.clear();
    normal_containers.clear();
    opened_containers.clear();
    waypoint_markers.clear();
    pending_shrine_rooms.clear();
    processed_rooms.clear();
}
}  // namespace unleashed
