#include "features/survival.hpp"

#include <cstdint>
#include <windows.h>

#include "core/config.hpp"
#include "core/logger.hpp"
#include "recovered/untouched_handlers.hpp"

namespace unleashed {
namespace {

using GetUnitStat3 = int(__stdcall*)(void*, int, int);
using GetMonsterOwner = DWORD(__fastcall*)(DWORD);
using GetUnitHpPercent = DWORD(__fastcall*)(DWORD);

struct UnitAny;
struct Room1 {
    std::uint32_t unused[29];
    UnitAny* first_unit;
    std::uint32_t unused_after_first;
    Room1* next_active;
};
struct UnitAny {
    std::uint32_t type, class_id, unused0, unit_id, mode;
    void* unit_data;
    std::uint8_t unused1[0xd0];
    UnitAny* room_next;
};

void** player_slot = nullptr;
GetUnitStat3 get_unit_stat3 = nullptr;
GetMonsterOwner get_monster_owner = nullptr;
GetUnitHpPercent get_unit_hp_percent = nullptr;
DWORD last_drink = 0;
DWORD last_mercenary_drink = 0;
volatile long drink_count = 0;
volatile long mercenary_drink_count = 0;
volatile long emergency_exit_triggered = 0;

void tap_belt_key() noexcept {
    DWORD process_id = 0;
    GetWindowThreadProcessId(GetForegroundWindow(), &process_id);
    if (process_id != GetCurrentProcessId()) {
        return;
    }
    const WORD key = static_cast<WORD>('0' + config().rejuvenation_belt_key);
    INPUT input[2]{};
    input[0].type = INPUT_KEYBOARD;
    input[0].ki.wVk = key;
    input[1] = input[0];
    input[1].ki.dwFlags = KEYEVENTF_KEYUP;
    if (SendInput(2, input, sizeof(INPUT)) == 2) {
        InterlockedIncrement(&drink_count);
    }
}

UnitAny* find_owned_mercenary(void* player_pointer) noexcept {
    auto* player = static_cast<std::uint8_t*>(player_pointer);
    auto* act = *reinterpret_cast<std::uint8_t**>(player + 0x1c);
    if (!act || !get_monster_owner) return nullptr;
    Room1* room = *reinterpret_cast<Room1**>(act + 0x10);
    const DWORD player_id = *reinterpret_cast<DWORD*>(player + 0x0c);
    int room_guard = 0;
    while (room && room_guard++ < 256) {
        int unit_guard = 0;
        for (UnitAny* unit = room->first_unit; unit && unit_guard++ < 4096;
             unit = unit->room_next) {
            if (unit->type != 1 ||
                (unit->class_id != 0x010f && unit->class_id != 0x0152 &&
                 unit->class_id != 0x0167 && unit->class_id != 0x0231)) continue;
            if (get_monster_owner(unit->unit_id) == player_id) return unit;
        }
        room = room->next_active;
    }
    return nullptr;
}

void tap_mercenary_belt_key() noexcept {
    DWORD process_id = 0;
    GetWindowThreadProcessId(GetForegroundWindow(), &process_id);
    if (process_id != GetCurrentProcessId()) return;
    const WORD key = static_cast<WORD>('0' + config().mercenary_potion_belt_key);
    INPUT input[4]{};
    input[0].type = INPUT_KEYBOARD;
    input[0].ki.wVk = VK_SHIFT;
    input[1].type = INPUT_KEYBOARD;
    input[1].ki.wVk = key;
    input[2] = input[1];
    input[2].ki.dwFlags = KEYEVENTF_KEYUP;
    input[3] = input[0];
    input[3].ki.dwFlags = KEYEVENTF_KEYUP;
    if (SendInput(4, input, sizeof(INPUT)) == 4)
        InterlockedIncrement(&mercenary_drink_count);
}

void survival_frame() noexcept {
    if (player_slot == nullptr || get_unit_stat3 == nullptr) {
        return;
    }
    void* player = *player_slot;
    if (player == nullptr) {
        return;
    }
    const DWORD now = GetTickCount();
    const int current = get_unit_stat3(player, 6, 0) >> 8;
    const int maximum = get_unit_stat3(player, 7, 0) >> 8;
    if (current <= 0 || maximum <= 0 || current > maximum) {
        return;
    }
    const int percent = (current * 100) / maximum;
    if (config().emergency_exit &&
        percent <= config().emergency_exit_life_percent &&
        InterlockedCompareExchange(&emergency_exit_triggered, 1, 0) == 0) {
        char message[144]{};
        wsprintfA(message,
            "EMERGENCY EXIT: life %d/%d (%d%%) reached configured %d%% threshold",
            current, maximum, percent, config().emergency_exit_life_percent);
        logger::write(message);
        // This deliberately bypasses DLL detach and UI confirmation. The log
        // writer flushes every line, so the reason survives immediate exit.
        TerminateProcess(GetCurrentProcess(), 0xE911);
        return;
    }
    if (config().auto_mercenary_rejuvenation && get_unit_hp_percent) {
        UnitAny* mercenary = find_owned_mercenary(player);
        if (mercenary && mercenary->mode != 0 && mercenary->mode != 12) {
            const DWORD mercenary_percent = get_unit_hp_percent(mercenary->unit_id);
            if (mercenary_percent > 0 &&
                mercenary_percent <= static_cast<DWORD>(
                    config().mercenary_rejuvenation_life_percent) &&
                now - last_mercenary_drink >= static_cast<DWORD>(
                    config().mercenary_rejuvenation_cooldown_ms)) {
                last_mercenary_drink = now;
                tap_mercenary_belt_key();
            }
        }
    }
    if (config().auto_rejuvenation &&
        percent <= config().rejuvenation_life_percent &&
        now - last_drink >= static_cast<DWORD>(config().rejuvenation_cooldown_ms)) {
        last_drink = now;
        tap_belt_key();
    }
}

}  // namespace

std::string_view Survival::name() const noexcept { return "survival"; }
bool Survival::start() noexcept {
    if (!config().auto_rejuvenation && !config().auto_mercenary_rejuvenation &&
        !config().emergency_exit) {
        logger::write("Survival inputs disabled by configuration");
        return true;
    }
    auto* d2client = reinterpret_cast<std::uint8_t*>(GetModuleHandleW(L"D2Client.dll"));
    HMODULE d2common = GetModuleHandleW(L"D2Common.dll");
    if (d2client == nullptr || d2common == nullptr) {
        logger::write("FAILED: auto-rejuvenation modules unavailable");
        return false;
    }
    player_slot = reinterpret_cast<void**>(d2client + 0x11bbfc);
    FARPROC get_stat = GetProcAddress(d2common,
        reinterpret_cast<LPCSTR>(static_cast<ULONG_PTR>(0x2add)));
    if (get_stat == nullptr) {
        player_slot = nullptr;
        logger::write("FAILED: auto-rejuvenation stat binding unavailable");
        return false;
    }
    get_unit_stat3 = reinterpret_cast<GetUnitStat3>(get_stat);
    get_monster_owner = reinterpret_cast<GetMonsterOwner>(d2client + 0x8e3d0);
    get_unit_hp_percent = reinterpret_cast<GetUnitHpPercent>(d2client + 0x8e2b0);
    last_drink = GetTickCount();
    last_mercenary_drink = last_drink;
    InterlockedExchange(&drink_count, 0);
    InterlockedExchange(&mercenary_drink_count, 0);
    InterlockedExchange(&emergency_exit_triggered, 0);
    if (!recovered::install_site_2929e_hook(&survival_frame)) {
        player_slot = nullptr;
        get_unit_stat3 = nullptr;
        logger::write("FAILED: auto-rejuvenation frame hook unavailable");
        return false;
    }
    logger::write("Auto-rejuvenation armed at configured life threshold");
    if (config().auto_mercenary_rejuvenation)
        logger::write("Automatic mercenary rejuvenation armed");
    if (config().emergency_exit) {
        char message[80]{};
        wsprintfA(message, "Emergency process exit armed at %d%% life",
            config().emergency_exit_life_percent);
        logger::write(message);
    }
    return true;
}
void Survival::stop() noexcept {
    if (config().auto_rejuvenation || config().auto_mercenary_rejuvenation ||
        config().emergency_exit) {
        logger::write(recovered::remove_site_2929e_hook(&survival_frame)
            ? "Survival frame hook restored"
            : "WARNING: survival frame hook was not restored");
        char message[80]{};
        wsprintfA(message, "Auto-rejuvenation belt activations: %ld", drink_count);
        logger::write(message);
        wsprintfA(message, "Mercenary potion belt activations: %ld",
            mercenary_drink_count);
        logger::write(message);
    }
    player_slot = nullptr;
    get_unit_stat3 = nullptr;
    get_monster_owner = nullptr;
    get_unit_hp_percent = nullptr;
}

}  // namespace unleashed
