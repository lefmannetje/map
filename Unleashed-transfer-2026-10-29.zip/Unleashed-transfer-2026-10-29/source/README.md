# Unleashed for ProjectD2

Maintainable 32-bit C++ reconstruction of the supplied Unleashed map DLL,
targeted at the verified ProjectD2 client build used during development.

## Included features

- Full map reveal and cached room processing
- Num1 next, Num2 quest, Num3 waypoint, Num4 previous-area navigation
- Boss/champion/unique/Uber automap markers and Cow Level markers
- Color-coded immunity and elemental-enchantment labels on special monsters
- Shrine, waypoint, special chest and container markers
- Automatic rejuvenation potion below the configured player-life threshold
- Configurable emergency `Game.exe` termination at critical player life
- Shop-winner overlay for high-value skill weapons and gloves
- F8-toggleable Drognan shop buyer for Sorceress staves (temporarily set to
  +3 or higher for purchase-path testing)
- Delegation to the installed ProjectD2/BH loot-filter implementation
- Standalone administrator-aware DLL loader
- Logical-surface bounds checking and per-category automap fault isolation

The bindings are intentionally fail-closed. A different `D2Client.dll`,
`ProjectDiablo.dll`, or BH build may require updated verified offsets.

## Requirements

- Windows 10 or 11
- Visual Studio 2022 Build Tools (or Visual Studio 2022) with **Desktop
  development with C++**
- CMake 3.24 or newer

## Build

Open PowerShell in this directory and run:

```powershell
.\build-win32.ps1
```

Or invoke CMake manually:

```powershell
cmake -S . -B build -A Win32
cmake --build build --config Release
```

Outputs are placed in `build\Release`:

- `Unleashed.dll`
- `UnleashedLoader.exe`

Keep `Unleashed.ini` beside `Unleashed.dll`. The optional customized loot
filter is in `filters\Unleashed-Futureal.filter`.

## Use

1. Copy `Unleashed.dll`, `Unleashed.ini`, and `UnleashedLoader.exe` into one
   folder.
2. Start ProjectD2 and enter the game.
3. Run `UnleashedLoader.exe` as administrator.

The loader targets the running 32-bit `Game.exe` and loads `Unleashed.dll`
from its own directory.

### Sorceress staff buyer

Open Drognan's trade window in Act II and press **F8**. While enabled, this
test build purchases displayed staves whose best Sorceress skill reaches at
least +3 after combining all-Sorceress, skill-tree, and individual-skill
bonuses. The final intended threshold is +6.
Examples include +4 Sorceress skills with +2 to one skill, or +3 to a skill
tree with +3 to one skill in that tree. A +7 combination also qualifies.

This build intentionally does not move the character, leave town, or start
NPC conversations automatically. Those actions need live validation against
the installed ProjectD2 build before they can be enabled safely.

## Source layout

- `src\bindings`: target-build verification
- `src\core`: configuration, logging, and feature lifecycle
- `src\features`: map, lighting, survival, shop, and BH integration
- `src\recovered`: verified hook chains and packet dispatcher
- `tools\diagnostic_loader.cpp`: standalone loader source
